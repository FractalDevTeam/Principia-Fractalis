import PF.Analytic.DerivEdgeReBound_2026_10_20
open PrincipiaTractalis.DerivEdgeReBound20261020
#check @integrableOn_mul_F_plus''
#check @integral_mul_F_plus''_eq
#check @weighted_K_sum_eq
#check @K_sum_eq_quarter
