#!/bin/bash
# Box c = 7, r = 1/16, D = 1. Serial, lock-guarded: a single Seg0kRange build
# peaks at 5-7 GB on a 15 GB box, so two concurrent builds OOM (rc=137).
exec 9>/tmp/pf_lean_build.lock
if ! flock -n 9; then echo "ANOTHER BUILD HOLDS THE LOCK" > /tmp/c7_status; exit 1; fi
export PATH="$HOME/.elan/bin:$PATH"
cd "/Storage 2TB/home/xluxx/Principia-Fractalis-ACTIVE/PF_Lean4_Code" || exit 1
FP=".lake/build/lib/lean/PF/Analytic/FourierPanels"
PB=".lake/build/lib/lean/PF/Analytic/PilotBoxes"
mkdir -p "$FP" "$PB"
: > /tmp/c7_progress
echo RUNNING > /tmp/c7_status

fp() {  # $1 = module basename (no .lean)
  taskset -c 0,1 lake env lean -o "$FP/$1.olean" \
    "PF/Analytic/FourierPanels/$1.lean" > "/tmp/c7_$1.log" 2>&1
  local rc=$?
  echo "$1 rc=$rc $(date +%H:%M:%S) freeGB=$(free -g | awk 'NR==2{print $4}')" \
    >> /tmp/c7_progress
  [ $rc -ne 0 ] && { echo "FAILED $1" > /tmp/c7_status; exit 1; }
}

while read -r m; do
  [ -z "$m" ] && continue
  fp "$m"
done < PF/Analytic/_buildorder.txt

# Gate pilot, then the unconditional pilot (checked, not cached).
taskset -c 0,1 lake env lean -o "$PB/R1_c7_r1_16_HYBRID_2026_10_20.olean" \
  "PF/Analytic/PilotBoxes/R1_c7_r1_16_HYBRID_2026_10_20.lean" \
  > /tmp/c7_gate.log 2>&1
echo "gate rc=$? $(date +%H:%M:%S)" >> /tmp/c7_progress

taskset -c 0,1 lake env lean \
  "PF/Analytic/PilotBoxes/R1_c7_r1_16_pointwise_UNCONDITIONAL_2026_10_20.lean" \
  > /tmp/c7_uncond.log 2>&1
echo "uncond rc=$? $(date +%H:%M:%S)" >> /tmp/c7_progress

echo DONE > /tmp/c7_status
