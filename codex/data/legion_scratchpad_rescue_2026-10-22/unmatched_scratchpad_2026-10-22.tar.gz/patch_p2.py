#!/usr/bin/env python3
"""Parametric density, part 2: the naming and segment-set sites in
gen_box_part2.py. Every anchor here is backslash-free, so the patch cannot be
corrupted by shell quoting on the way in."""
import io

p = "gen_box_part2.py"
s = io.open(p, encoding="utf-8").read()
done = []


def rep(old, new, desc, n=1):
    global s
    got = s.count(old)
    assert got == n, f"{desc}: found {got}, expected {n}"
    s = s.replace(old, new)
    done.append(desc)


# 1. geometry block -> density read from gen_box, plus the naming helpers
rep("""PANEL_WIDTH = F(1, 32)
N_PANELS = 8
MID_SEGS = (1, 2)
RANGE_SEGS = (1, 2, 3, 4, 5, 6)""",
    '''N_PANELS = 8            # panels per MODULE -- fixed, never scaled with density


def _geom():
    """Density-dependent geometry, read from gen_box at call time rather than
    duplicated here, so the two halves of the producer cannot disagree about
    it. gen_box.set_density() is the single writer."""
    import gen_box as G
    return G.PANEL_WIDTH, G.MID_SEGS, G.RANGE_SEGS


def seg_mod_range(s):
    return f"Seg{s:02d}Range"


def seg_mod_mid(s):
    return f"Seg{s:02d}Midpoint"''',
    "geometry block")

# 2. the two functions that used the module-global segment sets now read _geom
rep("""    import re as _re
    t = tag(c)
    out = {}
    for s_idx in MID_SEGS:""",
    """    import re as _re
    PANEL_WIDTH, MID_SEGS, RANGE_SEGS = _geom()
    t = tag(c)
    out = {}
    for s_idx in MID_SEGS:""",
    "parse: read geometry")

rep("""    raw = _parse_midpoint_literals(c, tag, outdir)
    t = tag(c)""",
    """    PANEL_WIDTH, MID_SEGS, RANGE_SEGS = _geom()
    raw = _parse_midpoint_literals(c, tag, outdir)
    t = tag(c)""",
    "assemble: read geometry")

# 3. naming sites -- anchored on the module-name fragment only, no backslashes
rep('f"Seg0{s_idx}Midpoint_{t}_2026_10_20.lean"',
    'f"{seg_mod_mid(s_idx)}_{t}_2026_10_20.lean"',
    "midpoint parse path")

rep("FourierPanels.Seg0{s}Midpoint_{t}",
    "FourierPanels.{seg_mod_mid(s)}_{t}",
    "midpoint import")

rep("    for s in (3, 4, 5, 6):",
    """    for s in RANGE_SEGS:
        if s in MID_SEGS:
            continue""",
    "range import loop")

rep("FourierPanels.Seg0{s}Range_{t}",
    "FourierPanels.{seg_mod_range(s)}_{t}",
    "range import name")

rep("    Seg0{s}Midpoint.m0{s}p{p}_{side}_integral_bound",
    "    {seg_mod_mid(s)}.m{s:02d}p{p}_{side}_integral_bound",
    "midpoint bound reference")

rep("Seg0{s}Range.s0{s}p{p}_{side}_integral_bound",
    "{seg_mod_range(s)}.s{s:02d}p{p}_{side}_integral_bound",
    "range bound reference")

io.open(p, "w", encoding="utf-8", newline="\n").write(s)
print("patched gen_box_part2.py:")
for d in done:
    print("  -", d)
