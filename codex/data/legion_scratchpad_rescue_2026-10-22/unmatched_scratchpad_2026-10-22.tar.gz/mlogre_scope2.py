import math

CURVES = {
    "11a1":   ((0,-1, 1, 0, 0),  0,   11),
    "37a1":   ((0, 0, 1,-1, 0),  1,   37),
    "43a1":   ((0, 1, 1, 0, 0),  1,   43),
    "53a1":   ((1,-1, 1, 0, 0),  1,   53),
    "389a1":  ((0, 1, 1,-2, 0),  2,  389),
    "5077a1": ((0, 0, 1,-7, 6),  3, 5077),
}

def invariants(a):
    a1,a2,a3,a4,a6 = a
    b2 = a1*a1 + 4*a2; b4 = 2*a4 + a1*a3; b6 = a3*a3 + 4*a6
    b8 = a1*a1*a6 + 4*a2*a6 - a1*a3*a4 + a2*a3*a3 - a4*a4
    D  = -b2*b2*b8 - 8*b4**3 - 27*b6*b6 + 9*b2*b4*b6
    return b2,b4,b6,b8,D

def primes_upto(n):
    s = bytearray([1])*(n+1); s[0]=s[1]=0
    for i in range(2,int(n**0.5)+1):
        if s[i]: s[i*i::i] = bytearray(len(s[i*i::i]))
    return [i for i in range(n+1) if s[i]]

def legendre(a,p):
    a %= p
    return 0 if a==0 else (1 if pow(a,(p-1)//2,p)==1 else -1)

_apc = {}
def a_p(cur,p):
    k=(cur,p)
    if k in _apc: return _apc[k]
    b2,b4,b6,b8,D = invariants(cur)
    s=0
    for x in range(p):
        s += legendre((4*x*x*x + b2*x*x + 2*b4*x + b6) % p, p)
    _apc[k]=-s
    return -s

def D3(n):
    s=0
    while n: s += n%3; n//=3
    return s

def M(cur, X, mode):
    """mode 'pi_alpha' : phase = pi*alpha*D3   (docstring literal, alpha=3pi/4)
       mode 'alpha'    : phase = alpha*D3      (the other natural reading)"""
    b2,b4,b6,b8,D = invariants(cur)
    alpha = 3*math.pi/4
    tot=0.0
    for p in PR:
        if p>X: break
        if p==2 or D%p==0: continue
        ph = math.pi*alpha*D3(p) if mode=='pi_alpha' else alpha*D3(p)
        tot += a_p(cur,p) * (math.cos(ph)/math.sqrt(p)) * math.log(p)/p
    return -tot/math.log(X)

PR = primes_upto(40000)

print("=== (a) FORMULA AMBIGUITY: which reading of 'e^{i*pi*alpha*D_3(p)}' was computed? ===")
quoted = {"11a1":0.170, "37a1":-0.580, "389a1":-0.767, "5077a1":-0.143}
print("  curve     quoted     phase=pi*alpha*D3   phase=alpha*D3")
for lab in ["11a1","37a1","389a1","5077a1"]:
    cur = CURVES[lab][0]
    print("  %-8s %+0.3f      %+0.6f           %+0.6f"
          % (lab, quoted[lab], M(cur,2000,'pi_alpha'), M(cur,2000,'alpha')))
print("  --> neither reading reproduces the quoted table (5077a1 is coincidentally close)")

print()
print("=== (b) ASYMPTOTICS: the claim is X -> infinity. Does the sign stabilise? ===")
Xs = [1000, 2000, 5000, 10000, 20000, 40000]
print("  curve    rank " + "".join("  X=%-6d" % X for X in Xs))
for lab in ["11a1","37a1","43a1","53a1","389a1","5077a1"]:
    cur, r, N = CURVES[lab]
    row = "  %-8s %d   " % (lab, r)
    for X in Xs:
        row += " %+0.4f " % M(cur, X, 'pi_alpha')
    print(row)

print()
print("=== (c) the thin-margin curve 43a1 (rank 1, M was only -0.0155 at X=2000) ===")
cur = CURVES["43a1"][0]
for X in Xs:
    v = M(cur, X, 'pi_alpha')
    print("   X=%-6d  M=%+0.6f   sign %s" % (X, v, "NEGATIVE (ok)" if v<0 else "POSITIVE -> WRONG for rank 1"))

print()
print("=== (d) magnitude trend: is |M| -> 0 ? (if so no asymptotic sign claim is supported) ===")
for lab in ["11a1","37a1","389a1"]:
    cur = CURVES[lab][0]
    v1 = abs(M(cur,1000,'pi_alpha')); v2 = abs(M(cur,40000,'pi_alpha'))
    print("   %-8s |M| at X=1000: %0.4f   at X=40000: %0.4f   ratio %0.2f"
          % (lab, v1, v2, v2/v1 if v1 else float('nan')))
