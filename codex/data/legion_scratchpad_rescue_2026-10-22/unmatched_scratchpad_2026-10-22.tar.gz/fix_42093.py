#!/usr/bin/env python3
"""#42093: sort the import block, which is the whole build failure.

CI's Build step failed on head 5782b447 with

  warning: Mathlib/Topology/Algebra/Ring/TwoSidedIdeal.lean:10:0:
    Imports can be reformatted:
      public import Mathlib.RingTheory.TwoSidedIdeal.Lattice
      public import Mathlib.Topology.Algebra.IsOpenUnits
      public import Mathlib.Topology.Algebra.Ring.Basic
  Some required targets logged failures:
  - Mathlib.Topology.Algebra.Ring.TwoSidedIdeal
  error: build failed

`linter.style.header.imports` wants the block sorted, and in mathlib CI that
warning is build-failing. 'IsOpenUnits' sorts before 'Ring' ('I' < 'R'), so the
last two lines are in the wrong order.

MERGE FALLOUT, not the PR's own code: the ordering was accepted before the
2026-10-22 web-flow master merge, which brought the newer linter in. Nothing but
the order of two import lines changes -- no declarations, no API, nothing near
the TwoSidedIdeal-vs-Ideal design question.

This checkout is CRLF (core.autocrlf), so the line terminator is DETECTED and
preserved rather than assumed; writing LF would rewrite every line and bury a
two-line fix in a whole-file diff.
"""
import io
import os
import sys

PATH = ("D:/CLAUDE-i9/_tmp/pr42093-wt/Mathlib/Topology/Algebra/Ring/"
        "TwoSidedIdeal.lean")
if not os.path.exists(PATH):
    print("REFUSING: not found: %s" % PATH)
    sys.exit(1)

text = io.open(PATH, encoding="utf-8", newline="").read()
CRLF = chr(13) + chr(10)
EOL = CRLF if text.count(CRLF) else chr(10)
print("detected line terminator: %s" % ("CRLF" if EOL == CRLF else "LF"))

A = "public import Mathlib.Topology.Algebra.Ring.Basic"
B = "public import Mathlib.Topology.Algebra.IsOpenUnits"
OLD = A + EOL + B + EOL
NEW = B + EOL + A + EOL

n = text.count(OLD)
if n != 1:
    print("REFUSING: expected exactly 1 unsorted pair, found %d" % n)
    sys.exit(1)

out = text.replace(OLD, NEW, 1)
assert len(out) == len(text), "byte length changed -- more than a reorder"
assert sorted(out.split(EOL)) == sorted(text.split(EOL)), \
    "line multiset changed -- not a pure reorder"

io.open(PATH, "w", encoding="utf-8", newline="").write(out)
print("applied: import block sorted (pure reorder, byte length unchanged)")
shown = io.open(PATH, encoding="utf-8").read().split("\n")
for i, line in enumerate(shown[5:11], 6):
    print("  %2d  %s" % (i, line.rstrip()))
