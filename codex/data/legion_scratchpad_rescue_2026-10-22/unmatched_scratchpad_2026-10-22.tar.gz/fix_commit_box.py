#!/usr/bin/env python3
"""Stop commit_box.sh from absorbing files it was never given.

`git add <box files>` followed by a BARE `git commit` commits the whole index,
not just what was added. So anything another session (or I) left staged gets
swept into a box commit under a "feat(Riemann): box c = ..." message. That is
not hypothetical: it is what happened to the ch07/ch24 manuscript repairs in
d4fafadb, which is now a pushed Riemann box commit containing two book chapters.

Fix: expand the box's own files once into an array and pass that array as a
pathspec to `git commit`. With a pathspec git commits ONLY those paths and
leaves the rest of the index alone, so a stray staged file is no longer a
provenance hazard -- it just stays staged.

Deployed by atomic mv so a live runner never sees a half-written script.
"""
import io
import os
import shutil
import sys

SRC = "/Storage 2TB/home/xluxx/Principia-Fractalis-ACTIVE/codex/commit_box.sh"

OLD = '''git add "PF_Lean4_Code/PF/Analytic/FourierPanels/"*_${TAG}_*.lean \\
        "PF_Lean4_Code/PF/Analytic/PilotBoxes/R1_${TAG}_"*.lean || exit 1
git commit -q -F "$MSG" || exit 1
'''

NEW = '''# Stage AND commit only this box's own files. A bare `git commit` commits the
# whole index, so anything another session left staged is absorbed into the box
# commit under a Riemann message that does not mention it -- which is how the
# ch07/ch24 manuscript repairs ended up inside box commit d4fafadb on
# 2026-10-22. Passing the same expanded list as a pathspec makes that
# impossible: a stray staged file stays staged instead of being published here.
BOXFILES=( "PF_Lean4_Code/PF/Analytic/FourierPanels/"*_${TAG}_*.lean \\
           "PF_Lean4_Code/PF/Analytic/PilotBoxes/R1_${TAG}_"*.lean )
git add "${BOXFILES[@]}" || exit 1
git commit -q -F "$MSG" -- "${BOXFILES[@]}" || exit 1
'''

text = io.open(SRC, encoding="utf-8").read()
n = text.count(OLD)
if n != 1:
    print("REFUSING: expected exactly 1 occurrence of the add/commit pair, found %d" % n)
    sys.exit(1)

bak = SRC + ".bak-pathspec"
if not os.path.exists(bak):
    shutil.copy2(SRC, bak)
    print("backup: %s" % bak)

new_text = text.replace(OLD, NEW)
tmp = SRC + ".new"
io.open(tmp, "w", encoding="utf-8", newline="\n").write(new_text)
shutil.copymode(SRC, tmp)
os.replace(tmp, SRC)          # atomic

check = io.open(SRC, encoding="utf-8").read()
assert "git commit -q -F \"$MSG\" -- \"${BOXFILES[@]}\"" in check
assert check.count("git commit -q -F \"$MSG\" || exit 1") == 0
print("deployed: commit now takes a pathspec")
print("bash -n:", os.system("bash -n '%s'" % SRC) == 0)
