import PF.Analytic.ThetaBoundaryConstant_2026_10_19
import PF.Analytic.Lambda0IBP2Combined_2026_10_18
import PF.Analytic.EdgeReDerivBound_2026_10_14
import PF.Analytic.R1Neighborhood_2026_10_09
import Mathlib.Analysis.Calculus.ParametricIntegral

open Complex Real MeasureTheory Set Filter
open PrincipiaTractalis.OmegaDerivative20261014
open PrincipiaTractalis.OmegaSecondDerivative20261018
open PrincipiaTractalis.FPlusSecondDerivative20261018
open PrincipiaTractalis.FPlusSecondIBPRows20261018
open PrincipiaTractalis.FMinusSecondIBP20261018
open PrincipiaTractalis.Lambda0IBP2Combined20261018
open PrincipiaTractalis.ThetaBoundaryConstant20261019
open PrincipiaTractalis.XiThetaIntegral
open PrincipiaTractalis.RiemannXiEntire
open PrincipiaTractalis.EdgeReDerivBound20261014
open PrincipiaTractalis.R1Neighborhood20261009

-- the pieces I need for nonnegativity
#check @omega''
#check @omega''_nonneg
#check @omega'
#check @omega_nonneg
#check @F_plus''
#check @F_minus''
#check @abs_F_plus''_le
#check @abs_F_minus''_le
#check @F_plus'
#check @F_minus'
-- summability of the omega families
#check @omega_summable
#check @omega'_summable
#check @omega''_summable
-- FTC / limits
#check @tendsto_deriv_F_plus_atTop_zero
#check @deriv_F_plus_zero
#check @deriv_F_minus_zero
#check @hasDerivAt_deriv_F_plus
#check @integrableOn_deriv_deriv_F_plus
#check @deriv_F_plus'_eq_F_plus''
-- the sharp identity + boundary constant
#check @lambda0_edge_ibp2_identity_sharp
#check @boundary_const_eq_neg_quarter
#check @norm_int_F_plus''_le
-- edge machinery
#check @deriv_edgeRe_eq
#check @edgeRe
#check @re_xi_at_s
#check @tsum_nonneg
#check @Summable.tsum_add
#check @tsum_mul_left
