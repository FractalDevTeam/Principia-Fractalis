#!/usr/bin/env python3
"""Paper gate for the c = 13/2 box, computed before any Lean is written.

Gate model (codex/PILOT14_GATE_ANALYSIS_2026-10-14.md,
codex/POINTWISE_PANEL_PLAN_c6_2026-10-15.md):

    s = 1 + i c,   s(s-1) = -c^2 + i c
    Re xi(1+ic) = (1 - c^2 * Re Lambda0 - c * Im Lambda0) / 2
    Lambda0(s)  = Lambda(s) + 1/s + 1/(1-s),  Lambda(s) = pi^(-s/2) Gamma(s/2) zeta(s)

Ground truth via mpmath (NON-certifying -- this is the paper gate, not a proof).
"""
from mpmath import mp, mpf, mpc, pi, gamma, zeta, power

mp.dps = 50


def Lambda0(s):
    Lam = power(pi, -s / 2) * gamma(s / 2) * zeta(s)
    return Lam + 1 / s + 1 / (1 - s)


def gate(c):
    c = mpf(c)
    s = mpc(1, c)
    L0 = Lambda0(s)
    R, I = L0.real, L0.imag
    two_re_xi = 1 - c ** 2 * R - c * I
    return R, I, two_re_xi / 2, two_re_xi


print("=" * 78)
print("centre-value gate, exact-ish (mpmath, dps=50)")
print("%-9s %-16s %-16s %-14s" % ("c", "Re Lambda0", "Im Lambda0", "Re xi(1+ic)"))
for c in ["6", "6.125", "6.25", "6.375", "6.5"]:
    R, I, rexi, _ = gate(c)
    print("%-9s %-16.10f %-16.10f %-14.10f" % (c, R, I, rexi))

print()
print("=" * 78)
print("the four landed boxes are centred at c = 6, 49/8, 25/4, 51/8 with r = 1/16.")
print("Rio's reported margins: 0.0578, 0.0375, 0.0171, 0.0050.")
print("Identify what those are, by evaluating the WORST point of each box")
print("(gate 1 must hold across [c-r, c+r], and Re xi is decreasing here):")
print()
r = mpf(1) / 16
print("%-10s %-12s %-14s %-14s %-12s" % ("centre", "box hi", "Re xi(hi)", "Re xi(hi)-1/8", "Rio"))
rio = {"6": "0.0578", "6.125": "0.0375", "6.25": "0.0171", "6.375": "0.0050"}
for c in ["6", "6.125", "6.25", "6.375"]:
    hi = mpf(c) + r
    _, _, rexi_hi, _ = gate(hi)
    print("%-10s %-12.4f %-14.10f %-14.10f %-12s"
          % (c, hi, rexi_hi, rexi_hi - mpf(1) / 8, rio[c]))

print()
print("=" * 78)
print("PROJECTION for the requested box c = 13/2 = 6.5, [6.4375, 6.5625]:")
for cc in ["6.4375", "6.5", "6.5625"]:
    _, _, rexi, _ = gate(cc)
    print("   Re xi(1+i*%-8s) = %+.10f     Re xi - 1/8 = %+.10f"
          % (cc, rexi, rexi - mpf(1) / 8))

print()
print("   worst point of the box is the upper edge c = 6.5625:")
_, _, w, _ = gate("6.5625")
print("   Re xi = %+.10f ;  margin against Mc_lb = 1/8 : %+.10f" % (w, w - mpf(1) / 8))
print("   margin against Mc_lb = 1/16 : %+.10f" % (w - mpf(1) / 16))
print("   margin against Mc_lb = 0    : %+.10f" % w)

print()
print("=" * 78)
print("where does Re xi(1+ic) actually cross each threshold? (bisection)")


def cross(target, lo=mpf(6), hi=mpf(8)):
    f = lambda c: gate(c)[2] - target
    if f(lo) < 0:
        return None
    for _ in range(200):
        mid = (lo + hi) / 2
        if f(mid) > 0:
            lo = mid
        else:
            hi = mid
    return (lo + hi) / 2


for name, thr in [("1/8", mpf(1) / 8), ("1/16", mpf(1) / 16), ("0", mpf(0))]:
    c0 = cross(thr)
    print("   Re xi drops below %-5s at c = %s" % (name, c0))
