#!/usr/bin/env python3
"""Repair the doubled backslash on ch24 line 599.

`\\subsection{Example 2: Rank 1 Curve}` sits immediately after a blank line, so
the `\\` is a line break with no line to end -- "LaTeX Error: There's no line
here to end." The book does not build. Introduced in the uncommitted 2026-10-16
repair batch that replaced this example's curve; the repair itself is correct,
only its backslash count is wrong.

Backs up first, asserts exactly one substitution, and writes only on success.
Built with chr(92) so no heredoc, shell, or sed layer can eat a backslash level
on the way in -- that is the bug being fixed.
"""
import io
import os
import shutil
import sys

BS = chr(92)
PATH = ("/Storage 2TB/home/xluxx/Principia-Fractalis-ACTIVE/"
        "Principia_Fractalis_master_folder/chapters/ch24_birch_swinnerton_dyer.tex")
BAD = BS + BS + "subsection{Example 2: Rank 1 Curve}"
GOOD = BS + "subsection{Example 2: Rank 1 Curve}"

text = io.open(PATH, encoding="utf-8").read()
n = text.count(BAD)
if n != 1:
    print("REFUSING: expected exactly 1 occurrence, found %d" % n)
    sys.exit(1)

bak = PATH + ".bak-bsfix"
if not os.path.exists(bak):
    shutil.copy2(PATH, bak)
    print("backup: %s" % bak)

io.open(PATH, "w", encoding="utf-8", newline="\n").write(text.replace(BAD, GOOD))

check = io.open(PATH, encoding="utf-8").read()
print("after: bad=%d good=%d" % (check.count(BAD), check.count(GOOD)))
assert check.count(BAD) == 0 and check.count(GOOD) == 1
# nothing else moved
assert len(check) == len(text) - 1, "unexpected size change"
print("OK: one character removed, nothing else touched")
