#!/bin/bash
# Box c=29/4 finish: only the assemble and the two pilots changed (rewired onto
# box_of_enclosure_rat). The twelve modules before them already built rc=0 and
# their sources are byte-identical, so their oleans stay valid.
set -u
exec 9>/tmp/pf_lean_build.lock
if ! flock -n 9; then echo "LOCKED" > /tmp/b29_status; exit 1; fi
export PATH="$HOME/.elan/bin:$PATH"
A="/Storage 2TB/home/xluxx/Principia-Fractalis-ACTIVE/PF_Lean4_Code"
cd "$A" || exit 1
for f in /tmp/v29/*.lean; do b=$(basename "$f")
  case "$b" in R1_c29_4_*) cp "$f" PF/Analytic/PilotBoxes/"$b" ;;
               *) cp "$f" PF/Analytic/FourierPanels/"$b" ;; esac; done
FP=".lake/build/lib/lean/PF/Analytic/FourierPanels"
PB=".lake/build/lib/lean/PF/Analytic/PilotBoxes"
: > /tmp/b29_progress; echo RUNNING > /tmp/b29_status
run() { taskset -c 0,1 lake env lean ${3:+-o "$3"} "$2" > "/tmp/b29_$1.log" 2>&1
        rc=$?; echo "$1 rc=$rc $(date +%H:%M:%S) freeGB=$(free -g|awk 'NR==2{print $4}')" >> /tmp/b29_progress
        [ $rc -ne 0 ] && { echo "FAILED $1" > /tmp/b29_status; exit 1; }; }
run asm   "PF/Analytic/FourierPanels/Assemble_c29_4_threehalves_HYBRID_2026_10_20.lean" \
          "$FP/Assemble_c29_4_threehalves_HYBRID_2026_10_20.olean"
run gate  "PF/Analytic/PilotBoxes/R1_c29_4_r1_16_HYBRID_2026_10_20.lean" \
          "$PB/R1_c29_4_r1_16_HYBRID_2026_10_20.olean"
run uncond "PF/Analytic/PilotBoxes/R1_c29_4_r1_16_pointwise_UNCONDITIONAL_2026_10_20.lean" ""
U=/tmp/b29_uncond.log
grep -qE "sorryAx|nativeDecide|ofReduceBool" $U && { echo "FAILED axiom bar" > /tmp/b29_status; exit 1; }
SETS=$(tr '\n' ' ' < $U | grep -oE "axioms: \[[^]]*\]" | tr -s ' ' | sort -u)
N=$(grep -c "depends on axioms" $U)
[ "$SETS" = "axioms: [propext, Classical.choice, Quot.sound]" ] || { echo "FAILED axiom sets: $SETS" > /tmp/b29_status; exit 1; }
echo "axiom-bar OK: $N theorems, all [propext, Classical.choice, Quot.sound]" >> /tmp/b29_progress
echo "DONE c=29/4 r=1/16 ($N theorems on the bar)" > /tmp/b29_status
