import PF.Analytic.Lambda0PrimeUniformBound_2026_10_14
import Mathlib.Analysis.Calculus.ParametricIntegral

open Complex Real MeasureTheory Set
open PrincipiaTractalis.XiThetaIntegral
open PrincipiaTractalis.Lambda0UniformBound20261014

-- in-tree pieces, now with the right namespace open
#check @completedRiemannZeta₀_eq_theta_integral
#check @omega_le_geometric
#check @integral_exp_neg_pi_mul_Ioi
#check @omega_nonneg

-- cpow derivative in the EXPONENT: d/ds (x^s) = x^s * log x
#check @Complex.cpow_def
#check @Complex.hasDerivAt_cpow_const
#check @HasDerivAt.const_cpow
#check @Complex.hasStrictDerivAt_const_cpow

-- ∫ u e^{-a u}: candidates
#check @integral_Ioi_of_hasDerivAt_of_tendsto
#check @Real.Gamma_two_eq_one
#check @integral_exp_neg_mul_Ioi
#check @MeasureTheory.integral_comp_add_right
