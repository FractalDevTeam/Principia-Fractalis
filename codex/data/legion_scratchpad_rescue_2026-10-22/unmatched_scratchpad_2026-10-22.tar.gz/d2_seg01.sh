#!/bin/bash
# Rio 2026-10-21 section 2, LEGION task 4: build the Seg01 pack of the D=2 test
# box at c = 81/8. EMIT, DO NOT LAND -- the three sources are installed into the
# tree because Lean must resolve their module paths, but they are left UNTRACKED
# and nothing is committed.
#
# This is the first Lean ever built at density > 1. Everything validating the
# parametric producer so far has been Python-side (D=1 byte-identity at four
# centres, Mc_lb agreement to 8 decimals, counts, literal termination); the
# D >= 2 emitted PROOFS have never been near the kernel.
#
# Takes the shared flock with a WAIT, per section 1: the march runner holds it
# between boxes, so blocking queues this behind the current box instead of
# colliding with it. Dual builds OOM at 15 GB.
set -u
REPO="/Storage 2TB/home/xluxx/Principia-Fractalis-ACTIVE"
SRC=/tmp/d2test
TAG=c81_8
ST=/tmp/d2seg01_status
PG=/tmp/d2seg01_progress
: > "$PG"
echo "WAITING for the band to finish, then the lock" > "$ST"

# Do NOT simply block on the lock. march_box.sh takes it with `flock -n` and
# exits 1 on contention, and march_run.sh treats a non-zero march_box.sh as a
# STOP -- so grabbing the lock between boxes would halt the band and write a
# false failure into its log. Wait for the band to be genuinely finished first,
# then take the lock uncontended.
while ps -eo args | grep -q "[m]arch_run.sh"; do sleep 60; done
echo "band runner exited $(date +%H:%M:%S)" >> "$PG"
exec 9>/tmp/pf_lean_build.lock
flock -w 3600 9 || { echo "FAILED: lock wait timed out" > "$ST"; exit 1; }
echo "lock acquired $(date +%H:%M:%S)" >> "$PG"
export PATH="$HOME/.elan/bin:$PATH"

A="$REPO/PF_Lean4_Code/PF/Analytic"
MODS="CoreDefs_${TAG}_2026_10_16 Seg01Range_${TAG}_2026_10_16 Seg01Midpoint_${TAG}_2026_10_20"
for m in $MODS; do cp "$SRC/$m.lean" "$A/FourierPanels/$m.lean" || {
  echo "FAILED: cannot install $m" > "$ST"; exit 1; }; done
echo "installed (untracked): $MODS" >> "$PG"

cd "$REPO/PF_Lean4_Code" || exit 1
FP=".lake/build/lib/lean/PF/Analytic/FourierPanels"
mkdir -p "$FP"
echo "BUILDING the Seg01 pack at D=2" > "$ST"
for m in $MODS; do
  taskset -c 0,1 lake env lean -o "$FP/$m.olean" \
    "PF/Analytic/FourierPanels/$m.lean" > "/tmp/d2seg01_$m.log" 2>&1
  rc=$?
  echo "$m rc=$rc $(date +%H:%M:%S) freeGB=$(free -g | awk 'NR==2{print $4}')" >> "$PG"
  if [ $rc -ne 0 ]; then
    echo "FAILED $m -- see /tmp/d2seg01_$m.log" > "$ST"
    head -40 "/tmp/d2seg01_$m.log" >> "$PG"
    exit 1
  fi
done

# Axiom evidence, per section 0.9: the #print axioms output itself, matched
# directive-by-directive by the same checker the march uses.
for m in $MODS; do
  if ! python3 "$REPO/codex/check_march_axioms.py" \
        "$SRC/$m.lean" "/tmp/d2seg01_$m.log" >> "$PG" 2>&1; then
    echo "FAILED axiom bar on $m" > "$ST"; exit 1
  fi
done
echo "DONE: D=2 Seg01 pack built and on the exact three-axiom bar (NOT landed)" > "$ST"
