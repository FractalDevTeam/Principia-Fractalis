import PF.Analytic.DerivEdgeReLocalL_2026_10_20
import Mathlib.Analysis.Calculus.ParametricIntegral
open Complex Real MeasureTheory Set Filter Topology

-- bridging an integral's real/imaginary part
#check @MeasureTheory.integral_re
#check @Complex.integral_re
#check @RCLike.re_integral
#check @Complex.reCLM
#check @ContinuousLinearMap.integral_comp_comm
-- Re / Im of a HasDerivAt (real parameter, complex valued)
#check @HasDerivAt.real_of_complex
#check @ContinuousLinearMap.hasDerivAt
#check @HasFDerivAt.hasDerivAt
#check @HasDerivAt.hasFDerivAt
-- complex exp derivative in a real parameter
#check @HasDerivAt.cexp
#check @Complex.ofRealCLM
#check @Complex.abs_exp
#check @Complex.norm_exp
-- real route: cos/sin derivatives
#check @Real.hasDerivAt_cos
#check @Real.hasDerivAt_sin
#check @HasDerivAt.cos
#check @HasDerivAt.sin
