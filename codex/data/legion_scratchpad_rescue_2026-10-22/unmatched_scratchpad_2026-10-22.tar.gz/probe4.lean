import PF.Analytic.Lambda0PrimeUniformBound_2026_10_14
import Mathlib.Analysis.Calculus.ParametricIntegral

open Complex Real MeasureTheory Set Filter
open PrincipiaTractalis.XiThetaIntegral

#check @Real.tendsto_pow_mul_exp_neg_atTop_nhds_zero
#check @Real.tendsto_exp_neg_atTop_nhds_zero
#check @exp_neg_integrableOn_Ioi
#check @Integrable.mono'
#check @ContinuousOn.aestronglyMeasurable
#check @norm_integral_le_of_norm_le
#check @setIntegral_mono_on
#check @Real.add_one_le_exp

noncomputable section
private def G (x : ℝ) : ℝ := ((1 - x) / π - 1 / π ^ 2) * Real.exp (-π * x)

private lemma hasDerivAt_G (x : ℝ) :
    HasDerivAt G ((x - 1) * Real.exp (-π * x)) x := by
  have hπ : (0:ℝ) < π := Real.pi_pos
  have h1 : HasDerivAt (fun y : ℝ => (1 - y) / π - 1 / π ^ 2) (-(1/π)) x := by
    have ha : HasDerivAt (fun y : ℝ => (1 - y) / π) (-(1/π)) x := by
      have hb : HasDerivAt (fun y : ℝ => 1 - y) (-1) x := by
        simpa using (hasDerivAt_const x (1:ℝ)).sub (hasDerivAt_id x)
      have := hb.div_const π
      simpa [neg_div] using this
    simpa using ha.sub_const (1 / π ^ 2)
  have h2 : HasDerivAt (fun y : ℝ => Real.exp (-π * y)) (-π * Real.exp (-π * x)) x := by
    have hl : HasDerivAt (fun y : ℝ => -π * y) (-π) x := by
      simpa using (hasDerivAt_id x).const_mul (-π)
    simpa [mul_comm] using hl.exp
  have hG : G = fun y : ℝ => ((1 - y) / π - 1 / π ^ 2) * Real.exp (-π * y) := rfl
  rw [hG]
  convert h1.mul h2 using 1
  have hne : π ≠ 0 := ne_of_gt hπ
  field_simp
  ring

private lemma tendsto_G_atTop : Tendsto G atTop (nhds 0) := by
  have hπ : (0:ℝ) < π := Real.pi_pos
  set g : ℝ → ℝ := fun u => (1/π - 1/π^2) * Real.exp (-u) - (1/π^2) * (u * Real.exp (-u)) with hg
  have hgt : Tendsto g atTop (nhds 0) := by
    have h1 : Tendsto (fun u : ℝ => (1/π - 1/π^2) * Real.exp (-u)) atTop (nhds 0) := by
      simpa using (Real.tendsto_exp_neg_atTop_nhds_zero).const_mul (1/π - 1/π^2)
    have h2 : Tendsto (fun u : ℝ => (1/π^2) * (u * Real.exp (-u))) atTop (nhds 0) := by
      have := Real.tendsto_pow_mul_exp_neg_atTop_nhds_zero 1
      simpa using this.const_mul (1/π^2)
    simpa [hg] using h1.sub h2
  have hcomp : Tendsto (fun x : ℝ => π * x) atTop atTop :=
    Filter.Tendsto.const_mul_atTop hπ tendsto_id
  have := hgt.comp hcomp
  refine this.congr (fun x => ?_)
  simp only [hg, Function.comp_apply]
  have hne : π ≠ 0 := ne_of_gt hπ
  rw [G]
  field_simp
  ring
end
