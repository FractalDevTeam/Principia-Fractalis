/-! ## §3 — Pointwise derivative of the two phases, and `‖phase‖ = 1` -/

/-- `s ↦ (s : ℂ)` has derivative `1`. -/
private lemma hasDerivAt_ofReal (t : ℝ) :
    HasDerivAt (fun s : ℝ => (s : ℂ)) 1 t := by
  simpa using Complex.ofRealCLM.hasDerivAt (x := t)

private lemma norm_phase_plus (t u : ℝ) :
    ‖Complex.exp (Complex.I * ((t : ℂ) / 2) * (u : ℂ))‖ = 1 := by
  rw [Complex.norm_exp]
  have hre : (Complex.I * ((t : ℂ) / 2) * (u : ℂ)).re = 0 := by
    simp [Complex.mul_re, Complex.mul_im, Complex.div_re, Complex.div_im]
  rw [hre, Real.exp_zero]

private lemma norm_phase_minus (t u : ℝ) :
    ‖Complex.exp (-(Complex.I * ((t : ℂ) / 2)) * (u : ℂ))‖ = 1 := by
  rw [Complex.norm_exp]
  have hre : (-(Complex.I * ((t : ℂ) / 2)) * (u : ℂ)).re = 0 := by
    simp [Complex.mul_re, Complex.mul_im, Complex.div_re, Complex.div_im]
  rw [hre, Real.exp_zero]

private lemma hasDerivAt_phase_plus (u t : ℝ) :
    HasDerivAt (fun s : ℝ => Complex.exp (Complex.I * ((s : ℂ) / 2) * (u : ℂ)))
      (Complex.exp (Complex.I * ((t : ℂ) / 2) * (u : ℂ))
        * (Complex.I * (u : ℂ) / 2)) t := by
  have hg : HasDerivAt (fun s : ℝ => Complex.I * ((s : ℂ) / 2) * (u : ℂ))
      (Complex.I * (u : ℂ) / 2) t := by
    have h3 := (((hasDerivAt_ofReal t).div_const (2 : ℂ)).const_mul
      (Complex.I)).mul_const (u : ℂ)
    convert h3 using 1
    ring
  exact hg.cexp

private lemma hasDerivAt_phase_minus (u t : ℝ) :
    HasDerivAt (fun s : ℝ => Complex.exp (-(Complex.I * ((s : ℂ) / 2)) * (u : ℂ)))
      (Complex.exp (-(Complex.I * ((t : ℂ) / 2)) * (u : ℂ))
        * (-(Complex.I * (u : ℂ)) / 2)) t := by
  have hg : HasDerivAt (fun s : ℝ => -(Complex.I * ((s : ℂ) / 2)) * (u : ℂ))
      (-(Complex.I * (u : ℂ)) / 2) t := by
    have h3 := ((((hasDerivAt_ofReal t).div_const (2 : ℂ)).const_mul
      (Complex.I)).neg).mul_const (u : ℂ)
    convert h3 using 1
    ring
  exact hg.cexp

/-! ## §4 — Measurability and integrability -/

private lemma aesm_F_plus'' :
    AEStronglyMeasurable F_plus'' (volume.restrict (Ioi (0 : ℝ))) :=
  (integrableOn_deriv_deriv_F_plus.congr_fun
    (fun u _ => by rw [deriv_F_plus_eq_F_plus', deriv_F_plus'_eq_F_plus''])
    measurableSet_Ioi).aestronglyMeasurable

private lemma aesm_F_minus'' :
    AEStronglyMeasurable F_minus'' (volume.restrict (Ioi (0 : ℝ))) :=
  (integrableOn_deriv_deriv_F_minus.congr_fun
    (fun u _ => by rw [deriv_F_minus_eq_F_minus', deriv_F_minus'_eq_F_minus''])
    measurableSet_Ioi).aestronglyMeasurable

private lemma integrableOn_cpx_plus (t : ℝ) :
    IntegrableOn (fun u : ℝ => ((F_plus'' u : ℝ) : ℂ)
      * Complex.exp (Complex.I * ((t : ℂ) / 2) * (u : ℂ))) (Ioi 0) volume := by
  have hc : (0 : ℝ) < π - 5 / 2 := by linarith [Real.pi_gt_three]
  have hg : IntegrableOn (fun u : ℝ => (81 * Real.exp (-π))
      * Real.exp (-(π - 5 / 2) * u)) (Ioi 0) volume :=
    (exp_neg_integrableOn_Ioi 0 hc).const_mul _
  refine Integrable.mono' hg ?_ ?_
  · exact (Complex.continuous_ofReal.comp_aestronglyMeasurable aesm_F_plus'').mul
      (Complex.continuous_exp.comp (by continuity)).aestronglyMeasurable
  · rw [ae_restrict_iff' (measurableSet_Ioi : MeasurableSet (Ioi (0 : ℝ)))]
    refine Filter.Eventually.of_forall (fun u hu => ?_)
    have hu0 : (0 : ℝ) ≤ u := le_of_lt (mem_Ioi.mp hu)
    rw [norm_mul, norm_phase_plus, mul_one, Complex.norm_real, Real.norm_eq_abs]
    calc |F_plus'' u| ≤ 81 * Real.exp (-π) * Real.exp (u * (5 / 2 - π)) :=
          abs_F_plus''_le hu0
      _ = 81 * Real.exp (-π) * Real.exp (-(π - 5 / 2) * u) := by ring_nf

private lemma integrableOn_cpx_minus (t : ℝ) :
    IntegrableOn (fun u : ℝ => ((F_minus'' u : ℝ) : ℂ)
      * Complex.exp (-(Complex.I * ((t : ℂ) / 2)) * (u : ℂ))) (Ioi 0) volume := by
  have hc : (0 : ℝ) < π - 2 := by linarith [Real.pi_gt_three]
  have hg : IntegrableOn (fun u : ℝ => (72 * Real.exp (-π))
      * Real.exp (-(π - 2) * u)) (Ioi 0) volume :=
    (exp_neg_integrableOn_Ioi 0 hc).const_mul _
  refine Integrable.mono' hg ?_ ?_
  · exact (Complex.continuous_ofReal.comp_aestronglyMeasurable aesm_F_minus'').mul
      (Complex.continuous_exp.comp (by continuity)).aestronglyMeasurable
  · rw [ae_restrict_iff' (measurableSet_Ioi : MeasurableSet (Ioi (0 : ℝ)))]
    refine Filter.Eventually.of_forall (fun u hu => ?_)
    have hu0 : (0 : ℝ) ≤ u := le_of_lt (mem_Ioi.mp hu)
    rw [norm_mul, norm_phase_minus, mul_one, Complex.norm_real, Real.norm_eq_abs]
    calc |F_minus'' u| ≤ 72 * Real.exp (-π) * Real.exp (u * (2 - π)) :=
          abs_F_minus''_le hu0
      _ = 72 * Real.exp (-π) * Real.exp (-(π - 2) * u) := by ring_nf

/-- Half-weighted plus bound: `(u/2)·F₊″`, with `∫ = ω(1)/2`. -/
private def bP (u : ℝ) : ℝ := u / 2 * F_plus'' u
/-- Half-weighted minus bound. -/
private def bM (u : ℝ) : ℝ := u / 2 * F_minus'' u
/-- The common dominating function for the differentiation step. -/
private def dBound (u : ℝ) : ℝ := bP u + bM u

private lemma integrableOn_bP : IntegrableOn bP (Ioi 0) volume := by
  refine (integrableOn_mul_F_plus''.const_mul (1 / 2 : ℝ)).congr_fun
    (fun u _ => ?_) measurableSet_Ioi
  simp only [bP]; ring

private lemma integrableOn_bM : IntegrableOn bM (Ioi 0) volume := by
  refine (integrableOn_mul_F_minus''.const_mul (1 / 2 : ℝ)).congr_fun
    (fun u _ => ?_) measurableSet_Ioi
  simp only [bM]; ring

private lemma integrableOn_dBound : IntegrableOn dBound (Ioi 0) volume :=
  integrableOn_bP.add integrableOn_bM

private lemma integral_bP_eq : ∫ u in Ioi (0 : ℝ), bP u = omega 1 / 2 := by
  have h : (∫ u in Ioi (0 : ℝ), bP u)
      = (1 / 2 : ℝ) * ∫ u in Ioi (0 : ℝ), u * F_plus'' u := by
    rw [← integral_const_mul]
    refine setIntegral_congr_fun measurableSet_Ioi (fun u _ => ?_)
    simp only [bP]; ring
  rw [h, integral_mul_F_plus''_eq]; ring

private lemma integral_bM_eq : ∫ u in Ioi (0 : ℝ), bM u = omega 1 / 2 := by
  have h : (∫ u in Ioi (0 : ℝ), bM u)
      = (1 / 2 : ℝ) * ∫ u in Ioi (0 : ℝ), u * F_minus'' u := by
    rw [← integral_const_mul]
    refine setIntegral_congr_fun measurableSet_Ioi (fun u _ => ?_)
    simp only [bM]; ring
  rw [h, integral_mul_F_minus''_eq]; ring

/-! ## §5 — Dominated differentiation of `Sp`, `Sm`, `Ssum` -/

/-- Derivative of the plus-side integral. -/
def Sp' (t : ℝ) : ℂ :=
  ∫ u in Ioi (0 : ℝ), ((F_plus'' u : ℝ) : ℂ)
    * (Complex.exp (Complex.I * ((t : ℂ) / 2) * (u : ℂ)) * (Complex.I * (u : ℂ) / 2))

/-- Derivative of the minus-side integral. -/
def Sm' (t : ℝ) : ℂ :=
  ∫ u in Ioi (0 : ℝ), ((F_minus'' u : ℝ) : ℂ)
    * (Complex.exp (-(Complex.I * ((t : ℂ) / 2)) * (u : ℂ))
        * (-(Complex.I * (u : ℂ)) / 2))

/-- `S′ = Sp′ + Sm′`. -/
def Ssum' (t : ℝ) : ℂ := Sp' t + Sm' t

/-- The tool returns integrability of the derivative integrand *and* the
derivative, so one application per side yields both. -/
private lemma dom_plus (t : ℝ) :
    IntegrableOn (fun u : ℝ => ((F_plus'' u : ℝ) : ℂ)
        * (Complex.exp (Complex.I * ((t : ℂ) / 2) * (u : ℂ))
            * (Complex.I * (u : ℂ) / 2))) (Ioi 0) volume
      ∧ HasDerivAt Sp (Sp' t) t := by
  refine hasDerivAt_integral_of_dominated_loc_of_deriv_le
    (ε := 1) (bound := dBound) (x₀ := t) one_pos
    (Filter.Eventually.of_forall
      (fun s => (integrableOn_cpx_plus s).aestronglyMeasurable))
    (integrableOn_cpx_plus t)
    ((Complex.continuous_ofReal.comp_aestronglyMeasurable aesm_F_plus'').mul
      ((Complex.continuous_exp.comp (by continuity)).mul
        (by continuity)).aestronglyMeasurable)
    ?_ integrableOn_dBound ?_
  · rw [ae_restrict_iff' (measurableSet_Ioi : MeasurableSet (Ioi (0 : ℝ)))]
    refine Filter.Eventually.of_forall (fun u hu => ?_)
    intro s _
    have hu0 : (0 : ℝ) < u := mem_Ioi.mp hu
    rw [norm_mul, norm_mul, norm_phase_plus, one_mul, Complex.norm_real,
      Real.norm_eq_abs]
    have hnI : ‖Complex.I * (u : ℂ) / 2‖ = u / 2 := by
      rw [norm_div, norm_mul, Complex.norm_I, one_mul, Complex.norm_real,
        Real.norm_eq_abs, abs_of_pos hu0]
      norm_num
    rw [hnI, abs_F_plus''_eq hu0.le]
    have hm : (0 : ℝ) ≤ u / 2 * F_minus'' u :=
      mul_nonneg (by linarith) (F_minus''_nonneg hu0.le)
    simp only [dBound, bP, bM]
    linarith
  · rw [ae_restrict_iff' (measurableSet_Ioi : MeasurableSet (Ioi (0 : ℝ)))]
    refine Filter.Eventually.of_forall (fun u _ => ?_)
    intro s _
    exact (hasDerivAt_phase_plus u s).const_mul _

private lemma dom_minus (t : ℝ) :
    IntegrableOn (fun u : ℝ => ((F_minus'' u : ℝ) : ℂ)
        * (Complex.exp (-(Complex.I * ((t : ℂ) / 2)) * (u : ℂ))
            * (-(Complex.I * (u : ℂ)) / 2))) (Ioi 0) volume
      ∧ HasDerivAt Sm (Sm' t) t := by
  refine hasDerivAt_integral_of_dominated_loc_of_deriv_le
    (ε := 1) (bound := dBound) (x₀ := t) one_pos
    (Filter.Eventually.of_forall
      (fun s => (integrableOn_cpx_minus s).aestronglyMeasurable))
    (integrableOn_cpx_minus t)
    ((Complex.continuous_ofReal.comp_aestronglyMeasurable aesm_F_minus'').mul
      ((Complex.continuous_exp.comp (by continuity)).mul
        (by continuity)).aestronglyMeasurable)
    ?_ integrableOn_dBound ?_
  · rw [ae_restrict_iff' (measurableSet_Ioi : MeasurableSet (Ioi (0 : ℝ)))]
    refine Filter.Eventually.of_forall (fun u hu => ?_)
    intro s _
    have hu0 : (0 : ℝ) < u := mem_Ioi.mp hu
    rw [norm_mul, norm_mul, norm_phase_minus, one_mul, Complex.norm_real,
      Real.norm_eq_abs]
    have hnI : ‖-(Complex.I * (u : ℂ)) / 2‖ = u / 2 := by
      rw [norm_div, norm_neg, norm_mul, Complex.norm_I, one_mul, Complex.norm_real,
        Real.norm_eq_abs, abs_of_pos hu0]
      norm_num
    rw [hnI, abs_F_minus''_eq hu0.le]
    have hp : (0 : ℝ) ≤ u / 2 * F_plus'' u :=
      mul_nonneg (by linarith) (F_plus''_nonneg hu0.le)
    simp only [dBound, bP, bM]
    linarith
  · rw [ae_restrict_iff' (measurableSet_Ioi : MeasurableSet (Ioi (0 : ℝ)))]
    refine Filter.Eventually.of_forall (fun u _ => ?_)
    intro s _
    exact (hasDerivAt_phase_minus u s).const_mul _

/-- **`HasDerivAt Ssum (Ssum′ t) t`.** -/
theorem hasDerivAt_Ssum (t : ℝ) : HasDerivAt Ssum (Ssum' t) t :=
  (dom_plus t).2.add (dom_minus t).2

/-- **`‖S′(t)‖ ≤ ω(1)`**, the weighted constant from `weighted_K_sum_eq`. -/
theorem norm_Ssum'_le (t : ℝ) : ‖Ssum' t‖ ≤ omega 1 := by
  have hp : ‖Sp' t‖ ≤ omega 1 / 2 := by
    have hb : ∀ᵐ u ∂(volume.restrict (Ioi (0 : ℝ))),
        ‖((F_plus'' u : ℝ) : ℂ)
          * (Complex.exp (Complex.I * ((t : ℂ) / 2) * (u : ℂ))
              * (Complex.I * (u : ℂ) / 2))‖ ≤ bP u := by
      rw [ae_restrict_iff' (measurableSet_Ioi : MeasurableSet (Ioi (0 : ℝ)))]
      refine Filter.Eventually.of_forall (fun u hu => ?_)
      have hu0 : (0 : ℝ) < u := mem_Ioi.mp hu
      rw [norm_mul, norm_mul, norm_phase_plus, one_mul, Complex.norm_real,
        Real.norm_eq_abs]
      have hnI : ‖Complex.I * (u : ℂ) / 2‖ = u / 2 := by
        rw [norm_div, norm_mul, Complex.norm_I, one_mul, Complex.norm_real,
          Real.norm_eq_abs, abs_of_pos hu0]
        norm_num
      rw [hnI, abs_F_plus''_eq hu0.le]
      simp only [bP]
    have h := norm_integral_le_of_norm_le integrableOn_bP hb
    rw [integral_bP_eq] at h
    exact h
  have hm : ‖Sm' t‖ ≤ omega 1 / 2 := by
    have hb : ∀ᵐ u ∂(volume.restrict (Ioi (0 : ℝ))),
        ‖((F_minus'' u : ℝ) : ℂ)
          * (Complex.exp (-(Complex.I * ((t : ℂ) / 2)) * (u : ℂ))
              * (-(Complex.I * (u : ℂ)) / 2))‖ ≤ bM u := by
      rw [ae_restrict_iff' (measurableSet_Ioi : MeasurableSet (Ioi (0 : ℝ)))]
      refine Filter.Eventually.of_forall (fun u hu => ?_)
      have hu0 : (0 : ℝ) < u := mem_Ioi.mp hu
      rw [norm_mul, norm_mul, norm_phase_minus, one_mul, Complex.norm_real,
        Real.norm_eq_abs]
      have hnI : ‖-(Complex.I * (u : ℂ)) / 2‖ = u / 2 := by
        rw [norm_div, norm_neg, norm_mul, Complex.norm_I, one_mul, Complex.norm_real,
          Real.norm_eq_abs, abs_of_pos hu0]
        norm_num
      rw [hnI, abs_F_minus''_eq hu0.le]
      simp only [bM]
    have h := norm_integral_le_of_norm_le integrableOn_bM hb
    rw [integral_bM_eq] at h
    exact h
  calc ‖Ssum' t‖ ≤ ‖Sp' t‖ + ‖Sm' t‖ := norm_add_le _ _
    _ ≤ omega 1 / 2 + omega 1 / 2 := add_le_add hp hm
    _ = omega 1 := by ring

/-! ## §6 — Real and imaginary parts of a real-parameter derivative -/

/-- `Re` of a `HasDerivAt` in a real parameter. `Complex.reCLM` is a
continuous ℝ-linear map, so it composes with the Fréchet derivative. -/
private lemma HasDerivAt.cre {f : ℝ → ℂ} {f' : ℂ} {t : ℝ} (h : HasDerivAt f f' t) :
    HasDerivAt (fun s : ℝ => (f s).re) f'.re t := by
  have h2 := (Complex.reCLM.hasFDerivAt.comp t h.hasFDerivAt).hasDerivAt
  simpa using h2

/-- `Im` of a `HasDerivAt` in a real parameter. -/
private lemma HasDerivAt.cim {f : ℝ → ℂ} {f' : ℂ} {t : ℝ} (h : HasDerivAt f f' t) :
    HasDerivAt (fun s : ℝ => (f s).im) f'.im t := by
  have h2 := (Complex.imCLM.hasFDerivAt.comp t h.hasFDerivAt).hasDerivAt
  simpa using h2

/-! ## §7 — ★ THE BOX-LOCAL BOUND ★ -/

/-- `edgeRe` is differentiable at every `t > 0`, with
`deriv edgeRe t = 2·Re S′ + (2/t)·Im S′ − (2/t²)·Im S`. -/
theorem hasDerivAt_edgeRe {t : ℝ} (ht : 0 < t) :
    HasDerivAt edgeRe
      (2 * (Ssum' t).re + (2 / t) * (Ssum' t).im
        - (2 / t ^ 2) * (Ssum t).im) t := by
  have htne : t ≠ 0 := ne_of_gt ht
  -- the three building blocks
  have hre : HasDerivAt (fun s : ℝ => (Ssum s).re) (Ssum' t).re t :=
    (hasDerivAt_Ssum t).cre
  have him : HasDerivAt (fun s : ℝ => (Ssum s).im) (Ssum' t).im t :=
    (hasDerivAt_Ssum t).cim
  have hinv : HasDerivAt (fun s : ℝ => 2 / s) (-(2 / t ^ 2)) t := by
    have h := (hasDerivAt_id t).const_div (c := (2 : ℝ)) htne
    convert h using 1
    field_simp
  -- assemble the derivative of  2*Re S + (2/t)*Im S
  have hsum := (hre.const_mul (2 : ℝ)).add (hinv.mul him)
  -- and transport it along `edgeRe = 2 Re S + (2/t) Im S` near `t`
  have hEq : ∀ᶠ s : ℝ in nhds t,
      edgeRe s = 2 * (Ssum s).re + (2 / s) * (Ssum s).im := by
    filter_upwards [eventually_ne_nhds htne] with s hs
    exact edgeRe_eq_Ssum hs
  refine (hsum.congr_of_eventuallyEq hEq.symm).congr_deriv ?_
  ring

/-- **★ `|deriv edgeRe t| ≤ 2ω(1)(1 + 1/t) + 1/(2t²)` for `t > 0` ★**

The three terms do not cancel (measured 1.0×–1.2×), so the plain triangle
inequality is already near-optimal here. -/
theorem abs_deriv_edgeRe_le {t : ℝ} (ht : 0 < t) :
    |deriv edgeRe t| ≤ 2 * omega 1 * (1 + 1 / t) + 1 / (2 * t ^ 2) := by
  rw [(hasDerivAt_edgeRe ht).deriv]
  have hS' := norm_Ssum'_le t
  have hS := norm_Ssum_le t
  have hre' : |(Ssum' t).re| ≤ omega 1 :=
    le_trans (Complex.abs_re_le_norm _) hS'
  have him' : |(Ssum' t).im| ≤ omega 1 :=
    le_trans (Complex.abs_im_le_norm _) hS'
  have him : |(Ssum t).im| ≤ 1 / 4 :=
    le_trans (Complex.abs_im_le_norm _) hS
  have htpos : (0 : ℝ) < 1 / t := by positivity
  have ht2 : (0 : ℝ) < 2 / t ^ 2 := by positivity
  have h1 : |2 * (Ssum' t).re| ≤ 2 * omega 1 := by
    rw [abs_mul, abs_of_nonneg (by norm_num : (0:ℝ) ≤ 2)]
    linarith
  have h2 : |(2 / t) * (Ssum' t).im| ≤ (2 / t) * omega 1 := by
    rw [abs_mul, abs_of_nonneg (by positivity : (0:ℝ) ≤ 2 / t)]
    have : (0 : ℝ) ≤ 2 / t := by positivity
    nlinarith [him']
  have h3 : |(2 / t ^ 2) * (Ssum t).im| ≤ (2 / t ^ 2) * (1 / 4) := by
    rw [abs_mul, abs_of_nonneg (by positivity : (0:ℝ) ≤ 2 / t ^ 2)]
    nlinarith [him]
  have hfin : (2 : ℝ) * omega 1 + (2 / t) * omega 1 + (2 / t ^ 2) * (1 / 4)
      = 2 * omega 1 * (1 + 1 / t) + 1 / (2 * t ^ 2) := by
    field_simp
    ring
  calc |2 * (Ssum' t).re + (2 / t) * (Ssum' t).im - (2 / t ^ 2) * (Ssum t).im|
      ≤ |2 * (Ssum' t).re| + |(2 / t) * (Ssum' t).im|
          + |(2 / t ^ 2) * (Ssum t).im| := by
        exact (abs_sub _ _).trans (by linarith [abs_add (2 * (Ssum' t).re)
          ((2 / t) * (Ssum' t).im)])
    _ ≤ 2 * omega 1 + (2 / t) * omega 1 + (2 / t ^ 2) * (1 / 4) := by linarith
    _ = 2 * omega 1 * (1 + 1 / t) + 1 / (2 * t ^ 2) := hfin

/-! ## §8 — The producer-facing form -/

/-- **`L₀`, the box-local Lipschitz constant as a rational function of `c`.**

`L₀ c = 2·ω(1)·(1 + 1/c) + 1/(2c²)`. Measured: `0.096–0.110` on `c ∈ [6.75, 13]`,
versus the uniform `L = 1` that Gate-2 proves. -/
def L0 (c : ℝ) : ℝ := 2 * omega 1 * (1 + 1 / c) + 1 / (2 * c ^ 2)

/-- **★ The hypothesis `R1_box_centered_of_lb` wants, with `L := L0 c` ★**

`∀ x ∈ Icc (c − r) (c + r), |deriv edgeRe x| ≤ L0 (c − r)`.

`L0` is decreasing in `c`, so its value at the *left* edge dominates the whole
box — which is why the producer passes `L0 (c − r)`. -/
theorem deriv_edgeRe_le_on_box {c r : ℝ} (hr : 0 ≤ r) (hc : r < c) :
    ∀ x ∈ Icc (c - r) (c + r), |deriv edgeRe x| ≤ L0 (c - r) := by
  intro x hx
  rw [mem_Icc] at hx
  have hxpos : (0 : ℝ) < x := by linarith [hx.1]
  have hlo : (0 : ℝ) < c - r := by linarith
  refine le_trans (abs_deriv_edgeRe_le hxpos) ?_
  -- L0 is decreasing: both 1/x and 1/x² shrink as x grows
  have hle : c - r ≤ x := hx.1
  have h1 : 1 / x ≤ 1 / (c - r) := by
    apply one_div_le_one_div_of_le hlo hle
  have h2 : 1 / (2 * x ^ 2) ≤ 1 / (2 * (c - r) ^ 2) := by
    apply one_div_le_one_div_of_le (by positivity)
    nlinarith [hlo.le, hle]
  have homega : (0 : ℝ) ≤ omega 1 := omega_nonneg 1
  simp only [L0]
  nlinarith [h1, h2, homega]

end

end DerivEdgeReLocalL20261020
end PrincipiaTractalis
