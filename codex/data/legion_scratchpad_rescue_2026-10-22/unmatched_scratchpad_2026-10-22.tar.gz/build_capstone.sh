#!/bin/bash
# Build the E91a1 rank capstone and the two of its dependencies that were only
# CHECKED (no -o) when they landed tonight, so have no olean.
#
# One flock acquisition for all three: they are small BSD modules, not panels,
# so the hold is comparable to a single march panel module (~7.5 min) and the
# per-module lock contract with the Acer YM session is respected in spirit.
set -u
export PATH="$HOME/.elan/bin:$PATH"
cd /Storage\ 2TB/home/xluxx/Principia-Fractalis-ACTIVE/PF_Lean4_Code || exit 1
LOG=/tmp/legion_capstone_build.log
: > "$LOG"
echo "[$(date +%H:%M:%S)] waiting for the shared lean lock" >> "$LOG"
flock -w 7200 /tmp/pf_lean_build.lock bash -c '
  export PATH="$HOME/.elan/bin:$PATH"
  echo "[$(date +%H:%M:%S)] lock acquired" >> '"$LOG"'
  taskset -c 0,1 lake build PF.E91a1RankOneCapstone_2026_10_22 >> '"$LOG"' 2>&1
  echo "RC=$?" >> '"$LOG"'
  echo "[$(date +%H:%M:%S)] lock released" >> '"$LOG"'
'
echo "DONE" >> "$LOG"
