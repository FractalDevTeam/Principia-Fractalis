#!/usr/bin/env python3
"""Fix a literal backslash-n printed by the self-test's final echo.

`echo "...record-count\n  guard..."` without -e prints the two characters
backslash and n. Pre-existing, but it is on a line this session rewrote, so it
gets fixed rather than propagated. Split into two echo calls instead of relying
on -e, which is not portable across sh implementations.
"""
import io
import os
import shutil
import sys

BS = chr(92)
SRC = ("/Storage 2TB/home/xluxx/Principia-Fractalis-ACTIVE/codex/"
       "ci_gate_selftest.sh")

OLD = ('  echo "SELFTEST PASSED: new logic rejects all 8 bad fixtures '
       '(4 by the record-count' + BS + 'n  guard, 4 by the axiom parser, '
       'one of those via a primed name) and accepts the clean one."')
NEW = ('  echo "SELFTEST PASSED: new logic rejects all 8 bad fixtures:"\n'
       '  echo "  4 by the record-count guard, 4 by the axiom parser '
       '(one of those"\n'
       '  echo "  reachable only via a primed declaration name), and it '
       'accepts the"\n'
       '  echo "  clean fixture."')

text = io.open(SRC, encoding="utf-8").read()
n = text.count(OLD)
if n != 1:
    print("REFUSING: anchor occurs %d times, expected 1" % n)
    sys.exit(1)

io.open(SRC + ".tmp", "w", encoding="utf-8", newline="\n").write(
    text.replace(OLD, NEW, 1))
shutil.copymode(SRC, SRC + ".tmp")
os.replace(SRC + ".tmp", SRC)
out = io.open(SRC, encoding="utf-8").read()
assert BS + "n  guard" not in out
print("fixed: literal backslash-n removed")
print("bash -n:", os.system("bash -n '%s'" % SRC) == 0)
