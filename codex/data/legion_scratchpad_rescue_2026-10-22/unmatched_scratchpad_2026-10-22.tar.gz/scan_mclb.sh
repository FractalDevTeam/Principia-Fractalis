#!/bin/bash
cd "C:/Users/psolo/AppData/Local/Temp/claude/C--Users-psolo/be22315a-596c-4f31-b184-3f681f009411/scratchpad"
: > mclb_scan.txt
for cc in 55/8 7 15/2 8 17/2 9 19/2 10 165/16 83/8 21/2; do
  v=$(PYTHONUTF8=1 PYTHONIOENCODING=utf-8 timeout 500 python gen_box.py --c "$cc" --r 1/256 --out /tmp/bt 2>&1 | grep "provable Mc_lb" | sed 's/.*= //')
  echo "$cc $v" >> mclb_scan.txt
done
echo DONE >> mclb_scan.txt
