#!/usr/bin/env python3
"""Projection of the gate-1 slack to c = 13/2, and a ranking of the levers.

Real constants (R1_c51_8_r1_16_pointwise_CLOSED_2026_10_16.lean:893-896):
    R_ub_h32 = 542831867/32000000000
    I_ub_h32 =  60314889/32000000000
    add-ons  = 231/279841 (residue) + 1/10^6 (analytic tail) + 1/10^4 (omega-gap)
Gate 1:  c^2 * R_ub_f + c * I_ub_f <= 3/4
"""
from fractions import Fraction as F
from mpmath import mp, mpf, mpc, pi, gamma, zeta, power

mp.dps = 40

R_ub_h32 = F(542831867, 32000000000)
I_ub_h32 = F(60314889, 32000000000)
RESID = F(231, 279841)
TAIL = F(1, 10 ** 6)
OMGAP = F(1, 10 ** 4)
ADDON = RESID + TAIL + OMGAP


def Lambda0(s):
    return power(pi, -s / 2) * gamma(s / 2) * zeta(s) + 1 / s + 1 / (1 - s)


def true_RI(c):
    L0 = Lambda0(mpc(1, mpf(c)))
    return L0.real, L0.imag


print("=" * 78)
print("1. reproduce the landed c = 51/8 slack from the REAL constants")
c = F(51, 8)
R_ub_f = R_ub_h32 + ADDON
I_ub_f = I_ub_h32 + ADDON
lhs = c ** 2 * R_ub_f + c * I_ub_f
print("   R_ub_h32 = %.10f   R_ub_f = %.10f" % (float(R_ub_h32), float(R_ub_f)))
print("   I_ub_h32 = %.10f   I_ub_f = %.10f" % (float(I_ub_h32), float(I_ub_f)))
print("   c^2*R_ub_f + c*I_ub_f = %.8f" % float(lhs))
print("   slack = 3/4 - that    = %+.8f      <-- Rio's reported +0.0050" % float(F(3, 4) - lhs))
print()
print("   NB the file's own section-0 comment (lines 62-63) states R_ub_f ~ 0.018418")
print("   and a product ~0.6909. Neither is consistent: 40.6406 x 0.018418 = %.4f,"
      % (float(c ** 2) * 0.018418))
print("   and 0.6909/40.6406 = %.6f. The CORRECT constants are at line 893." % (0.6909 / float(c ** 2)))
print("   -> section-0 of the landed file is numerically wrong. Header defect.")

print()
print("=" * 78)
print("2. enclosure quality achieved at c = 51/8 (panel width, excluding add-ons)")
Rt, It = true_RI("6.375")
wR = float(R_ub_h32) - float(Rt)
wI = float(I_ub_h32) - float(It)
print("   true  R = %.10f   R_ub_h32 - R_true = %.3e" % (float(Rt), wR))
print("   true  I = %.10f   I_ub_h32 - I_true = %.3e" % (float(It), wI))

print()
print("=" * 78)
print("3. PROJECTION to c = 13/2, assuming the SAME absolute panel widths")
print("   (optimistic: cos(cu/2) oscillates faster at larger c, so the real")
print("    width will be somewhat larger -- the true shortfall is >= this)")
c2 = F(13, 2)
Rt2, It2 = true_RI("6.5")
R_ub_h32_p = F(Rt2 + wR).limit_denominator(10 ** 12)
I_ub_h32_p = F(It2 + wI).limit_denominator(10 ** 12)
R_ub_f_p = R_ub_h32_p + ADDON
I_ub_f_p = I_ub_h32_p + ADDON
lhs2 = c2 ** 2 * R_ub_f_p + c2 * I_ub_f_p
print("   projected R_ub_f = %.10f ,  I_ub_f = %.10f" % (float(R_ub_f_p), float(I_ub_f_p)))
print("   c^2*R_ub_f + c*I_ub_f = %.8f   vs budget 0.75" % float(lhs2))
short = float(lhs2 - F(3, 4))
print("   => slack = %+.8f" % (-short))
print("   VERDICT: %s" % ("FAILS gate 1, shortfall %.5f" % short if short > 0 else "passes"))

print()
print("=" * 78)
print("4. LEVER RANKING -- what each add-on costs in the 0.75 budget at c = 13/2")
w = float(c2 ** 2) + float(c2)   # both R and I carry the same add-on
print("   weight (c^2 + c) = %.4f" % w)
for name, v in [("residue 231/279841", RESID), ("omega-gap 1/10^4", OMGAP),
                ("analytic tail 1/10^6", TAIL)]:
    print("   %-22s = %.3e   costs %.6f of the budget" % (name, float(v), w * float(v)))
print()
print("   needed recovery: %.6f" % short)
print("   - killing the analytic tail entirely buys %.6f  (negligible)" % (w * float(TAIL)))
print("   - killing the omega-gap entirely buys     %.6f  (%.0f%% of need)"
      % (w * float(OMGAP), 100 * w * float(OMGAP) / short))
print("   - the RESIDUE term alone costs            %.6f  (%.1fx the need)"
      % (w * float(RESID), w * float(RESID) / short))
print("   - panel narrowing required if used alone: dR_ub = %.3e (%.0f%% of current width %.3e)"
      % (short / float(c2 ** 2), 100 * (short / float(c2 ** 2)) / wR, wR))
print()
print("   => Rio's scoped levers (tail + omega-gap) together buy %.6f," % (w * float(TAIL + OMGAP)))
print("      which is %.0f%% of what is needed. The residue term is %.1fx the"
      % (100 * w * float(TAIL + OMGAP) / short, float(RESID) / float(OMGAP)))
print("      omega-gap and is where the room actually is; a ~%.0f%% panel"
      % (100 * (short / float(c2 ** 2)) / wR))
print("      narrowing would also do it on its own.")
