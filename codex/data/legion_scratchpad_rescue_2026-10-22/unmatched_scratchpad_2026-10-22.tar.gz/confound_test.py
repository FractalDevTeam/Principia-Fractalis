"""
Confound test for M_log^Re(E,X), the BSDRankSignBridge statistic.

PHASE READING (documented choice): the docstring says
    r_p = (1/sqrt p) * e^{i*pi*(3pi/4)*D_3(p)}
so the phase is  pi*alpha*D_3(p)  with alpha = 3pi/4, i.e. cos(3pi^2/4 * D_3(p)).
This LITERAL reading is used throughout below. It is also the only one of the two
candidate readings that reproduces the SIGNS of the file's published table
(the alternative, phase = alpha*D_3, inverts every sign).

RANK LABELS:
  rank>=1  is VERIFIED here: a rational point is found and shown non-torsion by
           super-exponential denominator growth under doubling (Mazur caps
           rational torsion order at 12, so growth past 12 doublings is decisive;
           we use growth itself, not Mazur).
  rank0?   means an exhaustive small search found NO non-torsion point. That is
           EVIDENCE, not proof -- a rank-1 curve can have a large generator.
Only the rank>=1 half needs to be sound for the KILL direction: a verified
rank>=1 curve with M > 0 falsifies the detector outright.
"""
import math
from fractions import Fraction as Fr

# ---------- curve arithmetic ----------
def invariants(a):
    a1,a2,a3,a4,a6 = a
    b2 = a1*a1 + 4*a2; b4 = 2*a4 + a1*a3; b6 = a3*a3 + 4*a6
    b8 = a1*a1*a6 + 4*a2*a6 - a1*a3*a4 + a2*a3*a3 - a4*a4
    D  = -b2*b2*b8 - 8*b4**3 - 27*b6*b6 + 9*b2*b4*b6
    return b2,b4,b6,b8,D

def on_curve(a, x, y):
    a1,a2,a3,a4,a6 = a
    return y*y + a1*x*y + a3*y == x**3 + a2*x*x + a4*x + a6

def negY(a, x, y):
    a1,a2,a3,a4,a6 = a
    return -y - a1*x - a3

def dbl(a, P):
    """double an affine point; None = identity"""
    if P is None: return None
    a1,a2,a3,a4,a6 = a
    x,y = P
    den = 2*y + a1*x + a3
    if den == 0: return None                     # 2-torsion
    lam = Fr(3*x*x + 2*a2*x + a4 - a1*y, 1) / den
    mu  = y - lam*x
    x3 = lam*lam + a1*lam - a2 - 2*x
    y3 = -(lam + a1)*x3 - mu - a3
    return (x3, y3)

def is_nontorsion(a, P, steps=14):
    """non-torsion iff the doubling orbit's denominators grow without returning to O"""
    Q = P
    dens = []
    for _ in range(steps):
        Q = dbl(a, Q)
        if Q is None: return False, dens
        dens.append(max(abs(Fr(Q[0]).denominator), 1))
    return (dens[-1] > 10**6 and dens[-1] > dens[0]), dens

def find_point(a, xb=12, vb=6):
    """search small rational x = u/v for a point on the curve"""
    a1,a2,a3,a4,a6 = a
    out = []
    for v in range(1, vb+1):
        for u in range(-xb*v, xb*v+1):
            x = Fr(u, v)
            # solve y^2 + (a1 x + a3) y - (x^3+a2x^2+a4x+a6) = 0
            B = a1*x + a3
            C = -(x**3 + a2*x*x + a4*x + a6)
            disc = B*B - 4*C
            if disc < 0: continue
            n, d = disc.numerator, disc.denominator
            rn = math.isqrt(n) if n >= 0 else -1
            rd = math.isqrt(d)
            if rn < 0 or rn*rn != n or rd*rd != d: continue
            s = Fr(rn, rd)
            for y in ((-B + s)/2, (-B - s)/2):
                if on_curve(a, x, y):
                    out.append((x, y))
    return out

# ---------- a_p and the statistic ----------
def primes_upto(n):
    s = bytearray([1])*(n+1); s[0]=s[1]=0
    for i in range(2,int(n**0.5)+1):
        if s[i]: s[i*i::i] = bytearray(len(s[i*i::i]))
    return [i for i in range(n+1) if s[i]]

PR = primes_upto(2000)

def legendre(x,p):
    x %= p
    return 0 if x==0 else (1 if pow(x,(p-1)//2,p)==1 else -1)

def a_p(a, p):
    b2,b4,b6,b8,D = invariants(a)
    s = 0
    for x in range(p):
        s += legendre((4*x*x*x + b2*x*x + 2*b4*x + b6) % p, p)
    return -s

def D3(n):
    s=0
    while n: s += n%3; n//=3
    return s

ALPHA = 3*math.pi/4
_W = {p: math.cos(math.pi*ALPHA*D3(p))/math.sqrt(p) for p in PR}

def M_stat(a, X=2000):
    b2,b4,b6,b8,D = invariants(a)
    tot = 0.0
    for p in PR:
        if p > X: break
        if p == 2 or D % p == 0: continue       # good primes only, p odd
        tot += a_p(a, p) * _W[p] * math.log(p) / p
    return -tot / math.log(X)

# ---------- build the two groups ----------
print("building curve set (small integer models, grouped by |Delta| scale)...")
cands = []
for a1 in (0,1):
    for a2 in (-1,0,1):
        for a3 in (0,1):
            for a4 in range(-9,10):
                for a6 in range(-9,10):
                    a = (a1,a2,a3,a4,a6)
                    b2,b4,b6,b8,D = invariants(a)
                    if D == 0: continue
                    cands.append((a, abs(D)))

rank1, rank0 = [], []
seen = set()
for a, absD in sorted(cands, key=lambda t: t[1]):
    if len(rank1) >= 12 and len(rank0) >= 12: break
    key = a
    if key in seen: continue
    seen.add(key)
    pts = find_point(a)
    nt = None
    for P in pts:
        ok, dens = is_nontorsion(a, P)
        if ok:
            nt = (P, dens[-1]); break
    if nt and len(rank1) < 12:
        rank1.append((a, absD, nt))
    elif (not pts or nt is None) and len(rank0) < 12:
        rank0.append((a, absD))

print("  verified rank>=1 curves: %d    candidate rank0 curves: %d" % (len(rank1), len(rank0)))
print()
print("=== GROUP A — rank >= 1, VERIFIED by non-torsion point (denominator growth) ===")
print("  a-invariants             |Delta|     generator          den(2^14 P)      M_log^Re")
resA = []
for a, absD, (P, dlast) in rank1:
    M = M_stat(a); resA.append((a, absD, M))
    print("  %-24s %-11d (%s,%s)%s %-16s %+0.6f"
          % (str(a), absD, P[0], P[1], " "*max(1,14-len("(%s,%s)"%(P[0],P[1]))),
             ("%.2e" % dlast), M))

print()
print("=== GROUP B — candidate rank 0 (no non-torsion point found in search) ===")
print("  a-invariants             |Delta|     M_log^Re")
resB = []
for a, absD in rank0:
    M = M_stat(a); resB.append((a, absD, M))
    print("  %-24s %-11d %+0.6f" % (str(a), absD, M))

print()
print("=== SIGN TABLE ===")
posA = [m for _,_,m in resA if m > 0]; negA = [m for _,_,m in resA if m < 0]
posB = [m for _,_,m in resB if m > 0]; negB = [m for _,_,m in resB if m < 0]
print("  rank>=1 (VERIFIED):   %d curves,  M<0: %d   M>0: %d   <-- M>0 here FALSIFIES the detector"
      % (len(resA), len(negA), len(posA)))
print("  rank0 candidates:     %d curves,  M>0: %d   M<0: %d" % (len(resB), len(posB), len(negB)))
if resA: print("  rank>=1 range: %+0.6f .. %+0.6f" % (min(m for _,_,m in resA), max(m for _,_,m in resA)))
if resB: print("  rank0   range: %+0.6f .. %+0.6f" % (min(m for _,_,m in resB), max(m for _,_,m in resB)))
print()
if posA:
    print("  VERDICT: DETECTOR FALSIFIED — %d verified rank>=1 curves have M > 0." % len(posA))
    for a, absD, m in resA:
        if m > 0: print("     %s  |Delta|=%d  M=%+0.6f" % (str(a), absD, m))
else:
    print("  VERDICT: no verified rank>=1 curve has M > 0 on this sample.")
if negB:
    print("  Also: %d candidate-rank-0 curves have M < 0 (suggestive, not decisive)." % len(negB))
    for a, absD, m in resB:
        if m < 0: print("     %s  |Delta|=%d  M=%+0.6f" % (str(a), absD, m))
