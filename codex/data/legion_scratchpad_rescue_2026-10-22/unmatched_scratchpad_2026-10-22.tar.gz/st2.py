#!/usr/bin/env python3
"""Add full-size fixtures so the AXIOM PARSER is what fires, not the
MIN_RECORDS guard. Without these the self-test passes for the wrong reason."""
import io

p = "/tmp/ci_gate_selftest.sh"
s = io.open(p, encoding="utf-8").read()

old = """cat > "${TMP}/E_good.txt" <<'EOF'"""
new = """# Full-size variants: 4 records, one of which carries a violation. These
# make the AXIOM CHECK the thing that fires, rather than the MIN_RECORDS
# guard -- without them this self-test would pass for the wrong reason.
cat > "${TMP}/B4_oneline.txt" <<'EOF'
'PF.t1' depends on axioms: [propext, Classical.choice, Quot.sound]
'PF.t2' depends on axioms: [propext, Classical.choice, Quot.sound]
'PF.t3' depends on axioms: [propext, Classical.choice, Quot.sound]
'PF.bad' depends on axioms: [propext, Classical.choice, myProjectAxiom, Quot.sound]
EOF

cat > "${TMP}/C4_wrapped.txt" <<'EOF'
'PF.t1' depends on axioms: [propext, Classical.choice, Quot.sound]
'PF.t2' depends on axioms: [propext, Classical.choice, Quot.sound]
'PF.t3' depends on axioms: [propext, Classical.choice, Quot.sound]
'PF.bad' depends on axioms: [propext,
 Classical.choice,
 myProjectAxiom,
 Quot.sound]
EOF

cat > "${TMP}/D4_sorry.txt" <<'EOF'
'PF.t1' depends on axioms: [propext, Classical.choice, Quot.sound]
'PF.t2' depends on axioms: [propext, Classical.choice, Quot.sound]
'PF.t3' depends on axioms: [propext, Classical.choice, Quot.sound]
'PF.broken' depends on axioms: [propext,
 sorryAx,
 Quot.sound]
EOF

cat > "${TMP}/E_good.txt" <<'EOF'"""
assert s.count(old) == 1
s = s.replace(old, new, 1)

old_runs = """check "${TMP}/E_good.txt"    "E clean, 4 records"            accept"""
new_runs = """check "${TMP}/B4_oneline.txt" "B4 violation, 4 recs, 1 line"  reject
check "${TMP}/C4_wrapped.txt" "C4 violation, 4 recs, wrapped" reject
check "${TMP}/D4_sorry.txt"   "D4 sorryAx, 4 recs, wrapped"   reject
check "${TMP}/E_good.txt"    "E clean, 4 records"            accept"""
assert s.count(old_runs) == 1
s = s.replace(old_runs, new_runs, 1)

io.open(p, "w", encoding="utf-8").write(s)
print("added 3 full-size fixtures")
