#!/usr/bin/env python3
"""
STEP 1, exact: price the panel-density ladder for the march to c = 13.

NO MODEL. This computes the producer's own quantities at parametric density,
using the shipped interval arithmetic verbatim:

    R_ub(c, D) = sum_seg sum_{k=1..8D} ( h * U_node_plus(m_k) + err_seg/2 )
    I_ub(c, D) = ... same with U_node_minus ...
    h = 1/(32 D),   err_seg = M_seg(c, T_seg) * h^3 / 24
    gate = c^2 (R_ub + ADDON) + c (I_ub + ADDON)
    Mc_lb = (1 - gate) / 2            [gen_box.py line 549]
    box criterion: L0(c - r) * r < Mc_lb

exactly as gen_box.py lines 466-467, 540-549 do it at D = 1.

Two facts established before this was written, not assumed:

(a) The midpoint panel width is pure truncation error. Node bounds are
    outward-rounded to 10 digits (~1e-10), while err = M h^3/24 is ~1e-5 per
    panel, so the enclosure is err-dominated by five orders of magnitude and
    therefore scales as EXACTLY 1/D^2. Checked against the shipped widths:
    seg1-2 M=24 -> 24/98304 = 2.4414e-4, seg3-4 M=30 -> 3.0518e-4,
    seg5-6 M=72 -> 7.3242e-4, all matching the measured table.

(b) D must be a POWER OF 2. err = M h^3/24 = M/(2^18 * 3 * D^3) must be a
    terminating decimal for the emitted Lean literal (gen_box.dec), which with
    M a multiple of 3 needs D to be 2-5 smooth; and the panel endpoints must
    stay dyadic. Powers of two satisfy both. So the ladder is over
    D in {1, 2, 4, 8, 16, 32}, not over every integer.

All six segments go midpoint: the shipped hybrid's range-brick segments 3-6
scale only as 1/D, so on a mixed scheme the h^1 part dominates any real
tightening. All-midpoint is 2.8x worse at D = 1 and wins from D = 2 on.
"""
import io
import os
import sys
from fractions import Fraction as F

import mpmath as mp

HERE = os.path.dirname(os.path.abspath(__file__))
RG = os.path.join(HERE, "gen", "gen_fourier_panels_c27_4.py")

_g = {"__name__": "_g", "__file__": RG}
exec(compile(io.open(RG, encoding="utf-8").read(), RG, "exec"), _g)

I = _g["I"]
exp_pos_interval = _g["exp_pos_interval"]
cos_interval = _g["cos_interval"]
sin_interval = _g["sin_interval"]
omega_N3_interval = _g["omega_N3_interval"]
SEGMENTS = _g["SEGMENTS"]

ST = 50
ADDON = F(7, 10**7) + F(12, 10**8) + F(1, 10**21)      # gen_box.py line 100
OMEGA1 = F(4321741, 10**8)                              # gen_box.py line 103
PI_UB = F(4)
B_UB = {n: F(1, 23) ** ((n + 1) ** 2) for n in range(3)}


def L0_val(c):
    return 2 * OMEGA1 * (1 + 1 / F(c)) + 1 / (2 * F(c) ** 2)


# --- the three M tiers, exactly as gen_fourier_panels_..._midpoint.py doc'd --
#   Tier A (T <= 1/2): E <= 2, expT <= 2     Tier B (T <= 1): E <= 2, expT <= 3
#   Tier C (T <= 3/2): E <= 3, expT <= 9
def tier(T):
    if T <= F(1, 2):
        return F(2), F(2)
    if T <= F(1):
        return F(2), F(3)
    return F(3), F(9)


def termM_coarse(c, n, T):
    """gen_box.termM_coarse, with the tier constants made T-dependent."""
    A = PI_UB * (n + 1) ** 2
    E, Th = tier(T)
    B, G = B_UB[n], abs(F(c)) / 2
    return (E / 4 * (2 * B)
            + (E + 1) * (2 * A * (A * Th - 1) * B)
            + (E + 1) * (2 * B) * G ** 2
            + 2 * (E / 2) * (2 * A * B)
            + 2 * (E / 2) * (2 * B) * G
            + 2 * (E + 1) * (2 * A * B) * G)


def M_of(c, T):
    """Least multiple of 3 >= the summed per-n integer targets (gen_box.m_data)."""
    s = sum(int(termM_coarse(c, n, T)) + 1 for n in range(3))
    return s + (-s) % 3


# --- node upper bounds at a single point, shipped primitives ---------------
_cache = {}


def node_ub(m, c_half):
    """(U_node_plus, U_node_minus) at the point m. Same composition as the
    midpoint generator's point_bounds, with c_half explicit."""
    key = (m, c_half)
    if key in _cache:
        return _cache[key]
    mi = I(m, m)
    exp_u = exp_pos_interval(mi, series_terms=ST)
    hi = I(m * F(1, 2), m * F(1, 2))
    E = exp_pos_interval(hi, series_terms=ST)
    om = omega_N3_interval(exp_u, series_terms=ST)
    Fp = (E * om).rounded()
    Fm = om
    cu = I(c_half * m, c_half * m)
    cos_cu = cos_interval(cu, series_terms=ST)
    sin_cu = sin_interval(cu, series_terms=ST)
    R = ((Fp + Fm) * cos_cu).rounded()
    S = ((Fp - Fm) * sin_cu).rounded()
    _cache[key] = (R.hi, S.hi)
    return _cache[key]


def enclosure(c, D):
    """(R_ub, I_ub) all-midpoint at density D, producer-exact."""
    c_half = F(c) / 2
    h = F(1, 32 * D)
    Rub = Iub = F(0)
    for seg in range(1, 7):
        lo, hi = SEGMENTS[seg]
        T = hi
        M = M_of(c, T)
        err = F(M) * h ** 3 / 24
        n = 8 * D
        assert (hi - lo) == n * h, f"seg {seg}: {hi-lo} != {n}*{h}"
        for k in range(n):
            a = lo + k * h
            m = a + h / 2
            up, um = node_ub(m, c_half)
            Rub += h * F(up) + err / 2
            Iub += h * F(um) + err / 2
    return Rub, Iub


def mc_lb(c, D):
    Rub, Iub = enclosure(c, D)
    gate = F(c) ** 2 * (Rub + ADDON) + F(c) * (Iub + ADDON)
    return (F(1) - gate) / 2


DLAD = [1, 2, 4, 8, 16, 32]
RLAD = [F(1, 2 ** k) for k in range(4, 13)]
SAFETY = F(5, 4)
MIN_PER_MODULE = 7.5      # measured: ~7m30s, <=7.6 GB, 8 panels/module


# ---------------------------------------------------------------------------
if __name__ == "__main__":
    # (0) validate the tier M against the shipped constants at c = 27/4
    print("validate M tiers at c = 27/4 (shipped: seg1-2 = 24, seg3-4 = 30, "
          "seg5-6 = 72):")
    for seg in range(1, 7):
        T = SEGMENTS[seg][1]
        print(f"   seg{seg}  T = {str(T):>4}   M = {M_of(F(27,4), T)}")
    print()

    # (1) the D = 1 cross-check against the producer's measured Mc_lb
    print("cross-check vs producer-measured Mc_lb (hybrid, codex/mclb_scan.txt):")
    print(f"{'c':>8} {'all-mid D=1':>14} {'all-mid D=2':>14} {'hybrid (meas)':>14}")
    MEAS = {F(55, 8): 0.14684818, F(8): 0.08528181, F(10): 0.00751429}
    for c, mv in MEAS.items():
        print(f"{str(c):>8} {float(mc_lb(c,1)):>14.8f} {float(mc_lb(c,2)):>14.8f}"
              f" {mv:>14.8f}")
    print()

    # (2) the ladder: walk the frontier, choose (r, D) minimising cost/advance
    print("=" * 94)
    print("DENSITY LADDER TO c = 13  (all-midpoint; 6D modules of 8 panels, "
          "~7m30s each, serial)")
    print("=" * 94)
    f = F(109, 16)
    boxes = []
    while f < 13 and len(boxes) < 400:
        best = None
        for r in RLAD:
            c = f + r
            if c > 13 + r or r >= c:
                continue
            for D in DLAD:
                m = mc_lb(c, D)
                lr = L0_val(c - r) * r
                if m <= 0 or not (lr * SAFETY < m):
                    continue
                cost = 6 * D * MIN_PER_MODULE
                key = cost / (2.0 * float(r))
                if best is None or key < best[0]:
                    best = (key, c, r, D, m, lr, cost)
                break                      # smallest D that works at this r
        if best is None:
            print(f"  STOP: no (r, D) in the ladders works at frontier "
                  f"{float(f):.6f}")
            break
        _, c, r, D, m, lr, cost = best
        boxes.append((c, r, D, m, lr, cost))
        f = c + r
    print(f"{'#':>4} {'centre c':>11} {'r':>9} {'D':>4} {'Mc_lb':>12}"
          f" {'L0*r':>11} {'ratio':>7} {'mods':>6} {'hours':>7}")
    tot_h = 0.0
    tot_mod = 0
    for i, (c, r, D, m, lr, cost) in enumerate(boxes, 1):
        tot_h += cost / 60.0
        tot_mod += 6 * D
        if i <= 8 or i > len(boxes) - 8:
            print(f"{i:>4} {str(c):>11} {str(r):>9} {D:>4} {float(m):>12.8f}"
                  f" {float(lr):>11.8f} {float(m/lr):>6.1f}x {6*D:>6}"
                  f" {cost/60.0:>7.2f}")
        elif i == 9:
            print(f"{'':>4} {'...':>11}")
    print("-" * 94)
    print(f"  {len(boxes)} boxes, frontier {float(f):.6f}"
          f"  {'REACHED 13' if f >= 13 else 'STOPPED SHORT'}")
    print(f"  {tot_mod} panel modules, {tot_h:.1f} h serial "
          f"({tot_h/24:.1f} days continuous)")
    print()
    grp = {}
    for c, r, D, m, lr, cost in boxes:
        grp.setdefault(D, []).append(float(c))
    print("  density ladder in c:")
    for D in sorted(grp):
        cs = grp[D]
        print(f"    D = {D:>2}  ({D}x panels, {6*D} modules, "
              f"{6*D*MIN_PER_MODULE/60:.1f} h/box) : {len(cs):>3} boxes, "
              f"c in [{min(cs):.4f}, {max(cs):.4f}]")
    print()
    print(f"  vs Rio's ~6 h x boxes: {len(boxes)} boxes x 6 h = "
          f"{len(boxes)*6} h; ladder = {tot_h:.0f} h "
          f"({tot_h/(len(boxes)*6):.2f}x of it)")
