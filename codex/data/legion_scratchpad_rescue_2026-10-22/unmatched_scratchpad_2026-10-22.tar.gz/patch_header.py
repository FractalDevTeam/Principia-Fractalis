#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Update the pilot header's worked arithmetic to the new add-on constants, and
add a dated provenance note. This file has a documented history of the comment
drifting from the constants the proof uses (its own NOTE 2026-10-16), so the
comment is recomputed exactly from the rationals rather than edited by hand.
"""
import io
from fractions import Fraction as F

P = ("/Storage 2TB/home/xluxx/Principia-Fractalis-ACTIVE/PF_Lean4_Code/"
     "PF/Analytic/PilotBoxes/R1_c13_2_r1_16_pointwise_CLOSED_2026_10_16.lean")
s = io.open(P, encoding="utf-8").read()

R = F(1339441331, 80000000000)
I = F(302372667, 160000000000)
A = F(231, 10**6) + F(12, 10**8) + F(1, 10**21)
Rf, If = R + A, I + A
t1, t2 = F(169, 4) * Rf, F(13, 2) * If
lhs = t1 + t2
margin = F(3, 4) - lhs


def d(x, n=10):
    return f"{float(x):.{n}f}"


old = """  R_ub_f ≈ 0.0167430166 + 0.000332 ≈ 0.0170750166
  I_ub_f ≈ 0.0018898292 + 0.000332 ≈ 0.0022218292
  (169/4)·0.0170750166 + (13/2)·0.0022218292
      ≈ 0.7214194 + 0.0144419 ≈ 0.7358614 ≤ 0.75 ✓   (slack ≈ +0.0141386)"""
new = f"""  R_ub_f ≈ {d(R)} + 0.00023112 ≈ {d(Rf)}
  I_ub_f ≈ {d(I)} + 0.00023112 ≈ {d(If)}
  (169/4)·{d(Rf)} + (13/2)·{d(If)}
      ≈ {d(t1, 7)} + {d(t2, 7)} ≈ {d(lhs, 7)} ≤ 0.75 ✓   (slack ≈ +{d(margin, 7)})"""
assert s.count(old) == 1, "header arithmetic block not matched verbatim"
s = s.replace(old, new, 1)

anchor = """constants above (`231/10⁶` residue). Margin is `+0.01414`, not `+0.0050`."""
add = anchor + f"""
2026-10-18 (Legion): the two one-line add-on tightenings from the add-on
scoping (`codex/ADDON_SCOPE_RESIDUE_IS_THE_WORK_2026-10-17.md`, commit
4d5c26de) are now applied. `epsOm` 1/10⁴ → 1/10²¹ (the ω-gap chain already
PROVED 4.3790e−22 and was discarding 2.284e17× of it in its final `norm_num`);
analytic tail 1/10⁶ → 12/10⁸ (the chain already PROVED 1.1326e−7 — note 1/10⁷
is NOT reachable, 1.2e−7 is). No new mathematics: only the two `norm_num`
targets changed. Add-on total 3.3200e−4 → 2.3112e−4, and the Gate-1 margin
improves from +0.0141387 to +{d(margin, 7)} (gain +{float(margin) - 0.0141387:.7f}).
The residue `231/10⁶` is now 99.9% of the remaining add-on total; subdividing
it is the next lever (see that note's `ln k` design)."""
assert s.count(anchor) == 1, "provenance anchor not found"
s = s.replace(anchor, add, 1)

io.open(P, "w", encoding="utf-8").write(s)
print("header arithmetic recomputed and provenance note added")
print(f"  lhs    = {d(lhs, 12)}")
print(f"  margin = +{d(margin, 12)}")
