#!/bin/bash
# Bring the two already-landed boxes (c = 7, 57/8) onto the parameterised route,
# so the tree has no boxes proved through a route the producer no longer emits.
# Same theorems either way -- their old-shape margins are +0.0273 and +0.0128,
# so the superseded route genuinely closed there. This doubles as a regression
# check on the rewiring, at centres where BOTH routes are valid.
#
# Only the assemble and the two pilots change; the panels are untouched.
set -u
exec 9>/tmp/pf_lean_build.lock
if ! flock -n 9; then echo "LOCKED" > /tmp/uni_status; exit 1; fi
export PATH="$HOME/.elan/bin:$PATH"
REPO="/Storage 2TB/home/xluxx/Principia-Fractalis-ACTIVE"
cd "$REPO/PF_Lean4_Code" || exit 1
FP=".lake/build/lib/lean/PF/Analytic/FourierPanels"
PB=".lake/build/lib/lean/PF/Analytic/PilotBoxes"
: > /tmp/uni_progress; echo RUNNING > /tmp/uni_status

for C in 7 57/8; do
  TAG="c$(echo "$C" | tr '/' '_')"
  O=$(mktemp -d /tmp/uni.XXXXXX)
  (cd /tmp/prod && python3 gen_box.py --c "$C" --r 1/16 --out "$O" \
      --work "$(mktemp -d /tmp/uniw.XXXXXX)" > "/tmp/uni_${TAG}_gen.log" 2>&1) \
    || { echo "FAILED generate $C" > /tmp/uni_status; exit 1; }
  # sanity: the panels must NOT have changed
  for f in "$O"/Seg*.lean "$O"/CoreDefs_*.lean "$O"/Residue*.lean \
           "$O"/AnalyticTail*.lean "$O"/OmegaTail*.lean; do
    b=$(basename "$f")
    diff -q "$f" "PF/Analytic/FourierPanels/$b" >/dev/null 2>&1 || {
      echo "FAILED $C: panel $b changed unexpectedly" > /tmp/uni_status; exit 1; }
  done
  cp "$O/Assemble_${TAG}_threehalves_HYBRID_2026_10_20.lean" PF/Analytic/FourierPanels/
  cp "$O/R1_${TAG}_r1_16_HYBRID_2026_10_20.lean" PF/Analytic/PilotBoxes/
  cp "$O/R1_${TAG}_r1_16_pointwise_UNCONDITIONAL_2026_10_20.lean" PF/Analytic/PilotBoxes/

  r3() { taskset -c 0,1 lake env lean ${3:+-o "$3"} "$2" > "/tmp/uni_${TAG}_$1.log" 2>&1
         rc=$?; echo "$TAG $1 rc=$rc $(date +%H:%M:%S)" >> /tmp/uni_progress
         [ $rc -ne 0 ] && { echo "FAILED $TAG $1" > /tmp/uni_status; exit 1; }; }
  r3 asm "PF/Analytic/FourierPanels/Assemble_${TAG}_threehalves_HYBRID_2026_10_20.lean" \
         "$FP/Assemble_${TAG}_threehalves_HYBRID_2026_10_20.olean"
  r3 gate "PF/Analytic/PilotBoxes/R1_${TAG}_r1_16_HYBRID_2026_10_20.lean" \
          "$PB/R1_${TAG}_r1_16_HYBRID_2026_10_20.olean"
  r3 uncond "PF/Analytic/PilotBoxes/R1_${TAG}_r1_16_pointwise_UNCONDITIONAL_2026_10_20.lean" ""
  U="/tmp/uni_${TAG}_uncond.log"
  grep -qE "sorryAx|nativeDecide|ofReduceBool" "$U" && {
    echo "FAILED $TAG axiom bar" > /tmp/uni_status; exit 1; }
  SETS=$(tr '\n' ' ' < "$U" | grep -oE "axioms: \[[^]]*\]" | tr -s ' ' | sort -u)
  [ "$SETS" = "axioms: [propext, Classical.choice, Quot.sound]" ] || {
    echo "FAILED $TAG axiom sets: $SETS" > /tmp/uni_status; exit 1; }
  echo "$TAG axiom-bar OK: $(grep -c 'depends on axioms' "$U") theorems" >> /tmp/uni_progress
  grep -c "R1_box_centered_of_lb\|Mc_lb := 1/8" \
    "PF/Analytic/PilotBoxes/R1_${TAG}_r1_16_HYBRID_2026_10_20.lean" \
    | grep -q '^0$' || { echo "FAILED $TAG: old shape survived" > /tmp/uni_status; exit 1; }
  echo "$TAG old-shape check OK (0 occurrences)" >> /tmp/uni_progress
done
echo "DONE" > /tmp/uni_status
