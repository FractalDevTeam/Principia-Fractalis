"""
Confound test for M_log^Re(E,X) -- the BSDRankSignBridge statistic.  v2.

PHASE READING (documented): docstring says r_p = (1/sqrt p) e^{i*pi*(3pi/4)*D_3(p)},
so phase = pi*alpha*D_3(p) with alpha = 3pi/4, i.e. cos(3pi^2/4 * D_3(p)).
This LITERAL reading is used. It is the only one of the two candidate readings
that reproduces the SIGNS of the file's published table; the alternative
(phase = alpha*D_3) inverts every sign.

GROUP A (rank >= 1): the corpus's OWN cohort -- each has a kernel-clean
  `_rank_ge_one` theorem in the repo (r134-r144). Ranks are corpus-verified,
  not asserted here.
GROUP B (rank 0 candidates): no non-torsion point found by bounded search
  (x = u/v, |u| <= 8v, v <= 4; non-torsion = strict denominator growth over
  <= 4 doublings). This is EVIDENCE of rank 0, not proof.

KILL DIRECTION: only group A needs to be sound. A corpus-verified rank>=1
curve with M > 0 falsifies the detector outright.
"""
import math
from fractions import Fraction as Fr

# ---- Group A: corpus cohort, coefficients verbatim from the Lean defs ----
RANK1 = [
    ("37a1",  (0,0,1,-1,0)), ("43a1",  (0,1,1,0,0)),  ("53a1",  (1,-1,1,0,0)),
    ("61a1",  (1,0,0,-2,1)), ("79a1",  (1,1,1,-2,0)), ("83a1",  (1,1,1,1,0)),
    ("89a1",  (1,1,1,-1,0)), ("101a1", (0,1,1,-1,-1)),("106a1", (1,1,0,-7,5)),
]

def inv(a):
    a1,a2,a3,a4,a6 = a
    b2=a1*a1+4*a2; b4=2*a4+a1*a3; b6=a3*a3+4*a6
    b8=a1*a1*a6+4*a2*a6-a1*a3*a4+a2*a3*a3-a4*a4
    D=-b2*b2*b8-8*b4**3-27*b6*b6+9*b2*b4*b6
    return b2,b4,b6,b8,D

def on_curve(a,x,y):
    a1,a2,a3,a4,a6=a
    return y*y+a1*x*y+a3*y == x**3+a2*x*x+a4*x+a6

def dbl(a,P):
    if P is None: return None
    a1,a2,a3,a4,a6=a; x,y=P
    den = 2*y+a1*x+a3
    if den==0: return None
    lam=(3*x*x+2*a2*x+a4-a1*y)/den
    mu=y-lam*x
    x3=lam*lam+a1*lam-a2-2*x
    return (x3, -(lam+a1)*x3-mu-a3)

def nontorsion(a,P,steps=4,cap=10**8):
    """strict denominator growth under doubling; early exit once large"""
    Q=P; prev=Fr(P[0]).denominator
    for _ in range(steps):
        Q=dbl(a,Q)
        if Q is None: return False
        d=Fr(Q[0]).denominator
        if d>cap and d>prev: return True
        if d<=prev: return False
        prev=d
    return prev>10**4

def find_points(a,xb=8,vb=4):
    a1,a2,a3,a4,a6=a; out=[]
    for v in range(1,vb+1):
        for u in range(-xb*v,xb*v+1):
            if math.gcd(abs(u),v)!=1: continue
            x=Fr(u,v); B=a1*x+a3; C=-(x**3+a2*x*x+a4*x+a6)
            disc=B*B-4*C
            if disc<0: continue
            n,d=disc.numerator,disc.denominator
            rn=math.isqrt(n); rd=math.isqrt(d)
            if rn*rn!=n or rd*rd!=d: continue
            s=Fr(rn,rd)
            for y in ((-B+s)/2,(-B-s)/2):
                if on_curve(a,x,y): out.append((x,y))
    return out

def primes_upto(n):
    s=bytearray([1])*(n+1); s[0]=s[1]=0
    for i in range(2,int(n**0.5)+1):
        if s[i]: s[i*i::i]=bytearray(len(s[i*i::i]))
    return [i for i in range(n+1) if s[i]]
PR=primes_upto(2000)

def leg(x,p):
    x%=p
    return 0 if x==0 else (1 if pow(x,(p-1)//2,p)==1 else -1)

def a_p(a,p):
    b2,b4,b6,b8,D=inv(a); s=0
    for x in range(p): s+=leg((4*x*x*x+b2*x*x+2*b4*x+b6)%p,p)
    return -s

def D3(n):
    s=0
    while n: s+=n%3; n//=3
    return s
ALPHA=3*math.pi/4
W={p: math.cos(math.pi*ALPHA*D3(p))/math.sqrt(p) for p in PR}

def M(a,X=2000):
    b2,b4,b6,b8,D=inv(a); t=0.0
    for p in PR:
        if p>X: break
        if p==2 or D%p==0: continue
        t+=a_p(a,p)*W[p]*math.log(p)/p
    return -t/math.log(X)

# ---- Group B: search rank-0 candidates with |Delta| in the matched band ----
import sys
print("searching rank-0 candidates (|Delta| in the 37..106-cohort band)...", flush=True)
rank0=[]
seen=set()
cands=[]
for a1 in (0,1):
    for a2 in (-1,0,1):
        for a3 in (0,1):
            for a4 in range(-6,7):
                for a6 in range(-6,7):
                    a=(a1,a2,a3,a4,a6); b2,b4,b6,b8,D=inv(a)
                    if D==0: continue
                    cands.append((abs(D),a))
cands.sort()
for absD,a in cands:
    if len(rank0)>=10: break
    if absD<11 or absD>3000: continue
    if a in seen: continue
    seen.add(a)
    pts=find_points(a)
    if not pts: continue                     # need rational points to be a fair comparison
    if any(nontorsion(a,P) for P in pts): continue
    rank0.append((a,absD))
print("  found %d rank-0 candidates" % len(rank0), flush=True)

print()
print("=== GROUP A -- rank >= 1 (corpus-verified, r134-r144) ===")
print("  curve     |Delta|      M_log^Re")
resA=[]
for lab,a in RANK1:
    b2,b4,b6,b8,D=inv(a); m=M(a); resA.append((lab,abs(D),m))
    print("  %-8s %-11d %+0.6f" % (lab,abs(D),m), flush=True)

print()
print("=== GROUP B -- rank 0 candidates (no non-torsion point found) ===")
print("  a-invariants             |Delta|      M_log^Re")
resB=[]
for a,absD in rank0:
    m=M(a); resB.append((str(a),absD,m))
    print("  %-24s %-11d %+0.6f" % (str(a),absD,m), flush=True)

print()
print("=== SIGN TABLE / VERDICT ===")
pA=[m for _,_,m in resA if m>0]; nA=[m for _,_,m in resA if m<0]
pB=[m for _,_,m in resB if m>0]; nB=[m for _,_,m in resB if m<0]
print("  group A (rank>=1, verified): %d curves -- M<0: %d  M>0: %d" % (len(resA),len(nA),len(pA)))
print("  group B (rank0 candidates):  %d curves -- M>0: %d  M<0: %d" % (len(resB),len(pB),len(nB)))
if resA: print("  A range: %+0.6f .. %+0.6f" % (min(m for _,_,m in resA),max(m for _,_,m in resA)))
if resB: print("  B range: %+0.6f .. %+0.6f" % (min(m for _,_,m in resB),max(m for _,_,m in resB)))
overlap = bool(resA and resB and min(m for _,_,m in resB) < max(m for _,_,m in resA))
print()
if pA:
    print("  VERDICT: FALSIFIED -- %d corpus-verified rank>=1 curves have M > 0:" % len(pA))
    for l,d,m in resA:
        if m>0: print("     %-8s |D|=%-10d M=%+0.6f" % (l,d,m))
elif nB:
    print("  VERDICT: FAILS on group B -- %d rank-0 candidates have M < 0 (wrong sign):" % len(nB))
    for l,d,m in resB:
        if m<0: print("     %-24s |D|=%-10d M=%+0.6f" % (l,d,m))
else:
    print("  VERDICT: SEPARATION HOLDS on this set -- all A negative, all B positive.")
    print("  margins: closest A to zero %+0.6f ; closest B to zero %+0.6f"
          % (max(m for _,_,m in resA), min(m for _,_,m in resB)))
