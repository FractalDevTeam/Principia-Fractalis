import PF.Analytic.Lambda0PrimeUniformBound_2026_10_14
import Mathlib.Analysis.Calculus.ParametricIntegral

open Complex Real MeasureTheory Set
open PrincipiaTractalis.XiThetaIntegral
open PrincipiaTractalis.Lambda0UniformBound20261014
open PrincipiaTractalis.Lambda0PrimeUniformBound20261014

#check @Complex.ofReal_log
#check @dominating
#check @dominating_integrableOn
#check @dominating_eq
#check @exp_neg_pi_le_one_twentythird
#check @one_sub_exp_neg_pi_ge_twentytwo_twentythirds
#check @Real.pi_gt_d2
#check @Real.exp_neg_pi

noncomputable section

/-- Antiderivative of `(x-1)e^{-πx}`. -/
private def G (x : ℝ) : ℝ := -((x - 1) / π + 1 / π ^ 2) * Real.exp (-π * x)

private lemma hasDerivAt_G (x : ℝ) :
    HasDerivAt G ((x - 1) * Real.exp (-π * x)) x := by
  have hπ : (0:ℝ) < π := Real.pi_pos
  have h1 : HasDerivAt (fun y : ℝ => -((y - 1) / π + 1 / π ^ 2)) (-(1/π)) x := by
    have : HasDerivAt (fun y : ℝ => (y - 1) / π + 1 / π ^ 2) (1/π) x := by
      have hd : HasDerivAt (fun y : ℝ => (y - 1) / π) (1/π) x := by
        simpa using ((hasDerivAt_id x).sub_const 1).div_const π
      simpa using hd.add_const (1 / π ^ 2)
    simpa using this.neg
  have h2 : HasDerivAt (fun y : ℝ => Real.exp (-π * y)) (-π * Real.exp (-π * x)) x := by
    have : HasDerivAt (fun y : ℝ => -π * y) (-π) x := by
      simpa using (hasDerivAt_id x).const_mul (-π)
    simpa [mul_comm] using this.exp
  have := h1.mul h2
  convert this using 1
  field_simp
  ring

end
