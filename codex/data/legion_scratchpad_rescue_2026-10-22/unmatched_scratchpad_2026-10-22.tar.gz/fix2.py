#!/usr/bin/env python3
import io

p = "rb_wip.lean"
s = io.open(p, encoding="utf-8").read()

# 1. replace the deprecated umbrella import with the three current modules
old_imp = "import Mathlib.AlgebraicGeometry.EllipticCurve.Group"
new_imp = ("import Mathlib.AlgebraicGeometry.EllipticCurve.Affine.Basic\n"
           "import Mathlib.AlgebraicGeometry.EllipticCurve.Affine.Formula\n"
           "import Mathlib.AlgebraicGeometry.EllipticCurve.Affine.Point")
assert s.count(old_imp) == 1
s = s.replace(old_imp, new_imp)

# 2. the point-at-infinity case: `simp` makes no progress; use add_zero
old_zero = "  | zero => simp\n"
new_zero = "  | zero => exact add_zero 0\n"
assert s.count(old_zero) == 1, "zero-case anchor count = %d" % s.count(old_zero)
s = s.replace(old_zero, new_zero)

io.open(p, "w", encoding="utf-8").write(s)
print("imports + zero case patched")
