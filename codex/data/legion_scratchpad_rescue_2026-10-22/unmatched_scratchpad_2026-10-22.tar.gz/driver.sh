#!/bin/bash
# Wait for the in-flight c=29/4 box, commit it, then run the rest of the D=1 band.
set -u
R="/Storage 2TB/home/xluxx/Principia-Fractalis-ACTIVE"
cd "$R" || exit 1
until grep -qE "^DONE|^FAILED|^LOCKED" /tmp/march_c29_4_status 2>/dev/null; do sleep 30; done
if ! grep -q "^DONE" /tmp/march_c29_4_status; then
  echo "c=29/4 did not finish: $(cat /tmp/march_c29_4_status)" > /tmp/march_run_status
  exit 1
fi
./codex/commit_box.sh 29/4 1/16 - 7.1875 7.3125 >> /tmp/march_run.log 2>&1 \
  || { echo "commit refused at 29/4" > /tmp/march_run_status; exit 1; }
exec ./codex/march_run.sh
