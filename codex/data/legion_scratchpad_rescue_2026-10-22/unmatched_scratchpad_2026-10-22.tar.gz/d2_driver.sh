#!/bin/bash
# Wait for the D=1 band to finish, then build the FIRST D=2 box.
#
# Runs on Acer under nohup/setsid so it is independent of any watcher on the
# other end of the ssh link.
#
# c = 81/8 = 10.125 is where the priced ladder's D = 2 band begins: it is the
# first centre past the D=1 band edge (frontier 10.0625 + r), and D = 1 cannot
# reach it -- Mc_lb(10.125) at D = 1 is below L0*r, which is why the band stops
# there rather than at some arbitrary point.
#
# Deliberately does NOT commit. This is the first Lean ever built at D > 1; the
# producer is validated only Python-side (D=1 byte-identity, Mc_lb agreement,
# counts, literal termination). The emitted D=2 proofs are unverified by the
# kernel until this runs, so the result gets inspected before it enters the tree.
set -u
REPO="/Storage 2TB/home/xluxx/Principia-Fractalis-ACTIVE"
C="81/8"; RAD="1/16"; D=2
TAG="c81_8"
ST=/tmp/d2_status
PG=/tmp/d2_progress
: > "$PG"
echo "WAITING for the D=1 band" > "$ST"

# --- 1. wait for the band ---------------------------------------------------
while true; do
  if grep -q "BAND-COMPLETE" /tmp/march_run_status 2>/dev/null; then break; fi
  if grep -qE "^\[.*\] STOP" /tmp/march_run.log 2>/dev/null; then
    echo "ABORT: the D=1 band STOPPED; not starting a D=2 box" > "$ST"; exit 1
  fi
  pgrep -f march_run.sh > /dev/null || {
    # runner gone without BAND-COMPLETE: only proceed if it genuinely finished
    grep -q "BAND-COMPLETE" /tmp/march_run_status 2>/dev/null && break
    echo "ABORT: march_run.sh vanished without completing" > "$ST"; exit 1; }
  sleep 60
done
echo "band complete at $(date +%H:%M:%S); deploying the density producer" >> "$PG"

# --- 2. deploy the parametric producer (safe only now the band is idle) -----
cp "$REPO/codex/gen_box.py" "$REPO/codex/gen_box_part2.py" /tmp/prod/ || {
  echo "ABORT: could not deploy the producer" > "$ST"; exit 1; }
echo "deployed gen_box.py + gen_box_part2.py to /tmp/prod" >> "$PG"

# --- 3. generate at D = 2 ---------------------------------------------------
echo "GENERATING c=$C D=$D" > "$ST"
OUT=$(mktemp -d /tmp/d2out.XXXXXX)
if ! (cd /tmp/prod && python3 gen_box.py --c "$C" --r "$RAD" --density "$D" \
        --out "$OUT" --work "$(mktemp -d /tmp/d2w.XXXXXX)" > /tmp/d2_gen.log 2>&1); then
  echo "FAILED generate -- see /tmp/d2_gen.log (box criterion?)" > "$ST"; exit 1
fi
grep -E "geometry|Mc_lb|L0\(|BOX CRITERION|margin vs|hybrid (plus|minus)|gate lhs" \
  /tmp/d2_gen.log >> "$PG"
echo "OUT=$OUT" >> "$PG"

# --- 4. install and build, strictly serial under the lock -------------------
exec 9>/tmp/pf_lean_build.lock
flock -w 7200 9 || { echo "ABORT: could not take the build lock" > "$ST"; exit 1; }
export PATH="$HOME/.elan/bin:$PATH"
A="$REPO/PF_Lean4_Code/PF/Analytic"
for f in "$OUT"/*.lean; do b=$(basename "$f")
  case "$b" in R1_*) cp "$f" "$A/PilotBoxes/$b" ;; *) cp "$f" "$A/FourierPanels/$b" ;; esac
done
cp "$OUT/_buildorder.txt" "$A/_buildorder.txt"
cd "$REPO/PF_Lean4_Code" || exit 1
FP=".lake/build/lib/lean/PF/Analytic/FourierPanels"
PB=".lake/build/lib/lean/PF/Analytic/PilotBoxes"
mkdir -p "$FP" "$PB"
echo "BUILDING ($(wc -l < PF/Analytic/_buildorder.txt) modules)" > "$ST"

while read -r m; do
  [ -z "$m" ] && continue
  taskset -c 0,1 lake env lean -o "$FP/$m.olean" \
    "PF/Analytic/FourierPanels/$m.lean" > "/tmp/d2_$m.log" 2>&1
  rc=$?
  echo "$m rc=$rc $(date +%H:%M:%S) freeGB=$(free -g | awk 'NR==2{print $4}')" >> "$PG"
  [ $rc -ne 0 ] && { echo "FAILED $m" > "$ST"; exit 1; }
done < PF/Analytic/_buildorder.txt

GATE=$(cd "$A/PilotBoxes" && ls R1_${TAG}_*_HYBRID_*.lean | head -1)
UNC=$(cd "$A/PilotBoxes" && ls R1_${TAG}_*_UNCONDITIONAL_*.lean | head -1)
taskset -c 0,1 lake env lean -o "$PB/${GATE%.lean}.olean" \
  "PF/Analytic/PilotBoxes/$GATE" > /tmp/d2_gate.log 2>&1
rc=$?; echo "gate rc=$rc $(date +%H:%M:%S)" >> "$PG"
[ $rc -ne 0 ] && { echo "FAILED gate" > "$ST"; exit 1; }

taskset -c 0,1 lake env lean "PF/Analytic/PilotBoxes/$UNC" > /tmp/d2_uncond.log 2>&1
rc=$?; echo "uncond rc=$rc $(date +%H:%M:%S)" >> "$PG"
[ $rc -ne 0 ] && { echo "FAILED uncond" > "$ST"; exit 1; }

# --- 5. the three-axiom bar, as a gate --------------------------------------
U=/tmp/d2_uncond.log
if grep -qE "sorryAx|nativeDecide|ofReduceBool" "$U"; then
  echo "FAILED axiom bar: forbidden axiom" > "$ST"; exit 1
fi
SETS=$(tr '\n' ' ' < "$U" | grep -oE "axioms: \[[^]]*\]" | tr -s ' ' | sort -u)
N=$(grep -c "depends on axioms" "$U")
if [ "$SETS" != "axioms: [propext, Classical.choice, Quot.sound]" ]; then
  echo "FAILED axiom bar: $SETS" > "$ST"; exit 1
fi
echo "axiom-bar OK: $N theorems" >> "$PG"
echo "DONE c=$C D=$D ($N theorems on the bar) -- NOT COMMITTED, awaiting review" > "$ST"
