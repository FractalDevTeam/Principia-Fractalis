import math

# --- curves: label -> (a1,a2,a3,a4,a6, rank, conductor) ---
# coefficients taken VERBATIM from the corpus's own Lean defs where available.
CURVES = [
    ("11a1",   (0,-1, 1, 0, 0),  0,   11),
    ("37a1",   (0, 0, 1,-1, 0),  1,   37),
    ("43a1",   (0, 1, 1, 0, 0),  1,   43),
    ("53a1",   (1,-1, 1, 0, 0),  1,   53),
    ("61a1",   (1, 0, 0,-2, 1),  1,   61),
    ("79a1",   (1, 1, 1,-2, 0),  1,   79),
    ("83a1",   (1, 1, 1, 1, 0),  1,   83),
    ("89a1",   (1, 1, 1,-1, 0),  1,   89),
    ("101a1",  (0, 1, 1,-1,-1),  1,  101),
    ("106a1",  (1, 1, 0,-7, 5),  1,  106),
    ("389a1",  (0, 1, 1,-2, 0),  2,  389),
    ("5077a1", (0, 0, 1,-7, 6),  3, 5077),
]

def invariants(a):
    a1,a2,a3,a4,a6 = a
    b2 = a1*a1 + 4*a2
    b4 = 2*a4 + a1*a3
    b6 = a3*a3 + 4*a6
    b8 = a1*a1*a6 + 4*a2*a6 - a1*a3*a4 + a2*a3*a3 - a4*a4
    D  = -b2*b2*b8 - 8*b4**3 - 27*b6*b6 + 9*b2*b4*b6
    return b2,b4,b6,b8,D

def primes_upto(n):
    s = bytearray([1])*(n+1); s[0]=s[1]=0
    for i in range(2,int(n**0.5)+1):
        if s[i]: s[i*i::i] = bytearray(len(s[i*i::i]))
    return [i for i in range(n+1) if s[i]]

def legendre(a, p):
    a %= p
    if a == 0: return 0
    return 1 if pow(a, (p-1)//2, p) == 1 else -1

def a_p(curve, p):
    """a_p = p+1-#E(F_p) = -sum_x chi(g(x)),  g = 4x^3+b2 x^2+2b4 x+b6  (p odd)."""
    b2,b4,b6,b8,D = invariants(curve)
    s = 0
    for x in range(p):
        g = (4*x*x*x + b2*x*x + 2*b4*x + b6) % p
        s += legendre(g, p)
    return -s

def D3(n):
    s = 0
    while n:
        s += n % 3; n //= 3
    return s

ALPHA = 3*math.pi/4
def Re_r(p):
    # r_p = p^{-1/2} e^{i*pi*alpha*D_3(p)}   ->  Re = p^{-1/2} cos(pi*alpha*D_3(p))
    return math.cos(math.pi*ALPHA*D3(p)) / math.sqrt(p)

def M_log_Re(curve, X, skip_bad=True):
    b2,b4,b6,b8,D = invariants(curve)
    tot = 0.0
    for p in primes_upto(X):
        if p == 2: continue              # completion of square needs p odd
        if skip_bad and D % p == 0: continue
        tot += a_p(curve, p) * Re_r(p) * math.log(p) / p
    return -tot / math.log(X)

print("=== the statistic as the docstring defines it, X = 2000 ===")
print("  (good primes only; p=2 skipped)")
print()
print("  curve      rank  cond    M_log^Re     file's quoted value")
quoted = {"11a1": "+0.170", "37a1": "-0.580", "389a1": "-0.767", "5077a1": "-0.143"}
res2000 = {}
for lab, a, r, N in CURVES:
    v = M_log_Re(a, 2000)
    res2000[lab] = v
    print("  %-9s  %d    %4d   %+0.6f      %s" % (lab, r, N, v, quoted.get(lab, "-")))

print()
print("=== CONFOUND TEST (sweep-B design): nine curves, ALL rank 1, conductor 37..106 ===")
print("  if the statistic reads RANK it clusters; if it reads CONDUCTOR it spreads in N")
r1 = [(l,a,N) for l,a,r,N in CURVES if r == 1]
vals = []
for lab, a, N in r1:
    v = res2000[lab]; vals.append(v)
    print("  %-7s N=%4d   M=%+0.6f" % (lab, N, v))
print("  --> spread over FIXED rank 1: min %+0.6f  max %+0.6f  range %0.6f"
      % (min(vals), max(vals), max(vals)-min(vals)))
r0 = res2000["11a1"]
print("  --> the single rank-0 curve:   M=%+0.6f" % r0)
print("  --> rank-0 value inside the rank-1 spread?  %s"
      % ("YES - NO SEPARATION" if min(vals) <= r0 <= max(vals) else "no"))

print()
print("=== sign test: does sign(M) track rank at all? ===")
for lab, a, r, N in CURVES:
    v = res2000[lab]
    pred = "rank 0" if v > 0 else "rank >= 1"
    ok = (v > 0) == (r == 0)
    print("  %-9s rank %d  M=%+0.6f -> predicts %-9s  %s" % (lab, r, v, pred, "OK" if ok else "WRONG"))

print()
print("=== asymptotic behaviour (the claim is X -> infinity) ===")
for lab in ["11a1", "37a1", "389a1"]:
    a = dict((l,aa) for l,aa,r,N in CURVES)[lab]
    row = "  %-7s " % lab
    for X in [500, 1000, 2000, 4000, 8000]:
        row += " X=%-5d %+0.4f " % (X, M_log_Re(a, X))
    print(row)

print()
print("=== does including BAD primes change the sign? (docstring says 'p <= X', no restriction) ===")
for lab, a, r, N in CURVES[:6]:
    vg = M_log_Re(a, 2000, skip_bad=True)
    vb = M_log_Re(a, 2000, skip_bad=False)
    print("  %-7s good-only %+0.6f   all-p %+0.6f   sign flip: %s"
          % (lab, vg, vb, "YES" if (vg > 0) != (vb > 0) else "no"))
