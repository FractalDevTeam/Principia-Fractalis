import PF.Analytic.ThetaBoundaryConstant_2026_10_19
import PF.Analytic.Lambda0IBP2Combined_2026_10_18
import PF.Analytic.EdgeReDerivBound_2026_10_14

open Complex Real MeasureTheory Set Filter
open PrincipiaTractalis.OmegaDerivative20261014
open PrincipiaTractalis.OmegaSecondDerivative20261018
open PrincipiaTractalis.FPlusSecondDerivative20261018
open PrincipiaTractalis.RiemannXiThetaBoxEnclosure
open PrincipiaTractalis.XiThetaIntegral

#check @summable_omega'_term
#check @summable_omega''_term
#check @omega''_term_nonneg
#check @re_xi_at_s
#check @omega'_term_summable
#check @summable_omega_term
-- the defs, to see the exact tsum shapes
#print omega''
#print omega'
#print PrincipiaTractalis.FMinusSecondIBP20261018.F_minus''
#print F_plus''
