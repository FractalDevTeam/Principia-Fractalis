#!/usr/bin/env python3
"""
Fix the producer's retag for INTEGER box centres.

c = 7 is the first integer centre on the march (27/4, 55/8, 13/2 are all
fractions), and it exposed a bug in retag step 2b. The type-ascribed form is
rewritten by substituting numerator and denominator into a fixed template:

    asc_to = f"({c_to.numerator}:R)/{c_to.denominator}"

which for c = 7 yields `(7:R)/1`, so the emitted M-bound proof carries

    have habs_c : |((7:R)/1)| = 7 := by rw [abs_of_pos]; norm_num

Two failures follow, both from that `/1`:

  * `rw [habs_c]` cannot fire -- Lean elaborates the goal's occurrence as `|7|`,
    not `|7 / 1|`, so the pattern is absent;
  * the `have` itself fails. For a genuine fraction, `rw [abs_of_pos]` turns the
    main goal into `27/4 = 27/4`, which `rw` closes by rfl, leaving only the
    side goal `0 < 27/4` for `norm_num`. With `/1` the main goal is `7/1 = 7`,
    NOT closed by rfl, so `norm_num` consumes it and the side goal `0 < 7/1`
    survives -- exactly the reported `unsolved goals |- 0 < 7 / 1`.

Fix: canonicalise the target form when the denominator is 1, so the emitted
literal is `(7:R)` and matches what Lean elaborates. Plus a post-assertion that
no `:R)/1` artifact survives any retag, which catches this whole class for
every future integer centre.
"""
import io
import sys

R = chr(8477)
P = sys.argv[1] if len(sys.argv) > 1 else "gen_box.py"

OLD = f'''    asc_from = f"({{c_from.numerator}}:{R}}})/{{c_from.denominator}}"
    asc_to = f"({{c_to.numerator}}:{R}}})/{{c_to.denominator}}"
'''
# the f-string above is fragile to brace counting; build it literally instead
OLD = (
    '    asc_from = f"({c_from.numerator}:' + R + ')/{c_from.denominator}"\n'
    '    asc_to = f"({c_to.numerator}:' + R + ')/{c_to.denominator}"\n'
)

NEW = (
    '    # The template centres are all genuine fractions; an INTEGER target\n'
    '    # must not be written "(7:' + R + ')/1" -- Lean elaborates that\n'
    '    # occurrence as |7|, so a later `rw` cannot find it, and the main goal\n'
    '    # 7/1 = 7 is not closed by rfl so the positivity side goal survives.\n'
    '    assert c_from.denominator != 1, (\n'
    '        f"retag: integer source centre {c_from} would make asc_from a "\n'
    '        "prefix of the fractional form")\n'
    '    asc_from = f"({c_from.numerator}:' + R + ')/{c_from.denominator}"\n'
    '    asc_to = (f"({c_to.numerator}:' + R + ')/{c_to.denominator}"\n'
    '              if c_to.denominator != 1 else f"({c_to.numerator}:' + R + ')")\n'
)

OLD_POST = (
    '    # 4. post-assertions: no stale c literals\n'
    '    assert asc_from not in s, f"retag: stale ascribed {asc_from}"\n'
)
NEW_POST = (
    '    # 4. post-assertions: no stale c literals\n'
    '    assert asc_from not in s, f"retag: stale ascribed {asc_from}"\n'
    '    assert f":' + R + ')/1" not in s, (\n'
    '        "retag: emitted a \'/1\' denominator -- Lean normalises it away and "\n'
    '        "later rewrites will not match (integer-centre hazard)")\n'
)

src = io.open(P, encoding="utf-8").read()
for name, old in (("asc_to assignment", OLD), ("post-assertions", OLD_POST)):
    n = src.count(old)
    assert n == 1, f"{name}: found {n} times in {P}, expected 1"
out = src.replace(OLD, NEW).replace(OLD_POST, NEW_POST)
assert "c_to.denominator != 1 else" in out
assert "chr(8477)})/1\" not in s" in out
io.open(P, "w", encoding="utf-8", newline="\n").write(out)
print(f"patched {P}: retag canonicalises integer centres, + /1 post-assertion")
