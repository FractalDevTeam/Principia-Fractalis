#!/usr/bin/env python3
import io

p = "PF/Ch24Descent2TorsionRatBridge_2026_10_17.lean"
s = io.open(p, encoding="utf-8").read()

old = """## The integrality step"""
new = """## What this file concludes

§4 gives `solutions_are_origin`: the only rational solution of `y² = x³ + x` is
`(0, 0)`. §5 then plumbs that into the Mordell–Weil group and concludes

    **`Ecurve_rank_eq_zero : Module.rank ℤ Ecurve.toAffine.Point = 0`**

for `Ecurve = ⟨0, 0, 0, 1, 0⟩`. **This is the first EXACT rank in the
repository** — every other rank theorem in the tree is a lower bound
`n ≤ rank`. It uses no `L`-function anywhere: the chain is `descent_core`
(5ea7e0e9) → `descent_lowest_terms` (4028e3c0) → the `Rat` bridge here →
`rank_eq_zero_of_two_torsion`, with mathlib's `not_fermat_42` as the engine.

For the 2-torsion step, `Ecurve` has `a₁ = a₃ = 0`, so
`negY x y = -y - a₁x - a₃ = -y`; at `y = 0` that is `y = negY x y`, and
`WeierstrassCurve.Affine.Point.add_self_of_Y_eq` gives `P + P = 0` directly —
no dependent rewriting of the point's coordinates is needed.

## The integrality step"""

assert s.count(old) == 1, "anchor count = %d" % s.count(old)
io.open(p, "w", encoding="utf-8").write(s.replace(old, new, 1))
print("header updated")
