#!/bin/bash
# c=81/8 D=2 finish: only the assemble changed (hardcoded Seg03Range -> the
# first actual range sub-segment). The 18 panel/add-on modules already built
# rc=0 and regenerate byte-identical, so their oleans stay valid.
set -u
exec 9>/tmp/pf_lean_build.lock
flock -w 7200 9 || { echo "LOCKED" > /tmp/f81_status; exit 1; }
export PATH="$HOME/.elan/bin:$PATH"
A="/Storage 2TB/home/xluxx/Principia-Fractalis-ACTIVE/PF_Lean4_Code"
cd "$A" || exit 1
for f in /tmp/r81/*.lean; do b=$(basename "$f")
  case "$b" in R1_*) cp "$f" PF/Analytic/PilotBoxes/"$b" ;;
               *) cp "$f" PF/Analytic/FourierPanels/"$b" ;; esac; done
cp /tmp/r81/_buildorder.txt PF/Analytic/_buildorder.txt
FP=".lake/build/lib/lean/PF/Analytic/FourierPanels"
PB=".lake/build/lib/lean/PF/Analytic/PilotBoxes"
: > /tmp/f81_progress; echo RUNNING > /tmp/f81_status
run() { taskset -c 0,1 lake env lean -M 7000 ${3:+-o "$3"} "$2" > "/tmp/f81_$1.log" 2>&1
        rc=$?; echo "$1 rc=$rc $(date +%H:%M:%S)" >> /tmp/f81_progress
        [ $rc -ne 0 ] && { echo "FAILED $1" > /tmp/f81_status; exit 1; }; }
run asm "PF/Analytic/FourierPanels/Assemble_c81_8_threehalves_HYBRID_2026_10_20.lean" \
        "$FP/Assemble_c81_8_threehalves_HYBRID_2026_10_20.olean"
run gate "PF/Analytic/PilotBoxes/R1_c81_8_r1_16_HYBRID_2026_10_20.lean" \
         "$PB/R1_c81_8_r1_16_HYBRID_2026_10_20.olean"
run uncond "PF/Analytic/PilotBoxes/R1_c81_8_r1_16_pointwise_UNCONDITIONAL_2026_10_20.lean" ""
# the same exact-set axiom gate the march uses, on all three logs
for pair in "Assemble_c81_8_threehalves_HYBRID_2026_10_20:asm" \
            "R1_c81_8_r1_16_HYBRID_2026_10_20:gate" \
            "R1_c81_8_r1_16_pointwise_UNCONDITIONAL_2026_10_20:uncond"; do
  m="${pair%%:*}"; lg="${pair##*:}"
  src=$(ls PF/Analytic/FourierPanels/$m.lean PF/Analytic/PilotBoxes/$m.lean 2>/dev/null | head -1)
  python3 ../codex/check_march_axioms.py "$src" "/tmp/f81_$lg.log" >> /tmp/f81_progress 2>&1 \
    || { echo "FAILED axiom bar: $m" > /tmp/f81_status; exit 1; }
done
echo "DONE c=81/8 D=2" > /tmp/f81_status
