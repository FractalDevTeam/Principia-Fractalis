#!/usr/bin/env python3
"""
The allocation, against the CORRECT budget Re xi(1+it)/(t^2+t), and the
question that actually matters: how far past t=13 does add-on tightening buy?

Gate 1 budget:  c^2*(R_ub-R) + c*(I_ub-I) <= 2*(Re xi - Mc_lb) = Re xi  (Mc_lb = Re xi/2)
The add-on enters R_ub and I_ub equally => costs addon*(c^2+c).
So the add-on budget is  Re xi(t)/(t^2+t),  and it goes to ZERO at the first
zero of Re xi(1+it), t* = 13.9883806982.
"""
import math
import mpmath as mp

mp.mp.dps = 30
PI = math.pi
A, B = 1.5, 5.0
TSTAR = 13.9883806982


def g(u):
    return (math.exp(u / 2) + 1) * 3 * math.exp(-PI * math.exp(u))


def residue_bound(n):
    h = (B - A) / n
    return h * sum(g(A + i * h) for i in range(n))


def xi(s):
    return mp.mpf(1) / 2 * s * (s - 1) * mp.power(mp.pi, -s / 2) * mp.gamma(s / 2) * mp.zeta(s)


def budget(t):
    return float(mp.re(xi(mp.mpc(1, t)))) / (t**2 + t)


OM_FREE = 4.3790e-22      # already proven in Lean, currently discarded
TAIL_FREE = 1.1326e-07    # already proven in Lean, currently discarded
OM_NOW, TAIL_NOW, RES_NOW = 1e-4, 1e-6, 231 / 10**6

print("=" * 76)
print("ALLOCATION AT t = 13   (budget = Re xi / (t^2+t))")
print("=" * 76)
b13 = budget(13.0)
print(f"  add-on budget at t=13 (full)             = {b13:.4e}")
print(f"  current add-on total                     = "
      f"{OM_NOW+TAIL_NOW+RES_NOW:.4e}  -> {(OM_NOW+TAIL_NOW+RES_NOW)/b13:.1f}x over")
print()
print(f"  {'residue pieces':>15} {'residue':>11} {'add-on total':>13} "
      f"{'% of budget':>12} {'verdict':>22}")
for n in (1, 2, 4, 8, 16, 20, 32, 64):
    r = residue_bound(n)
    tot = r + TAIL_FREE + OM_FREE
    pct = 100 * tot / b13
    if pct <= 10:
        v = "<=10%: panels get 90%"
    elif pct < 100:
        v = "fits, panels squeezed"
    else:
        v = "OVER"
    print(f"  {n:>15} {r:>11.4e} {tot:>13.4e} {pct:>11.2f}% {v:>22}")

print()
print("=" * 76)
print("HOW FAR PAST t=13 DOES THE TIGHTENING BUY?")
print("  max t such that the add-on total is <= 10% of the budget")
print("=" * 76)


def max_t(addon_total, frac=0.10):
    lo, hi = 6.5, TSTAR - 1e-9
    if budget(lo) * frac < addon_total:
        return None
    for _ in range(200):
        mid = (lo + hi) / 2
        if budget(mid) * frac >= addon_total:
            lo = mid
        else:
            hi = mid
    return lo


configs = [
    ("current (omega 1e-4, tail 1e-6, residue 231/10^6)", OM_NOW + TAIL_NOW + RES_NOW),
    ("free omega+tail only, residue unchanged", RES_NOW + TAIL_FREE + OM_FREE),
    ("free omega+tail, residue 1 piece (endpoint-correct)", residue_bound(1) + TAIL_FREE + OM_FREE),
    ("free omega+tail, residue 2 pieces", residue_bound(2) + TAIL_FREE + OM_FREE),
    ("free omega+tail, residue 8 pieces", residue_bound(8) + TAIL_FREE + OM_FREE),
    ("free omega+tail, residue 32 pieces", residue_bound(32) + TAIL_FREE + OM_FREE),
    ("free omega+tail, residue at its FLOOR", 4.8856e-07 + TAIL_FREE + OM_FREE),
    ("add-ons driven to ZERO (unreachable limit)", 1e-30),
]
print(f"  {'configuration':>52} {'add-on':>11} {'max t':>9}")
for name, a in configs:
    mt = max_t(a)
    s = f"{mt:.4f}" if mt else "< 6.5"
    print(f"  {name:>52} {a:>11.4e} {s:>9}")

print()
print(f"  t* = first zero of Re xi(1+it) = {TSTAR}")
print("  Every configuration converges to t*, because the budget -> 0 there.")
print("  Add-on tightening cannot cross it; nor can panel work.")
