import PF.Analytic.DerivEdgeReBound_2026_10_20
open Real MeasureTheory Set Filter Topology
open PrincipiaTractalis.XiThetaIntegral
open PrincipiaTractalis.FPlusSecondDerivative20261018
open PrincipiaTractalis.FPlusSecondIBPRows20261018
open PrincipiaTractalis.FMinusSecondIBP20261018
open PrincipiaTractalis.Lambda0IBPIdentity20261015
-- pieces for the weighted FTC
#check @hasDerivAt_F_plus
#check @hasDerivAt_F_minus
#check @F_plus_zero
#check @F_minus_zero
#check @tendsto_F_plus_atTop_zero
#check @tendsto_F_minus_atTop_zero
#check @deriv_F_plus_eq_F_plus'
#check @deriv_F_minus_eq_F_minus'
#check @F_plus
#check @F_minus
#check @F_plus_continuous
#check @F_minus_continuous
#check @continuousWithinAt_deriv_F_plus_zero
#check @tendsto_exp_mul_const_atTop_zero
