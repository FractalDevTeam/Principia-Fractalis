#!/usr/bin/env python3
"""How loose is the residue bound, and how much does subdividing buy?

Current bound (ResidueBound_c51_8_three_halves_to_5_2026_10_16.lean):
   |f(u)| <= (exp(u/2) + 1) * 3 * exp(-pi * exp u)   pointwise
   on [3/2, 5]:  (exp(u/2)+1) <= 22 ,  exp(-pi exp u) <= exp(-4pi) <= 1/279841
   => |f| <= 66/279841 , integral <= (66/279841)*(7/2) = 231/279841 ~ 8.253e-4

The looseness is structural: the MAXIMUM of a super-exponentially decaying
integrand is multiplied by the FULL interval length.
"""
from fractions import Fraction as F
from mpmath import mp, mpf, exp, pi, quad

mp.dps = 60

a, b = mpf(3) / 2, mpf(5)
g = lambda u: (exp(u / 2) + 1) * 3 * exp(-pi * exp(u))

print("=" * 76)
print("1. the current bound vs the integral of the SAME pointwise majorant")
cur = F(231, 279841)
exact_major = quad(g, [a, b])
print("   current certified bound        = %s = %.6e" % (cur, float(cur)))
print("   integral of the majorant g(u)  = %.6e" % float(exact_major))
print("   looseness factor               = %.1f x  (~%.1f orders of magnitude)"
      % (float(cur) / float(exact_major),
         mp.log10(float(cur) / float(exact_major))))

print()
print("=" * 76)
print("2. what a plain SUBDIVISION of [3/2,5] buys (max x width, per piece)")
print("   This is the same argument, just applied piecewise -- semantics only,")
print("   no new mathematics, exactly as the previous tightening was.")
print()
print("   %-8s %-16s %-14s" % ("pieces", "bound", "vs current"))
for n in [1, 2, 4, 7, 14, 28]:
    tot = mpf(0)
    h = (b - a) / n
    for k in range(n):
        lo = a + k * h
        # g is decreasing on [3/2,5] (super-exponential decay dominates), so
        # the max on each piece is at its left endpoint
        tot += g(lo) * h
    print("   %-8d %-16.6e %-14s" % (n, float(tot), "%.1fx tighter" % (float(cur) / float(tot))))

print()
print("=" * 76)
print("3. budget impact at c = 13/2  (weight c^2 + c = 48.75)")
W = mpf(48.75)
need = mpf("0.014326")
print("   needed recovery                     = %.6f" % float(need))
print("   current residue costs               = %.6f" % float(W * float(cur)))
for n in [2, 4, 7]:
    tot = mpf(0)
    h = (b - a) / n
    for k in range(n):
        tot += g(a + k * h) * h
    saved = W * (float(cur) - float(tot))
    print("   with %2d pieces: residue costs %.6f  -> frees %.6f  (%s)"
          % (n, float(W * tot), float(saved),
             "ENOUGH" if saved > need else "not enough"))

print()
print("=" * 76)
print("4. also: is g really decreasing on [3/2,5]? (justifies left-endpoint max)")
print("   g'(u) = g(u) * [ (1/2)exp(u/2)/(exp(u/2)+1) - pi exp(u) ]")
for u in ["1.5", "2", "3", "4", "5"]:
    u = mpf(u)
    brack = (mpf(1) / 2 * exp(u / 2)) / (exp(u / 2) + 1) - pi * exp(u)
    print("     u = %-4s  bracket = %+.4f  -> g' %s 0" % (u, float(brack), "<" if brack < 0 else ">"))
print("   bracket < 0 throughout, so g is strictly decreasing: left-endpoint")
print("   maxima are valid and the subdivision argument is sound.")
