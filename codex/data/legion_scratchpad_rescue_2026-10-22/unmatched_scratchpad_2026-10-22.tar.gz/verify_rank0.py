"""Hard-verify the six negative-M 'rank 0 candidates': is any of them really rank >= 1?
A much wider rational-point search; any non-torsion point found => the curve is
rank >= 1 and is NOT a counterexample to the sign rule."""
import math
from fractions import Fraction as Fr

SUSPECTS = [
    ((1, 1, 1, 0, 0), 15, -0.093501),
    ((1, 0, 1, 0, 0), 26, -0.028828),
    ((0, 0, 1, 0, 0), 27, -0.010933),
    ((1, 0, 1,-1, 0), 28, -0.062830),
    ((0, 1, 1,-3, 1), 37, -0.112948),
    ((1, 1, 0, 1, 0), 39, -0.007300),
]
# controls: curves whose rank>=1 is corpus-verified, run through the SAME search
CONTROLS = [
    ((0,0,1,-1,0), "37a1"), ((0,1,1,0,0), "43a1"), ((1,-1,1,0,0), "53a1"),
]

def inv(a):
    a1,a2,a3,a4,a6=a
    b2=a1*a1+4*a2; b4=2*a4+a1*a3; b6=a3*a3+4*a6
    b8=a1*a1*a6+4*a2*a6-a1*a3*a4+a2*a3*a3-a4*a4
    return b2,b4,b6,b8,-b2*b2*b8-8*b4**3-27*b6*b6+9*b2*b4*b6

def on_curve(a,x,y):
    a1,a2,a3,a4,a6=a
    return y*y+a1*x*y+a3*y == x**3+a2*x*x+a4*x+a6

def dbl(a,P):
    if P is None: return None
    a1,a2,a3,a4,a6=a; x,y=P
    den=2*y+a1*x+a3
    if den==0: return None
    lam=(3*x*x+2*a2*x+a4-a1*y)/den
    mu=y-lam*x
    x3=lam*lam+a1*lam-a2-2*x
    return (x3,-(lam+a1)*x3-mu-a3)

def add(a,P,Q):
    if P is None: return Q
    if Q is None: return P
    a1,a2,a3,a4,a6=a; x1,y1=P; x2,y2=Q
    if x1==x2:
        if y1 == -y2-a1*x2-a3: return None
        return dbl(a,P)
    lam=(y2-y1)/(x2-x1); mu=y1-lam*x1
    x3=lam*lam+a1*lam-a2-x1-x2
    return (x3,-(lam+a1)*x3-mu-a3)

def order_or_infinite(a,P,maxn=16):
    """returns n if n*P = O for some n <= maxn (torsion), else None (looks infinite)"""
    Q=P
    for n in range(1,maxn+1):
        if Q is None: return n
        Q=add(a,Q,P)
    return None

def search(a,xb,vb):
    a1,a2,a3,a4,a6=a; out=[]
    for v in range(1,vb+1):
        for u in range(-xb*v,xb*v+1):
            if math.gcd(abs(u),v)!=1: continue
            x=Fr(u,v); B=a1*x+a3; C=-(x**3+a2*x*x+a4*x+a6)
            disc=B*B-4*C
            if disc<0: continue
            n,d=disc.numerator,disc.denominator
            rn=math.isqrt(n); rd=math.isqrt(d)
            if rn*rn!=n or rd*rd!=d: continue
            s=Fr(rn,rd)
            for y in ((-B+s)/2,(-B-s)/2):
                if on_curve(a,x,y) and (x,y) not in out: out.append((x,y))
    return out

print("=== CONTROLS: does this search FIND the known rank>=1 generators? ===")
for a,lab in CONTROLS:
    pts=search(a,60,12)
    inf=[P for P in pts if order_or_infinite(a,P) is None]
    print("  %-6s points found: %-3d   of infinite order: %-3d  %s"
          % (lab,len(pts),len(inf), ("FOUND generator " + str(inf[0])) if inf else "NONE FOUND (search too weak!)"))

print()
print("=== SUSPECTS: wide search (x = u/v, |u| <= 60v, v <= 12) ===")
for a,absD,m in SUSPECTS:
    pts=search(a,60,12)
    orders=[order_or_infinite(a,P) for P in pts]
    inf=[P for P,o in zip(pts,orders) if o is None]
    tors=[o for o in orders if o is not None]
    verdict = "RANK >= 1 (mislabelled!)" if inf else "rank 0 supported"
    print("  %-20s |D|=%-6d M=%+0.6f  pts=%-3d torsion orders=%-18s %s"
          % (str(a),absD,m,len(pts),str(sorted(set(tors))),verdict))
    if inf: print("       infinite-order point: %s" % str(inf[0]))
