
/-! ## §5 — the capstone: `Module.rank ℤ E(ℚ) = 0`

`E : y² = x³ + x` as a `WeierstrassCurve ℚ` is `⟨0, 0, 0, 1, 0⟩` (so
`a₁ = a₂ = a₃ = a₆ = 0`, `a₄ = 1`), for which `negY x y = -y - a₁x - a₃ = -y`.

Every affine rational point is `(0, 0)` by §4, and there `y = -y`, so
`add_self_of_Y_eq` gives `P + P = 0`. With the point at infinity that covers
every point, and `rank_eq_zero_of_two_torsion` concludes. -/

/-- `E : y² = x³ + x`, conductor 64. -/
def Ecurve : WeierstrassCurve ℚ := ⟨0, 0, 0, 1, 0⟩

/-- Every rational point of `E` is killed by `2`. -/
theorem Ecurve_two_torsion (P : Ecurve.toAffine.Point) : P + P = 0 := by
  cases P with
  | zero => simp
  | some h =>
      rename_i x y
      have heq : y ^ 2 = x ^ 3 + x := by
        have h1 := h.left
        rw [WeierstrassCurve.Affine.equation_iff] at h1
        simp only [Ecurve] at h1
        linarith [h1]
      have hy0 : y = 0 := (solutions_are_origin heq).2
      refine WeierstrassCurve.Affine.Point.add_self_of_Y_eq ?_
      simp [WeierstrassCurve.Affine.negY, Ecurve, hy0]

/-- **★ FIRST EXACT RANK IN THE REPOSITORY ★**

`Module.rank ℤ E(ℚ) = 0` for `E : y² = x³ + x`.

Every other rank theorem in the tree is a lower bound `n ≤ rank`. This is an
exact value, and it is obtained with no `L`-function: descent core
(`descent_core`) + lowest-terms form (`descent_lowest_terms`) + the `Rat`
bridge (`no_rational_point_x_ne_zero`) + rank-zero-from-2-torsion
(`rank_eq_zero_of_two_torsion`), with Fermat's `a⁴ + b⁴ ≠ c²` from mathlib as
the engine. -/
theorem Ecurve_rank_eq_zero : Module.rank ℤ Ecurve.toAffine.Point = 0 :=
  rank_eq_zero_of_two_torsion Ecurve_two_torsion
