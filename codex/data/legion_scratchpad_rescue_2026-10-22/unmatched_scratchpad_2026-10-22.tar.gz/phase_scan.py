from mpmath import mp, mpf, mpc
mp.dps = 25

# xi = s(s-1)*Lambda(s)/2  with Lambda(s) = pi^(-s/2) Gamma(s/2) zeta(s)
# (equivalently xi = (1 + s(s-1)*Lambda0(s))/2, Lambda0 = Lambda + 1/s + 1/(1-s))
def Lambda(s):  return mp.pi**(-s/2)*mp.gamma(s/2)*mp.zeta(s)
def xi(s):      return s*(s-1)*Lambda(s)/2

def at(t):
    return xi(mpc(1, t))

print("=== Re xi(1+it) and Im xi(1+it) on the edge ===")
print("   t        Re xi            Im xi            |xi|        arg xi/pi")
for k in range(0, 61, 2):
    t = mpf(k)
    v = at(t)
    print("%6.1f  %+14.8f  %+14.8f  %12.8f  %+9.4f"
          % (float(t), float(v.real), float(v.imag), float(abs(v)),
             float(mp.arg(v)/mp.pi)))

print("")
print("=== sign changes of Re xi on t in [0,60], bisected ===")
prev_t, prev = mpf(0), at(mpf(0)).real
step = mpf("0.05")
roots = []
t = step
while t <= 60:
    cur = at(t).real
    if (prev > 0) != (cur > 0):
        lo, hi = prev_t, t
        for _ in range(60):
            mid = (lo+hi)/2
            if (at(lo).real > 0) != (at(mid).real > 0): hi = mid
            else: lo = mid
        roots.append((lo+hi)/2)
    prev_t, prev = t, cur
    t += step
for r in roots:
    print("  Re xi(1+it) = 0 at t =", mp.nstr(r, 12))
print("  total sign changes in [0,60]:", len(roots))

print("")
print("=== sign changes of Im xi on t in [0,60] ===")
prev_t, prev = mpf("0.05"), at(mpf("0.05")).imag
t = mpf("0.10"); iroots = []
while t <= 60:
    cur = at(t).imag
    if (prev > 0) != (cur > 0):
        lo, hi = prev_t, t
        for _ in range(60):
            mid = (lo+hi)/2
            if (at(lo).imag > 0) != (at(mid).imag > 0): hi = mid
            else: lo = mid
        iroots.append((lo+hi)/2)
    prev_t, prev = t, cur
    t += mpf("0.05")
for r in iroots:
    print("  Im xi(1+it) = 0 at t =", mp.nstr(r, 12))
print("  total sign changes in [0,60]:", len(iroots))
