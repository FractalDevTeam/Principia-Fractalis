#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
HARD RULE 4 (repair, not disclosure): correct the t=14.5 row of
codex/R1R2R3_TARGET_REACHABLE_2026-10-16.md.

Re xi(1+14.5i) = -5.5910e-04, NOT +4.142e-04. Five of the table's six rows
match Re xi(1+it) to four digits, so the identification is certain and this
row is simply wrong. Because the Gate-1 budget is proportional to Re xi, a
negative value means there is NO budget at t=14.5 -- so "1397x tighter" is
not a hard target but an impossible one, and the programme is capped at the
first zero t* = 13.9883806982 (which equals the repo's own recorded hard
boundary to 3.5e-11).

Dated inline correction, following the house pattern (cf. the "NOTE
2026-10-16" block in R1_c13_2_..._CLOSED.lean). The original wording is kept
and marked, not deleted.
"""
import io, sys

P = "/Storage 2TB/home/xluxx/Principia-Fractalis-ACTIVE/codex/R1R2R3_TARGET_REACHABLE_2026-10-16.md"
s = io.open(P, encoding="utf-8").read()

# --- 1. the headline claim in the verdict block
old1 = ("3. **The binding constraint is Gate 1's enclosure, and it needs 186× at `t=13`\n"
        "   and 1397× at `t=14.5`.** No Gate-2 work of any tier touches it.")
new1 = ("3. **The binding constraint is Gate 1's enclosure, and it needs 186× at `t=13`.**\n"
        "   No Gate-2 work of any tier touches it.\n"
        "   **CORRECTION 2026-10-17: the `1397× at t=14.5` half of this claim is\n"
        "   withdrawn as erroneous — see the correction block in §5. `Re ξ(1+it)` is\n"
        "   NEGATIVE at `t=14.5`, so there is no budget there to be 1397× tighter\n"
        "   than. The programme is capped at `t* = 13.9883806982`.**")
assert s.count(old1) == 1, "headline claim not found exactly once"
s = s.replace(old1, new1, 1)

# --- 2. the table row
old2 = "| **14.5** (R2 worst) | 4.142e−04 | 1.877e−06 | **1397× tighter** |"
new2 = ("| ~~**14.5** (R2 worst)~~ | ~~4.142e−04~~ | ~~1.877e−06~~ | "
        "**ROW WITHDRAWN — see below** |")
assert s.count(old2) == 1, "table row not found exactly once"
s = s.replace(old2, new2, 1)

# --- 3. the correction block, inserted right after the table
anchor = ("**And the residue lever does not reach this.**")
correction = """**CORRECTION 2026-10-17 (Legion) — the `t = 14.5` row above is WRONG, and the
error changes the programme's ceiling.**

The table's `Re ξ` is the classical `ξ(s) = ½s(s−1)π^{−s/2}Γ(s/2)ζ(s)`. Audited
row by row against it (`codex/addon_rexi_audit.py`):

| t | as recorded | `Re ξ(1+it)` | |
|---|---|---|---|
| 6.375 | 1.868e−01 | 1.8680e−01 | ✓ |
| 8 | 1.019e−01 | 1.0192e−01 | ✓ |
| 10 | 3.681e−02 | 3.6811e−02 | ✓ |
| 12 | 8.194e−03 | 8.1941e−03 | ✓ |
| 13 | 2.509e−03 | 2.5094e−03 | ✓ |
| **14.5** | **4.142e−04** | **−5.5910e−04** | **✗ WRONG — sign** |

Five of six rows match to four digits, so the identification is certain and
this row is simply wrong. Its provenance is unexplained: the magnitude does not
match `|−5.591e−04|` either, so it is not a pure sign slip.

**Why it matters.** The Gate-1 budget is `Re ξ(1+it)/(t²+t)`, so it vanishes with
`Re ξ`. Measured: **`Re ξ(1+it)` has its first zero above `t=6` at
`t* = 13.9883806982`** (`+1.49e−05` just below, `−1.47e−05` just above) — which is
**exactly the hard boundary this repo already records, matched to 3.5e−11**.

So beyond `t*` the margin is negative and there is **no enclosure budget at
all**, not a tight one. `1397× at t=14.5` is not a hard target but an
impossible one, and **no amount of add-on or panel tightening crosses `t*`.**
This does not disturb the note's own headline (`§`"the exact positivity target
is `t = 13`, not 15 and not 13.9""), which stands and is now explained: the
target is `t=13` *because* the budget dies at 13.988.

"""
assert s.count(anchor) == 1, "anchor not found exactly once"
s = s.replace(anchor, correction + anchor, 1)

io.open(P, "w", encoding="utf-8").write(s)
print("R1R2R3 note corrected: headline, table row, and correction block inserted")
