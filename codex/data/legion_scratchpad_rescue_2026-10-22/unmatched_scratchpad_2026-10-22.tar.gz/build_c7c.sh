#!/bin/bash
# Box c = 7, finish: the four add-on modules were never built. The first run
# died at Seg01Midpoint, which precedes them in _buildorder.txt, and the resume
# script only covered the three modules whose source had changed.
exec 9>/tmp/pf_lean_build.lock
if ! flock -n 9; then echo "ANOTHER BUILD HOLDS THE LOCK" > /tmp/c7c_status; exit 1; fi
export PATH="$HOME/.elan/bin:$PATH"
cd "/Storage 2TB/home/xluxx/Principia-Fractalis-ACTIVE/PF_Lean4_Code" || exit 1
FP=".lake/build/lib/lean/PF/Analytic/FourierPanels"
PB=".lake/build/lib/lean/PF/Analytic/PilotBoxes"
mkdir -p "$FP" "$PB"
: > /tmp/c7c_progress
echo RUNNING > /tmp/c7c_status

fp() {
  taskset -c 0,1 lake env lean -o "$FP/$1.olean" \
    "PF/Analytic/FourierPanels/$1.lean" > "/tmp/c7c_$1.log" 2>&1
  local rc=$?
  echo "$1 rc=$rc $(date +%H:%M:%S) freeGB=$(free -g | awk 'NR==2{print $4}')" \
    >> /tmp/c7c_progress
  [ $rc -ne 0 ] && { echo "FAILED $1" > /tmp/c7c_status; exit 1; }
}

fp ResidueBound_c7_three_halves_to_5_2026_10_20
fp ResidueBoundTight_c7_2026_10_20
fp AnalyticTailBound_c7_2026_10_20
fp OmegaTailBound_c7_2026_10_20

# Unconditional pilot: no -o, so it is CHECKED not cached. The #print axioms
# output lands in the log and is the three-axiom-bar evidence.
taskset -c 0,1 lake env lean \
  "PF/Analytic/PilotBoxes/R1_c7_r1_16_pointwise_UNCONDITIONAL_2026_10_20.lean" \
  > /tmp/c7c_uncond.log 2>&1
rc=$?; echo "uncond rc=$rc $(date +%H:%M:%S)" >> /tmp/c7c_progress
[ $rc -ne 0 ] && { echo "FAILED uncond" > /tmp/c7c_status; exit 1; }

echo DONE > /tmp/c7c_status
