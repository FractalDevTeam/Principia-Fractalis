#!/usr/bin/env bash
# Demonstrate the two independent vacuities in verify.sh's verdict logic,
# using verify.sh's EXACT grep pipeline.
set -uo pipefail

run_gate () {   # $1 = path to a simulated axiom log
  local AXIOM_LOG="$1"
  grep -E "depends on axioms:" "${AXIOM_LOG}" \
    | grep -vE "propext|Classical\.choice|Quot\.sound" \
    | grep -v "Hardy1914_published_theorem_substrate_citation" \
    | grep -v "Mayer1991_Cohen2025_substrate_HP_program_citation" \
    | grep -v "Mayer1991_Cohen2025_T3_sym_HP_program_citation" \
    | grep -v "framework_substrate_pins_bulletproof_bundle" \
    || true
}

verdict () {
  local out; out="$(run_gate "$1")"
  if [[ -z "${out}" ]]; then echo "  GATE VERDICT: PASS (exit 0)"; else
    echo "  GATE VERDICT: FAIL (exit 2)"; echo "${out}" | sed 's/^/      /'; fi
}

echo "=============================================================="
echo "CASE A - empty log (what actually happens in CI: the modules are"
echo "         already built via PF.lean, so lake emits nothing)"
: > /tmp/caseA.log
echo "  log lines: $(wc -l < /tmp/caseA.log)"
verdict /tmp/caseA.log

echo
echo "=============================================================="
echo "CASE B - a REAL project axiom, on ONE line (the case the gate"
echo "         was designed to catch)"
cat > /tmp/caseB.log <<'EOF'
'PF.headline' depends on axioms: [propext, Classical.choice, myProjectAxiom, Quot.sound]
EOF
verdict /tmp/caseB.log

echo
echo "=============================================================="
echo "CASE C - the SAME project axiom, but Lean WRAPPED the output"
echo "         (which is what Lean actually does for long axiom lists)"
cat > /tmp/caseC.log <<'EOF'
'PF.headline' depends on axioms: [propext,
 Classical.choice,
 myProjectAxiom,
 Quot.sound]
EOF
echo "  log lines: $(wc -l < /tmp/caseC.log)"
verdict /tmp/caseC.log

echo
echo "=============================================================="
echo "CASE D - sorryAx on a wrapped continuation line"
cat > /tmp/caseD.log <<'EOF'
'PF.broken' depends on axioms: [propext,
 sorryAx,
 Quot.sound]
EOF
verdict /tmp/caseD.log

echo
echo "=============================================================="
echo "WHY C and D pass: the first line contains 'propext', so"
echo "grep -vE 'propext|...' DELETES it. The continuation lines carry"
echo "the offending axiom but do NOT contain 'depends on axioms:', so"
echo "the first grep never selects them. The offending axiom is never"
echo "examined by any filter."
