#!/usr/bin/env python3
"""Parametric density, part 1b: wire --density through gen_box.py's loader,
main loops and build order. Backslash-free anchors throughout."""
import io

p = "gen_box.py"
s = io.open(p, encoding="utf-8").read()
done = []


def rep(old, new, desc, n=1):
    global s
    got = s.count(old)
    assert got == n, f"{desc}: found {got}, expected {n}"
    s = s.replace(old, new)
    done.append(desc)


# 1. loader: inject the sub-segment geometry and the wider naming
rep("""    rg = {"__name__": "_rg", "__file__": rpath}
    exec(compile(rsrc, rpath, "exec"), rg)
    mg = {"__name__": "_mg", "__file__": mpath}
    exec(compile(msrc, mpath, "exec"), mg)
    return rg, mg""",
    """    rg = {"__name__": "_rg", "__file__": rpath}
    exec(compile(rsrc, rpath, "exec"), rg)
    mg = {"__name__": "_mg", "__file__": mpath}
    exec(compile(msrc, mpath, "exec"), mg)
    # Install the density-D geometry. At D = 1 this is the identity (the six
    # base segments, `Seg01..Seg06`), which is what makes a D = 1 run a
    # byte-identity regression test against the pre-density producer.
    inject_geometry(rg, midpoint=False)
    inject_geometry(mg, midpoint=True)
    return rg, mg""",
    "loader injection")

# 2. the hybrid panel list: range segments are everything not on midpoint
rep("""    for seg in (3, 4, 5, 6):
        for k in range(N_PANELS):
            a, b = IVL[(seg, "rng", k)]
            panels.append(("rng", seg, k, a, b))""",
    """    for seg in RANGE_SEGS:
        if seg in MID_SEGS:
            continue
        for k in range(N_PANELS):
            a, b = IVL[(seg, "rng", k)]
            panels.append(("rng", seg, k, a, b))""",
    "hybrid panel list")

# 2b. the tiling assertion should also pin the COUNT, so a mis-set density
#     cannot silently emit a box that tiles [0,3/2] with the wrong grid.
rep("""    panels.sort(key=lambda e: e[3])
    assert panels[0][3] == 0 and panels[-1][4] == F(3, 2), "panels do not tile [0,3/2]\"""",
    """    panels.sort(key=lambda e: e[3])
    assert panels[0][3] == 0 and panels[-1][4] == F(3, 2), "panels do not tile [0,3/2]"
    assert len(panels) == N_SEG_BASE * DENSITY * N_PANELS, (
        f"panel count {len(panels)} != {N_SEG_BASE * DENSITY * N_PANELS} "
        f"for density {DENSITY}")
    assert panels[0][4] - panels[0][3] == PANEL_WIDTH, "panel width disagrees\"""",
    "tiling assertions")

# 3. build order: the 02d module names, and range modules only where used
rep("""    order = ([f"CoreDefs_{t}_2026_10_16"]
             + [f"Seg0{k}Range_{t}_2026_10_16" for k in RANGE_SEGS]
             + [f"Seg0{k}Midpoint_{t}_2026_10_20" for k in MID_SEGS]""",
    """    order = ([f"CoreDefs_{t}_2026_10_16"]
             + [f"{seg_mod_range(k)}_{t}_2026_10_16" for k in RANGE_SEGS]
             + [f"{seg_mod_mid(k)}_{t}_2026_10_20" for k in MID_SEGS]""",
    "build order names")

# 4. the CLI flag, and set_density before anything is loaded
rep("""    ap.add_argument("--out", required=True)""",
    """    ap.add_argument("--density", type=int, default=1,
                    help="panel density D: each of the six segments splits "
                         "into D sub-segments of 8 panels, so 6D modules per "
                         "box and panel width 1/(32D). Must be a power of "
                         "two. D=1 is the shipped geometry.")
    ap.add_argument("--out", required=True)""",
    "CLI flag")

rep("""    c, r = F(args.c), F(args.r)
    assert c > 0 and r > 0""",
    """    c, r = F(args.c), F(args.r)
    assert c > 0 and r > 0
    set_density(args.density)""",
    "set_density call")

rep("""    print(f"=== gen_box: c = {c} ({float(c):.6f}), r = {r}, tag = {tag(c)} ===\")""",
    """    print(f"=== gen_box: c = {c} ({float(c):.6f}), r = {r}, "
          f"D = {DENSITY}, tag = {tag(c)} ===")
    print(f"  geometry  : {N_SEG_BASE * DENSITY} sub-segments x {N_PANELS} "
          f"panels, h = {PANEL_WIDTH}, "
          f"{len(MID_SEGS)} midpoint + {len(RANGE_SEGS) - len(MID_SEGS)} range")""",
    "banner")

io.open(p, "w", encoding="utf-8", newline="\n").write(s)
print("patched gen_box.py:")
for d in done:
    print("  -", d)
