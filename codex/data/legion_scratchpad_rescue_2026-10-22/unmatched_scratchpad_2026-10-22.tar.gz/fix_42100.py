#!/usr/bin/env python3
"""#42100: put Mathlib.lean's import block back in sorted order.

CI's Build step failed on head 7f7138a1 with, twice over, the same root cause:

  The file 'Mathlib.lean' is out of date: run `lake exe mk_all` to update it
  ...
  Please run 'lake exe mk_all' to regenerate the import all files

and NOT with a Lean error -- the same run reports
`[8686/8687] Built Mathlib (2.5s)`, so the two added modules compile.

`mk_all` emits one import line per module in sorted order. Checking the whole
8295-line block found exactly ONE inversion and no duplicates:

  line 1713  ...ContinuousFunctionalCalculus.SpectralProjection
  line 1714  ...ContinuousFunctionalCalculus.Restrict   <- sorts first

'Restrict' precedes 'SpectralProjection' ('R' < 'S'), so SpectralProjection was
inserted one line too early. Both added modules ARE listed and
...CFC.Ideal is correctly placed, so this is the only discrepancy.

Line terminator is detected, not assumed; writing the wrong one would rewrite
all 8299 lines and bury a one-line fix.
"""
import io
import os
import sys

PATH = "D:/CLAUDE-i9/_tmp/pr42100-wt/Mathlib.lean"
if not os.path.exists(PATH):
    print("REFUSING: not found: %s" % PATH)
    sys.exit(1)

PRE = "public import Mathlib.Analysis.CStarAlgebra.ContinuousFunctionalCalculus."
A = PRE + "SpectralProjection"
B = PRE + "Restrict"

text = io.open(PATH, encoding="utf-8", newline="").read()
CRLF = chr(13) + chr(10)
EOL = CRLF if text.count(CRLF) else chr(10)
print("detected line terminator: %s" % ("CRLF" if EOL == CRLF else "LF"))

OLD = A + EOL + B + EOL
NEW = B + EOL + A + EOL
n = text.count(OLD)
if n != 1:
    print("REFUSING: expected exactly 1 occurrence of the inverted pair, "
          "found %d" % n)
    sys.exit(1)

out = text.replace(OLD, NEW, 1)
assert len(out) == len(text), "byte length changed -- more than a reorder"
assert sorted(out.split(EOL)) == sorted(text.split(EOL)), \
    "line multiset changed -- not a pure reorder"

io.open(PATH, "w", encoding="utf-8", newline="").write(out)
print("applied: one import line moved (pure reorder, byte length unchanged)")

lines = io.open(PATH, encoding="utf-8").read().split("\n")
for i in range(1710, 1717):
    print("  %4d  %s" % (i + 1, lines[i].rstrip()))
