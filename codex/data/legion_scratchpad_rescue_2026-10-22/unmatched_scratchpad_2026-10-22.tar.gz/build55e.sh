#!/bin/bash
exec 9>/tmp/pf_lean_build.lock
if ! flock -n 9; then echo "LOCKED" > /tmp/b5_status; exit 1; fi
export PATH="$HOME/.elan/bin:$PATH"
cd "/Storage 2TB/home/xluxx/Principia-Fractalis-ACTIVE/PF_Lean4_Code" || exit 1
FP=".lake/build/lib/lean/PF/Analytic/FourierPanels"
PB=".lake/build/lib/lean/PF/Analytic/PilotBoxes"
mkdir -p "$FP" "$PB"
: > /tmp/b5_progress
r() { taskset -c 0,1 lake env lean -o "$1" "$2" > "/tmp/b5_$3.log" 2>&1
      echo "$3 rc=$? $(date +%H:%M:%S)" >> /tmp/b5_progress; }
r "$FP/ResidueBound_c55_8_three_halves_to_5_2026_10_20.olean" "PF/Analytic/FourierPanels/ResidueBound_c55_8_three_halves_to_5_2026_10_20.lean" resbase
r "$FP/ResidueBoundTight_c55_8_2026_10_20.olean" "PF/Analytic/FourierPanels/ResidueBoundTight_c55_8_2026_10_20.lean" restight
r "$FP/AnalyticTailBound_c55_8_2026_10_20.olean" "PF/Analytic/FourierPanels/AnalyticTailBound_c55_8_2026_10_20.lean" antail
r "$FP/OmegaTailBound_c55_8_2026_10_20.olean" "PF/Analytic/FourierPanels/OmegaTailBound_c55_8_2026_10_20.lean" omtail
r "$FP/Assemble_c55_8_threehalves_HYBRID_2026_10_20.olean" "PF/Analytic/FourierPanels/Assemble_c55_8_threehalves_HYBRID_2026_10_20.lean" asm
r "$PB/R1_c55_8_r1_16_HYBRID_2026_10_20.olean" "PF/Analytic/PilotBoxes/R1_c55_8_r1_16_HYBRID_2026_10_20.lean" gate
taskset -c 0,1 lake env lean "PF/Analytic/PilotBoxes/R1_c55_8_r1_16_pointwise_UNCONDITIONAL_2026_10_20.lean" > /tmp/b5_uncond.log 2>&1
echo "uncond rc=$? $(date +%H:%M:%S)" >> /tmp/b5_progress
echo DONE > /tmp/b5_status
