import sympy as sp
a, b = sp.symbols('a b')

F = a**4 + 16*a*b**3          # numerator form,   deg 4
D = 4*a**3*b - 8*b**4         # denominator form, deg 4

# ---- identity already derived by hand: 4a^2 b F - (a^3+18b^3) D = 144 b^7 ----
lhs = sp.expand(4*a**2*b*F - (a**3 + 18*b**3)*D)
print("b-side:  4a^2 b F - (a^3+18b^3) D =", sp.factor(lhs), "   == 144 b^7 ?",
      sp.simplify(lhs - 144*b**7) == 0)

# ---- find the a-side by Bezout in the a=1 dehomogenisation ----
t = sp.symbols('t')
F1 = sp.expand(F.subs({a: 1, b: t}))     # 1 + 16 t^3
D1 = sp.expand(D.subs({a: 1, b: t}))     # 4t - 8 t^4
s, u, h = sp.gcdex(F1, D1, t)
print("\ngcdex in b-dehomogenisation: h =", h, "  check:", sp.simplify(sp.expand(s*F1 + u*D1 - h)))
den = sp.lcm([sp.denom(sp.together(sp.simplify(c))) for c in [s, u]])
S1 = sp.expand(sp.simplify(s)*den); U1 = sp.expand(sp.simplify(u)*den)
print("  cleared:", sp.expand(S1*F1 + U1*D1), " = const")
print("  S1 =", S1)
print("  U1 =", U1)

# homogenise S1,U1 back (they are polys in t=b/a); total degree must make deg 7
def homog(poly_in_t, target_deg):
    p = sp.Poly(poly_in_t, t)
    out = 0
    for (k,), c in p.terms():
        out += c * b**k * a**(target_deg - k)
    return sp.expand(out)

# S1*F + U1*D should be const * a^7 after homogenising S1,U1 to degree 3
S = homog(S1, 3); U = homog(U1, 3)
res = sp.expand(S*F + U*D)
print("\na-side candidate:  S*F + U*D =", sp.factor(res))
print("  S =", S)
print("  U =", U)
print("  is it c*a^7 ?", sp.simplify(res - sp.LC(sp.Poly(res, a))*a**7) == 0 if res != 0 else None)

# ---- explicit coefficient bounds we will need in Lean ----
print("\n--- for the Lean height bound ---")
print("b-side cofactors: P_b = 4a^2 b        (coeff sum 4,  deg 3)")
print("                  Q_b = -(a^3+18b^3)  (coeff abs sum 19, deg 3)")
print("a-side cofactors: S =", S, "  U =", U)
cs = sum(abs(c) for c in sp.Poly(S, a, b).coeffs()) if S != 0 else 0
cu = sum(abs(c) for c in sp.Poly(U, a, b).coeffs()) if U != 0 else 0
print("  |coeffs| sums:  S ->", cs, "  U ->", cu)
print("  b-side const 144 ;  a-side const", sp.LC(sp.Poly(res, a)) if res != 0 else None)
