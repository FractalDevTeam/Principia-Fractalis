import sympy as sp
x, y = sp.symbols('x y', real=True)

print("=== (x^2+y^2)^a : smooth at the origin? (corrected test) ===")
print("  the earlier test restricted to y=0, x->0+ , where (x^2+y^2)^a = x^(2a)")
print("  and the conical singularity is INVISIBLE. Two honest probes below.")
print()

for a in [sp.Rational(1,2), sp.Rational(1), sp.Rational(3,2), sp.Rational(2),
          sp.Rational(5,2), sp.Rational(3)]:
    expr = (x**2 + y**2)**a
    verdict = []

    # probe A: two-sided limits of d^k/dx^k along y=0 -- a jump or blow-up kills C^k
    failA = None
    for k in range(1, 9):
        d = sp.simplify(sp.diff(expr, x, k).subs(y, 0))
        Lp = sp.limit(d, x, 0, '+'); Lm = sp.limit(d, x, 0, '-')
        bad = (Lp != Lm) or Lp.has(sp.oo, sp.zoo) or Lm.has(sp.oo, sp.zoo)
        if bad:
            failA = (k, Lp, Lm); break
    verdict.append("two-sided d^%d/dx^%d : %s vs %s" % (failA[0], failA[0], failA[1], failA[2])
                   if failA else "all x-derivatives two-sided OK")

    # probe B: is it a polynomial? (iff a is a non-negative integer)
    isperfect = sp.simplify(sp.expand(expr)).is_polynomial(x, y)
    verdict.append("polynomial: %s" % bool(isperfect))

    smooth = (failA is None) and bool(isperfect)
    print("  a = %-5s  %s" % (a, " | ".join(verdict)))
    print("           verdict: %s" % ("C^infinity" if smooth else "NOT C^infinity"))

print()
print("  Explicit low cases, for the record:")
print("   a=1/2 : (x^2+y^2)^(1/2) = r ; d r/dx along y=0 is +1 for x>0 and -1 for x<0")
print("           -> gradient jumps at the origin, not even C^1.")
d3 = sp.simplify(sp.diff((x**2+y**2)**sp.Rational(3,2), x, 3).subs(y, 0))
print("   a=3/2 : d^3/dx^3 (x^2+y^2)^(3/2) |_{y=0} =", d3,
      " -> limit x->0+ :", sp.limit(d3, x, 0, '+'), ", x->0- :", sp.limit(d3, x, 0, '-'))
print("           -> C^2 but not C^3.")
print()
print("CONCLUSION (corrected): (x^2+y^2)^a is C^infinity at the origin")
print("  iff a is a non-negative integer. With rho ~ r^(2 ell), smoothness of rho")
print("  across its own nodal line forces ell in Z_{>=0}, i.e. circulation in 2*pi*hbar*Z.")
