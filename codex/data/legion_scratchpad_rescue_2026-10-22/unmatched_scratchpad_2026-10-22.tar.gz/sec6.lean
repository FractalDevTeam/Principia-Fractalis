/-! ## §6 — `∫₀^∞ u·F″ = F(0) = ω(1)`

FTC with antiderivative `G(u) = u·F′(u) − F(u)`, whose derivative is
`F′ + u·F″ − F′ = u·F″`. At `0` it is `−F(0)`; at `∞` it vanishes because
`u·F′(u) → 0` (the `u ≤ 5exp(u/5)` trick again) and `F(u) → 0`. -/

private def G_plus (u : ℝ) : ℝ := u * F_plus' u - F_plus u
private def G_minus (u : ℝ) : ℝ := u * F_minus' u - F_minus u

private lemma hasDerivAt_F_plus'_at {u : ℝ} (hu : u ∈ Ioi (0 : ℝ)) :
    HasDerivAt F_plus' (F_plus'' u) u := by
  have h := hasDerivAt_deriv_F_plus u hu
  rw [deriv_F_plus_eq_F_plus'] at h
  have he : deriv F_plus' u = F_plus'' u := by rw [deriv_F_plus'_eq_F_plus'']
  rw [he] at h
  exact h

private lemma hasDerivAt_F_minus'_at {u : ℝ} (hu : u ∈ Ioi (0 : ℝ)) :
    HasDerivAt F_minus' (F_minus'' u) u := by
  have h := hasDerivAt_deriv_F_minus u hu
  rw [deriv_F_minus_eq_F_minus'] at h
  have he : deriv F_minus' u = F_minus'' u := by rw [deriv_F_minus'_eq_F_minus'']
  rw [he] at h
  exact h

private lemma hasDerivAt_G_plus {u : ℝ} (hu : u ∈ Ioi (0 : ℝ)) :
    HasDerivAt G_plus (u * F_plus'' u) u := by
  have h1 := (hasDerivAt_id u).mul (hasDerivAt_F_plus'_at hu)
  have h2 : HasDerivAt F_plus (F_plus' u) u := F_plus_hasDerivAt u
  have h := h1.sub h2
  have hG : G_plus = fun y : ℝ => y * F_plus' y - F_plus y := rfl
  rw [hG]
  convert h using 1
  ring

private lemma hasDerivAt_G_minus {u : ℝ} (hu : u ∈ Ioi (0 : ℝ)) :
    HasDerivAt G_minus (u * F_minus'' u) u := by
  have h1 := (hasDerivAt_id u).mul (hasDerivAt_F_minus'_at hu)
  have h2 : HasDerivAt F_minus (F_minus' u) u := F_minus_hasDerivAt u
  have h := h1.sub h2
  have hG : G_minus = fun y : ℝ => y * F_minus' y - F_minus y := rfl
  rw [hG]
  convert h using 1
  ring

private lemma tendsto_G_plus_atTop : Tendsto G_plus atTop (nhds 0) := by
  have hc : (3 / 2 - π : ℝ) + 1 / 5 < 0 := by linarith [Real.pi_gt_three]
  have hd : (1 / 2 - π : ℝ) < 0 := by linarith [Real.pi_gt_three]
  have h1 : Tendsto (fun u : ℝ => u * F_plus' u) atTop (nhds 0) := by
    have hmaj : Tendsto (fun u : ℝ => (9 * Real.exp (-π))
        * (u * Real.exp (u * (3 / 2 - π)))) atTop (nhds 0) := by
      have h := (tendsto_mul_exp_atTop_zero hc).const_mul (9 * Real.exp (-π))
      simpa using h
    refine squeeze_zero_norm' ?_ hmaj
    filter_upwards [eventually_ge_atTop (0 : ℝ)] with u hu
    rw [Real.norm_eq_abs, abs_mul, abs_of_nonneg hu]
    have hstep := mul_le_mul_of_nonneg_left (abs_F_plus'_le hu) hu
    calc u * |F_plus' u| ≤ u * (9 * Real.exp (-π) * Real.exp (u * (3 / 2 - π))) := hstep
      _ = 9 * Real.exp (-π) * (u * Real.exp (u * (3 / 2 - π))) := by ring
  have h2 : Tendsto F_plus atTop (nhds 0) := by
    have hmaj : Tendsto (fun u : ℝ => (23 / 22 * Real.exp (-π))
        * Real.exp (u * (1 / 2 - π))) atTop (nhds 0) := by
      have h := (tendsto_exp_mul_const_atTop_zero hd).const_mul (23 / 22 * Real.exp (-π))
      simpa using h
    refine squeeze_zero_norm' ?_ hmaj
    filter_upwards [eventually_ge_atTop (0 : ℝ)] with u hu
    rw [Real.norm_eq_abs, abs_of_nonneg (F_plus_nonneg u)]
    have hb := F_plus_le_exp_bound hu
    linarith [hb]
  have hsub := h1.sub h2
  rw [sub_zero] at hsub
  exact hsub

private lemma tendsto_G_minus_atTop : Tendsto G_minus atTop (nhds 0) := by
  have hc : (1 - π : ℝ) + 1 / 5 < 0 := by linarith [Real.pi_gt_three]
  have hd : (-π : ℝ) < 0 := by linarith [Real.pi_gt_three]
  have h1 : Tendsto (fun u : ℝ => u * F_minus' u) atTop (nhds 0) := by
    have hmaj : Tendsto (fun u : ℝ => (2 * π * Real.exp (-π))
        * (u * Real.exp (u * (1 - π)))) atTop (nhds 0) := by
      have h := (tendsto_mul_exp_atTop_zero hc).const_mul (2 * π * Real.exp (-π))
      simpa using h
    refine squeeze_zero_norm' ?_ hmaj
    filter_upwards [eventually_ge_atTop (0 : ℝ)] with u hu
    rw [Real.norm_eq_abs, abs_mul, abs_of_nonneg hu]
    have hstep := mul_le_mul_of_nonneg_left (abs_F_minus'_le hu) hu
    calc u * |F_minus' u|
        ≤ u * (2 * π * Real.exp (-π) * Real.exp (u * (1 - π))) := hstep
      _ = 2 * π * Real.exp (-π) * (u * Real.exp (u * (1 - π))) := by ring
  have h2 : Tendsto F_minus atTop (nhds 0) := by
    have hmaj : Tendsto (fun u : ℝ => (23 / 22 : ℝ) * Real.exp (u * (-π)))
        atTop (nhds 0) := by
      have h := (tendsto_exp_mul_const_atTop_zero hd).const_mul (23 / 22 : ℝ)
      simpa using h
    refine squeeze_zero_norm' ?_ hmaj
    filter_upwards [eventually_ge_atTop (0 : ℝ)] with u hu
    rw [Real.norm_eq_abs, abs_of_nonneg (F_minus_nonneg u)]
    have hb := F_minus_le_exp_neg_pi_mul hu
    have hmono : Real.exp (-π * Real.exp u) ≤ Real.exp (u * (-π)) := by
      apply Real.exp_le_exp.mpr
      have hge : u ≤ Real.exp u := by linarith [Real.add_one_le_exp u]
      nlinarith [Real.pi_pos, hge]
    calc F_minus u ≤ 23 / 22 * Real.exp (-π * Real.exp u) := hb
      _ ≤ 23 / 22 * Real.exp (u * (-π)) := by
          exact mul_le_mul_of_nonneg_left hmono (by norm_num)
  have hsub := h1.sub h2
  rw [sub_zero] at hsub
  exact hsub

private lemma continuousWithinAt_G_plus_zero : ContinuousWithinAt G_plus (Ici 0) 0 := by
  have hF' : ContinuousWithinAt F_plus' (Ici 0) 0 := by
    have h := continuousWithinAt_deriv_F_plus_zero
    rwa [deriv_F_plus_eq_F_plus'] at h
  have hF : ContinuousWithinAt F_plus (Ici 0) 0 :=
    ((F_plus_hasDerivAt 0).continuousAt).continuousWithinAt
  exact (continuousWithinAt_id.mul hF').sub hF

private lemma continuousWithinAt_G_minus_zero : ContinuousWithinAt G_minus (Ici 0) 0 := by
  have hF' : ContinuousWithinAt F_minus' (Ici 0) 0 := by
    have h := continuousWithinAt_deriv_F_minus_zero
    rwa [deriv_F_minus_eq_F_minus'] at h
  have hF : ContinuousWithinAt F_minus (Ici 0) 0 :=
    ((F_minus_hasDerivAt 0).continuousAt).continuousWithinAt
  exact (continuousWithinAt_id.mul hF').sub hF

/-- **★ `∫₀^∞ u·F₊″ = ω(1)` ★** -/
theorem integral_mul_F_plus''_eq :
    ∫ u in Ioi (0 : ℝ), u * F_plus'' u = omega 1 := by
  have h := integral_Ioi_of_hasDerivAt_of_tendsto
    continuousWithinAt_G_plus_zero
    (fun x hx => hasDerivAt_G_plus hx)
    integrableOn_mul_F_plus''
    tendsto_G_plus_atTop
  rw [h]
  have hG0 : G_plus 0 = -(omega 1) := by
    rw [G_plus, F_plus_zero]
    ring
  rw [hG0]
  ring

/-- **★ `∫₀^∞ u·F₋″ = ω(1)` ★** -/
theorem integral_mul_F_minus''_eq :
    ∫ u in Ioi (0 : ℝ), u * F_minus'' u = omega 1 := by
  have h := integral_Ioi_of_hasDerivAt_of_tendsto
    continuousWithinAt_G_minus_zero
    (fun x hx => hasDerivAt_G_minus hx)
    integrableOn_mul_F_minus''
    tendsto_G_minus_atTop
  rw [h]
  have hG0 : G_minus 0 = -(omega 1) := by
    rw [G_minus, F_minus_zero]
    ring
  rw [hG0]
  ring

/-- **★ The weighted constant: `∫₀^∞ u·(|F₊″| + |F₋″|) = 2·ω(1)` ★**

This is the constant that controls `|S′|` in
`d/dt Re ξ(1+it) = 2·Re S′ + (2/t)·Im S′ − (2/t²)·Im S`. -/
theorem weighted_K_sum_eq :
    (∫ u in Ioi (0 : ℝ), u * |F_plus'' u|)
      + (∫ u in Ioi (0 : ℝ), u * |F_minus'' u|) = 2 * omega 1 := by
  have hp : (∫ u in Ioi (0 : ℝ), u * |F_plus'' u|)
      = ∫ u in Ioi (0 : ℝ), u * F_plus'' u := by
    refine setIntegral_congr_fun measurableSet_Ioi (fun u hu => ?_)
    rw [abs_F_plus''_eq (le_of_lt (mem_Ioi.mp hu))]
  have hm : (∫ u in Ioi (0 : ℝ), u * |F_minus'' u|)
      = ∫ u in Ioi (0 : ℝ), u * F_minus'' u := by
    refine setIntegral_congr_fun measurableSet_Ioi (fun u hu => ?_)
    rw [abs_F_minus''_eq (le_of_lt (mem_Ioi.mp hu))]
  rw [hp, hm, integral_mul_F_plus''_eq, integral_mul_F_minus''_eq]
  ring

end

end DerivEdgeReBound20261020
end PrincipiaTractalis
