from mpmath import mp, mpf, mpc
mp.dps = 30

def omega(x):  return mp.nsum(lambda n: mp.e**(-mp.pi*n**2*x), [1, mp.inf])
def omegap(x): return mp.nsum(lambda n: -(mp.pi*n**2)*mp.e**(-mp.pi*n**2*x), [1, mp.inf])
def Lambda(s):  return mp.pi**(-s/2)*mp.gamma(s/2)*mp.zeta(s)
def Lambda0(s): return Lambda(s) + 1/s + 1/(1-s)

w1, wp1 = omega(1), omegap(1)
print("omega(1)  =", mp.nstr(w1, 15))
print("omegaP(1) =", mp.nstr(wp1, 15))
print("")
print("CLAIM from theta functional equation: omegaP(1) = -(1+2*omega(1))/8")
print("  RHS    =", mp.nstr(-(1+2*w1)/8, 20))
print("  LHS    =", mp.nstr(wp1, 20))
print("  |diff| =", mp.nstr(abs(wp1 + (1+2*w1)/8), 6))
print("")
print("Leading coeff of Lambda0(1+it) ~ C/t^2 is C = -4*(omega(1)/2 + 2*omegaP(1))")
S = w1/2 + 2*wp1
print("  omega(1)/2 + 2*omegaP(1) =", mp.nstr(S, 20), "  (claim: exactly -1/4)")
print("  C = -4*S =", mp.nstr(-4*S, 20))
print("")
print("=== numerical: t^2 * |Lambda0(1+it)| -> C ? ===")
for t in ["20", "50", "100", "400", "2000"]:
    t = mpf(t)
    v = Lambda0(mpc(1, t))
    print("  t = %7s   t^2*|Lambda0| = %s" % (t, mp.nstr(t**2*abs(v), 12)))
print("")
print("=== Gate 1 at center c needs ||Lambda0(1+ic)|| <= 1/(2c*sqrt(c^2+1)) ===")
for c in ["14.25", "50", "200", "1000"]:
    c = mpf(c)
    have = abs(Lambda0(mpc(1, c)))
    need = 1/(2*c*mp.sqrt(c**2+1))
    print("  c = %8s  have=%s  need=%s  have/need=%s"
          % (c, mp.nstr(have, 8), mp.nstr(need, 8), mp.nstr(have/need, 8)))
