#!/usr/bin/env python3
"""Repair the numerically false section-0 comment in the landed c=51/8 box.

The §0 block states R_ub_f ~ 0.018418 and a product ~0.6909. These are
mutually inconsistent (40.6406 x 0.018418 = 0.7485) and both disagree with
the actual rational constants, which appear correctly at line ~893:
    R_ub_h32 = 542831867/32000000000 ~ 0.0169634958
    I_ub_h32 =  60314889/32000000000 ~ 0.0018848403
The PROOF uses the correct constants; only the header comment is wrong.
Comment-only edit: no proof content changes.
"""
import io
import sys

P = ("/Storage 2TB/home/xluxx/Principia-Fractalis-ACTIVE/PF_Lean4_Code/"
     "PF/Analytic/PilotBoxes/R1_c51_8_r1_16_pointwise_CLOSED_2026_10_16.lean")

OLD = """Numerically:
  R_ub_f ≈ 0.017407 + 0.001011 ≈ 0.018418
  I_ub_f ≈ 0.001872 + 0.001011 ≈ 0.002883
  (2601/64)·0.018418 + (51/8)·0.002883 ≈ 0.6909 + 0.01765 ≈ 0.7086 ≤ 0.75 ✓"""

NEW = """Numerically (constants as actually used; cf. §M2.5 below):
  R_ub_h32 = 542831867/32000000000 ≈ 0.0169634958
  I_ub_h32 =  60314889/32000000000 ≈ 0.0018848403
  add-on   = 231/279841 + 1/10⁶ + 1/10⁴  ≈ 0.0009264688
  R_ub_f ≈ 0.0169634958 + 0.0009264688 ≈ 0.0178899646
  I_ub_f ≈ 0.0018848403 + 0.0009264688 ≈ 0.0028113090
  (2601/64)·0.0178899646 + (51/8)·0.0028113090
      ≈ 0.7270595 + 0.0179221 ≈ 0.7449814 ≤ 0.75 ✓   (slack ≈ +0.0050186)

NOTE 2026-10-16: the previous form of this block quoted R_ub_f ≈ 0.018418 and
a product ≈ 0.6909. Those were inconsistent with each other
(40.6406 × 0.018418 = 0.7485, which would FAIL the gate) and with the
rational constants the proof actually uses. The proof was always correct;
only this comment was wrong. Corrected above."""


def main():
    s = io.open(P, encoding="utf-8").read()
    n = s.count(OLD)
    if n != 1:
        print("ABORT: expected exactly 1 occurrence of the stale block, found %d" % n)
        return 1
    io.open(P, "w", encoding="utf-8").write(s.replace(OLD, NEW))
    print("repaired §0 header comment (comment-only; proof untouched)")
    return 0


sys.exit(main())
