#!/usr/bin/env python3
"""
Prerequisite (3) for the march to 13: refold the assemble's panel sum
hierarchically.

The emitted assemble currently proves the [0, 3/2] enclosure with a SINGLE flat
`linarith` per bound, carrying every panel bound and every adjacency equation at
once -- `96D - 1` hypotheses at density D:

    D =  1 (landed)   48 panels    95 hypotheses
    D =  4           192 panels   383
    D =  8           384 panels   767
    D = 16           768 panels  1535

`linarith` runs a simplex over that set, so the cost is superlinear in the
count and the D = 16 band -- 84 h of the priced 232 h march -- would be built
on a call sixteen times larger than any that has ever run.

The adjacency chain is cumulative (`int_0^x = int_0^y + int_y^x`) and therefore
associative, so the sum can be folded in two levels with no change to the
statement proved:

  * one bound per BLOCK of 8 consecutive panels, each from its own 8 panel
    bounds and 7 within-block adjacencies   -> 15 hypotheses per linarith;
  * then the `6D` block bounds combined with `6D - 1` block adjacencies
    -> `12D - 1` hypotheses, 191 at D = 16.

At D = 16 that is 192 linariths of 15 plus 2 of 191, against 2 of 1535.

Blocks are 8 consecutive panels in the tiling order, which at D = 1 coincides
exactly with the six segments, and in general with one source module per block.
"""
import io
import os
import re
import sys

P = sys.argv[1] if len(sys.argv) > 1 else "gen_box_part2.py"

OLD = '''        for i, (kind, s, p, a, b) in enumerate(panels):
            if kind == "mid":
                w(f"  have b{i:02d} := hm{s}{p}_{side}\\n")
            else:
                w(f"  have b{i:02d} := Seg0{s}Range.s0{s}p{p}_{side}_integral_bound\\n")
        for k in range(1, len(panels)):
            x, y = panels[k][3], panels[k][4]
            w(f"""  have h{k:02d} : (∫ u in (0 : ℝ)..({dec(x)} : ℝ), {fn} u)
             + (∫ u in ({dec(x)} : ℝ)..({dec(y)} : ℝ), {fn} u)
           = ∫ u in (0 : ℝ)..({dec(y)} : ℝ), {fn} u :=
    intervalIntegral.integral_add_adjacent_intervals ({ii} _ _) ({ii} _ _)
""")
        lows = ", ".join(f"b{i:02d}.1" for i in range(len(panels)))
        his = ", ".join(f"b{i:02d}.2" for i in range(len(panels)))
        hs = ", ".join(f"h{k:02d}" for k in range(1, len(panels)))
        w(f"""  refine ⟨?_, ?_⟩
  · linarith [{lows}, {hs}]
  · linarith [{his}, {hs}]

""")
'''

NEW = '''        # --- hierarchical fold: 8-panel blocks, then the blocks ------------
        # A single flat linarith would carry 2*len(panels) - 1 hypotheses
        # (1535 at D = 16). The adjacency chain is associative, so fold in two
        # levels: 15 hypotheses per block, then 2*nblk - 1 for the top.
        BLK = 8
        assert len(panels) % BLK == 0, \\
            f"panel count {len(panels)} is not a multiple of {BLK}"
        blocks = [panels[i:i + BLK] for i in range(0, len(panels), BLK)]
        for j, blk in enumerate(blocks):
            A, B = blk[0][3], blk[-1][4]
            blo = sum(bounds[(side, kind, s, p)][0] for kind, s, p, _a, _b in blk)
            bhi = sum(bounds[(side, kind, s, p)][1] for kind, s, p, _a, _b in blk)
            w(f"""  have B{j:03d} : ({dec(blo)} : ℝ)
          ≤ (∫ u in ({dec(A)} : ℝ)..({dec(B)} : ℝ), {fn} u)
        ∧ (∫ u in ({dec(A)} : ℝ)..({dec(B)} : ℝ), {fn} u)
          ≤ ({dec(bhi)} : ℝ) := by
""")
            for i, (kind, s, p, _a, _b) in enumerate(blk):
                if kind == "mid":
                    w(f"    have b{i} := hm{s}{p}_{side}\\n")
                else:
                    w(f"    have b{i} := Seg0{s}Range.s0{s}p{p}_{side}_integral_bound\\n")
            for k in range(1, len(blk)):
                x, y = blk[k][3], blk[k][4]
                w(f"""    have k{k} : (∫ u in ({dec(A)} : ℝ)..({dec(x)} : ℝ), {fn} u)
               + (∫ u in ({dec(x)} : ℝ)..({dec(y)} : ℝ), {fn} u)
             = ∫ u in ({dec(A)} : ℝ)..({dec(y)} : ℝ), {fn} u :=
      intervalIntegral.integral_add_adjacent_intervals ({ii} _ _) ({ii} _ _)
""")
            bl = ", ".join(f"b{i}.1" for i in range(len(blk)))
            bh = ", ".join(f"b{i}.2" for i in range(len(blk)))
            ks = ", ".join(f"k{k}" for k in range(1, len(blk)))
            w(f"""    exact ⟨by linarith [{bl}, {ks}], by linarith [{bh}, {ks}]⟩
""")
        for j in range(1, len(blocks)):
            x, y = blocks[j][0][3], blocks[j][-1][4]
            w(f"""  have H{j:03d} : (∫ u in (0 : ℝ)..({dec(x)} : ℝ), {fn} u)
             + (∫ u in ({dec(x)} : ℝ)..({dec(y)} : ℝ), {fn} u)
           = ∫ u in (0 : ℝ)..({dec(y)} : ℝ), {fn} u :=
    intervalIntegral.integral_add_adjacent_intervals ({ii} _ _) ({ii} _ _)
""")
        lows = ", ".join(f"B{j:03d}.1" for j in range(len(blocks)))
        his = ", ".join(f"B{j:03d}.2" for j in range(len(blocks)))
        hs = ", ".join(f"H{j:03d}" for j in range(1, len(blocks)))
        w(f"""  refine ⟨?_, ?_⟩
  · linarith [{lows}, {hs}]
  · linarith [{his}, {hs}]

""")
'''

src = io.open(P, encoding="utf-8").read()
n = src.count(OLD)
assert n == 1, f"flat-fold block found {n} times in {P}, expected 1"
out = src.replace(OLD, NEW)
assert "B{j:03d}" in out and "have k{k}" in out
assert out.count("linarith") == src.count("linarith") + 3, \
    "unexpected linarith count change"
io.open(P, "w", encoding="utf-8", newline="\n").write(out)
print(f"patched {P}: flat fold -> hierarchical (8-panel blocks)")
