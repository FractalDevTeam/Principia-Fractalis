#!/usr/bin/env python3
"""
Does the add-on architecture reach t = 15 at all?

The add-on budget at height t is  Re xi(t) / (t^2 + t).  The residue add-on has
a FLOOR: the true value of int_{3/2}^{5} g du, where g is the majorant the Lean
proof uses.  No amount of subdivision goes below it.  If the floor exceeds the
budget, the current add-on architecture is CAPPED at that t regardless of
tightening effort.

First: identify which 'Re xi' the R1R2R3 table used, by matching its values
(t=6.375 -> 1.868e-1, t=13 -> 2.509e-3, t=14.5 -> 4.142e-4).
"""
import math
import mpmath as mp

mp.mp.dps = 40
PI = math.pi


def g(u):
    return (math.exp(u / 2) + 1) * 3 * math.exp(-PI * math.exp(u))


# residue floor: the true integral of the majorant
N = 400000
A, B = 1.5, 5.0
h = (B - A) / N
RES_FLOOR = h * sum(g(A + (i + 0.5) * h) for i in range(N))

# --- candidate 1: Lambda_0 = completedRiemannZeta_0 (mathlib's entire version)
# Lambda(s) = pi^(-s/2) Gamma(s/2) zeta(s);  Lambda_0(s) = Lambda(s) + 1/s + 1/(1-s)
def Lambda(s):
    return mp.power(mp.pi, -s / 2) * mp.gamma(s / 2) * mp.zeta(s)


def Lambda0(s):
    return Lambda(s) + 1 / s + 1 / (1 - s)


# --- candidate 2: Riemann xi(s) = 1/2 s(s-1) pi^(-s/2) Gamma(s/2) zeta(s)
def xi(s):
    return mp.mpf(1) / 2 * s * (s - 1) * Lambda(s)


print("Identifying the table's 'Re xi' (targets: 1.868e-1, 2.509e-3, 4.142e-4):")
print(f"  {'t':>7} {'Re Lambda0(1+it)':>20} {'Re xi(1+it)':>18}")
for t in (6.375, 13.0, 14.5):
    s = mp.mpc(1, t)
    print(f"  {t:>7} {float(mp.re(Lambda0(s))):>20.4e} {float(mp.re(xi(s))):>18.4e}")

print()
print("=" * 78)
print(f"residue FLOOR (true value of int g du) = {RES_FLOOR:.4e}")
print("=" * 78)
print(f"  {'t':>6} {'Re Lambda0':>12} {'budget':>12} {'floor/budget':>14} "
      f"{'pieces for 10%':>15} {'status':>12}")
for t in [13.0, 13.5, 13.9883806982, 14.0, 14.5, 15.0]:
    s = mp.mpc(1, t)
    rexi = float(mp.re(Lambda0(s)))
    if rexi <= 0:
        print(f"  {t:>6} {rexi:>12.4e}  -- Re Lambda0 <= 0: sign fact fails here --")
        continue
    budget = rexi / (t**2 + t)
    ratio = RES_FLOOR / budget
    # pieces needed to get residue under 10% of budget
    need = 0.10 * budget
    pieces = None
    for n in range(1, 4001):
        hh = (B - A) / n
        bd = hh * sum(g(A + i * hh) for i in range(n))
        if bd <= need:
            pieces = n
            break
    status = "OK" if ratio < 0.1 else ("TIGHT" if ratio < 1 else "CAPPED")
    print(f"  {t:>6} {rexi:>12.4e} {budget:>12.4e} {ratio:>13.3f}x "
          f"{str(pieces) if pieces else '>4000':>15} {status:>12}")

print()
print("Note: 'pieces for 10%' assumes omega-gap and tail are driven to their")
print("already-proven values (4.4e-22 and 1.13e-7) -- both one-line changes.")
print("The tail's 1.13e-7 is itself a hard floor for the U=5 truncation:")
for t in [13.0, 14.5, 15.0]:
    s = mp.mpc(1, t)
    rexi = float(mp.re(Lambda0(s)))
    if rexi > 0:
        b = rexi / (t**2 + t)
        print(f"  t={t}: tail floor 1.1326e-07 is {1.1326e-07/b:.3f}x of the budget")
