#!/bin/bash
# Box c = 7 resume: only the modules whose SOURCE changed. The six Seg0kRange
# modules and CoreDefs are byte-identical to what already built clean, so their
# oleans stay valid; rebuilding them would cost 45 min for nothing.
#   Seg01/02Midpoint : retag fix for integer centres ((7:R)/1 -> (7:R))
#   Assemble         : hierarchical linarith fold (95 -> 15 hypotheses)
exec 9>/tmp/pf_lean_build.lock
if ! flock -n 9; then echo "ANOTHER BUILD HOLDS THE LOCK" > /tmp/c7b_status; exit 1; fi
export PATH="$HOME/.elan/bin:$PATH"
cd "/Storage 2TB/home/xluxx/Principia-Fractalis-ACTIVE/PF_Lean4_Code" || exit 1
FP=".lake/build/lib/lean/PF/Analytic/FourierPanels"
PB=".lake/build/lib/lean/PF/Analytic/PilotBoxes"
mkdir -p "$FP" "$PB"
: > /tmp/c7b_progress
echo RUNNING > /tmp/c7b_status

fp() {
  taskset -c 0,1 lake env lean -o "$FP/$1.olean" \
    "PF/Analytic/FourierPanels/$1.lean" > "/tmp/c7b_$1.log" 2>&1
  local rc=$?
  echo "$1 rc=$rc $(date +%H:%M:%S) freeGB=$(free -g | awk 'NR==2{print $4}')" \
    >> /tmp/c7b_progress
  [ $rc -ne 0 ] && { echo "FAILED $1" > /tmp/c7b_status; exit 1; }
}

fp Seg01Midpoint_c7_2026_10_20
fp Seg02Midpoint_c7_2026_10_20
fp Assemble_c7_threehalves_HYBRID_2026_10_20

taskset -c 0,1 lake env lean -o "$PB/R1_c7_r1_16_HYBRID_2026_10_20.olean" \
  "PF/Analytic/PilotBoxes/R1_c7_r1_16_HYBRID_2026_10_20.lean" \
  > /tmp/c7b_gate.log 2>&1
rc=$?; echo "gate rc=$rc $(date +%H:%M:%S)" >> /tmp/c7b_progress
[ $rc -ne 0 ] && { echo "FAILED gate" > /tmp/c7b_status; exit 1; }

# Unconditional pilot: no -o, so it is CHECKED not cached. #print axioms output
# lands in the log and is the three-axiom bar evidence.
taskset -c 0,1 lake env lean \
  "PF/Analytic/PilotBoxes/R1_c7_r1_16_pointwise_UNCONDITIONAL_2026_10_20.lean" \
  > /tmp/c7b_uncond.log 2>&1
rc=$?; echo "uncond rc=$rc $(date +%H:%M:%S)" >> /tmp/c7b_progress
[ $rc -ne 0 ] && { echo "FAILED uncond" > /tmp/c7b_status; exit 1; }

echo DONE > /tmp/c7b_status
