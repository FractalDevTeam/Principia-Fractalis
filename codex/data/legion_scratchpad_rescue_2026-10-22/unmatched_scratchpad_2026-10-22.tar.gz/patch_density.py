#!/usr/bin/env python3
"""
Prerequisite (1) for the D >= 2 bands of the march to 13: make the producer
parametric in panel density.

DESIGN. Density is realised by SPLITTING SEGMENTS, never by fattening a module:
peak RSS is 7.6 GB of 15 on a module of 8 panels, so an 8x-denser single module
would not fit and the march would die on memory rather than time. At density D
each of the six segments splits into D sub-segments of width 1/(4D), each
emitted as its own module with 8 panels of width h = 1/(32D). That is 6D equal
modules per box, each the same ~7m30s / 7.6 GB as today's.

WHY THIS IS A SMALL CHANGE. The shipped generators already derive panel width
from the segment (`panel_endpoints` divides `(hi - lo)` by `N_PANELS`), and the
producer already `exec`s them into a dict it owns -- it overrides `M_for_seg`
that way. So the sub-segment geometry and the wider module naming can simply be
INJECTED into the generator namespace; the shipped generators are not touched,
and the panel arithmetic is not touched at all.

NO NEW TIER IS NEEDED. The scheme stays `mmrrrr`: midpoint on the sub-segments
covering [0, 1/2], range-brick on the rest. Every midpoint sub-segment
therefore has `T <= 1/2`, which is Tier A -- the only tier the emitted M-bound
proof supports. (price7 measured that `mmrrrr` reaches c = 13 at every centre,
at a 2-4x density premium over the per-segment optimum, so Tier B buys cost but
is not required.)

NAMING. `Seg0{s}` -> `Seg{s:02d}` and `s0{s}p`/`m0{s}p` -> `s{s:02d}p`/`m{s:02d}p`.
For s = 1..6 these are byte-identical to the current names, so D = 1 must
reproduce the committed output EXACTLY -- which is the regression test.

D must be a power of two: the error literal `M/(24*(32D)^3)` and every
sub-segment endpoint `(s-1)/(4D)` must terminate as a decimal for `dec()`.
"""
import io
import sys

A = "gen_box.py"
B = "gen_box_part2.py"


def sub(path, pairs):
    s = io.open(path, encoding="utf-8").read()
    for old, new, desc, n_exp in pairs:
        n = s.count(old)
        assert n == n_exp, f"{path}: {desc}: found {n}, expected {n_exp}"
        s = s.replace(old, new)
    io.open(path, "w", encoding="utf-8", newline="\n").write(s)


# ---------------------------------------------------------------------------
# gen_box.py
# ---------------------------------------------------------------------------
sub(A, [
    # --- density-parametric geometry -------------------------------------
    ("""PANEL_WIDTH = F(1, 32)
N_PANELS = 8
MID_SEGS = (1, 2)                   # midpoint tier: T <= 1/2
RANGE_SEGS = (1, 2, 3, 4, 5, 6)     # range emitted for all six; 3-6 used by the hybrid""",
     '''N_PANELS = 8            # panels per MODULE -- fixed, never scaled with density
N_SEG_BASE = 6          # the six base segments tiling [0, 3/2]

# Density is set once from --density and read through these. Splitting segments
# rather than fattening modules is what keeps per-module RSS at the measured
# 7.6 GB of 15; see codex/DENSITY_LADDER_PRICED_2026-10-20.md section 6.
DENSITY = 1
PANEL_WIDTH = F(1, 32)
MID_SEGS = (1, 2)
RANGE_SEGS = (1, 2, 3, 4, 5, 6)
SUBSEGS = {}


def set_density(D):
    """Install the density-D geometry. D must be a power of two so that every
    sub-segment endpoint and the error literal M/(24*(32D)^3) terminate as
    decimals (gen_box.dec)."""
    global DENSITY, PANEL_WIDTH, MID_SEGS, RANGE_SEGS, SUBSEGS
    assert D >= 1 and (D & (D - 1)) == 0, f"density {D} is not a power of two"
    DENSITY = D
    PANEL_WIDTH = F(1, 32 * D)
    n = N_SEG_BASE * D
    # sub-segment s (1-based) covers [(s-1)/(4D), s/(4D)]
    SUBSEGS = {s: (F(s - 1, 4 * D), F(s, 4 * D)) for s in range(1, n + 1)}
    # scheme mmrrrr: midpoint on [0, 1/2] (the first 2D), range on the rest.
    # Every midpoint sub-segment then has T <= 1/2, which is Tier A -- the only
    # tier the emitted M-bound proof supports, at ANY density.
    MID_SEGS = tuple(range(1, 2 * D + 1))
    RANGE_SEGS = tuple(range(1, n + 1))
    for s in MID_SEGS:
        assert SUBSEGS[s][1] <= F(1, 2), (
            f"sub-segment {s} has T = {SUBSEGS[s][1]} > 1/2; the midpoint "
            f"M-bound proof is Tier A only")


def seg_mod_range(s):
    return f"Seg{s:02d}Range"


def seg_mod_mid(s):
    return f"Seg{s:02d}Midpoint"


def inject_geometry(g, midpoint):
    """Install the sub-segment geometry and the wider module naming into a
    loaded generator namespace. The generators' own functions resolve these
    through their module globals, which IS this dict, so overriding takes
    effect for calls made from inside the generator."""
    g["SEGMENTS"] = dict(SUBSEGS)
    g["N_PANELS"] = N_PANELS
    if midpoint:
        g["seg_file_name_mp"] = (
            lambda s: f"{seg_mod_mid(s)}_c27_4_2026_10_17.lean")
        g["seg_namespace_mp"] = seg_mod_mid
        g["seg_prefix_mp"] = lambda s: f"m{s:02d}p"
    else:
        g["seg_file_name"] = (
            lambda s: f"{seg_mod_range(s)}_c27_4_2026_10_16.lean")
        g["seg_namespace"] = seg_mod_range
        g["seg_prefix"] = lambda s: f"s{s:02d}p"
    return g'''),
     "geometry block", 1),

    # --- m_data's hardcoded 786432 = 24*32^3 ------------------------------
    ('''    M must be a multiple of 3 so that M*(1/32)^3/24 = M/786432 terminates
    (786432 = 2^18 * 3)."""
    tg = [int(termM_coarse(c, n, T)) + 1 for n in range(3)]
    s = sum(tg)
    M = s + (-s) % 3
    assert F(M, 786432) == F(M) * PANEL_WIDTH ** 3 / 24
    dec(F(M, 786432))        # must terminate''',
     '''    M must be a multiple of 3 so that M*h^3/24 = M/(24*(32D)^3) terminates;
    at D = 1 that denominator is 786432 = 2^18 * 3."""
    tg = [int(termM_coarse(c, n, T)) + 1 for n in range(3)]
    s = sum(tg)
    M = s + (-s) % 3
    den = 24 * (32 * DENSITY) ** 3
    assert F(M, den) == F(M) * PANEL_WIDTH ** 3 / 24
    dec(F(M, den))           # must terminate''',
     "m_data denominator", 1),
])

# ---------------------------------------------------------------------------
# gen_box_part2.py -- naming sites and the segment sets
# ---------------------------------------------------------------------------
sub(B, [
    ("""PANEL_WIDTH = F(1, 32)
N_PANELS = 8
MID_SEGS = (1, 2)
RANGE_SEGS = (1, 2, 3, 4, 5, 6)""",
     """N_PANELS = 8            # panels per MODULE -- fixed, never scaled with density
# Density-dependent values are imported from gen_box at call time rather than
# duplicated here, so the two halves of the producer cannot disagree about the
# geometry. gen_box.set_density() is the single writer.


def _geom():
    import gen_box as G
    return G.PANEL_WIDTH, G.MID_SEGS, G.RANGE_SEGS


def seg_mod_range(s):
    return f"Seg{s:02d}Range"


def seg_mod_mid(s):
    return f"Seg{s:02d}Midpoint\"""",
     "part2 geometry block", 1),

    ('        path = os.path.join(outdir, f"Seg0{s_idx}Midpoint_{t}_2026_10_20.lean")',
     '        path = os.path.join(outdir,\n'
     '                            f"{seg_mod_mid(s_idx)}_{t}_2026_10_20.lean")',
     "midpoint parse path", 1),

    ('        w(f"import PF.Analytic.FourierPanels.Seg0{s}Midpoint_{t}_2026_10_20\\n")',
     '        w(f"import PF.Analytic.FourierPanels.'
     '{seg_mod_mid(s)}_{t}_2026_10_20\\n")',
     "midpoint import", 1),

    ('''    for s in (3, 4, 5, 6):
        w(f"import PF.Analytic.FourierPanels.Seg0{s}Range_{t}_2026_10_16\\n")''',
     '''    for s in RANGE_SEGS:
        if s in MID_SEGS:
            continue
        w(f"import PF.Analytic.FourierPanels.'''
     '''{seg_mod_range(s)}_{t}_2026_10_16\\n")''',
     "range imports", 1),

    ("    Seg0{s}Midpoint.m0{s}p{p}_{side}_integral_bound",
     "    {seg_mod_mid(s)}.m{s:02d}p{p}_{side}_integral_bound",
     "midpoint bound reference", 1),

    ('                    w(f"    have b{i} := Seg0{s}Range.s0{s}p{p}_'
     '{side}_integral_bound\\n")',
     '                    w(f"    have b{i} := {seg_mod_range(s)}.'
     's{s:02d}p{p}_{side}_integral_bound\\n")',
     "range bound reference", 1),
])

print("patched gen_box.py and gen_box_part2.py for parametric density")
