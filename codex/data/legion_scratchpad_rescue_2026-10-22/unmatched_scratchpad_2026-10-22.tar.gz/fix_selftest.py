#!/usr/bin/env python3
"""Close a prime-name hole in the PROPOSED CI axiom gate, and make the
self-test able to see it.

FOUND BY MEASUREMENT, not by reading: applying the proposed parser to a real
3421-job build transcript parsed 551 records where the old line-grep selected
555. The four missing ones are declarations whose Lean names END IN A PRIME --
Lean prints `'...sub_ne_zero'' depends on axioms:` and the proposal's
`'([^']+)'` stops at the prime INSIDE the name, so the record never matches and
is silently skipped. A violation sitting in any `foo'` would pass the gate.

Primed names are ordinary Lean style, so this is not a corner case. Measured
instances in one closure: reduced_height_bound' (twice), dvd_R6_of_dvd_forms',
sub_ne_zero'.

Two edits:

1. The parser anchors the name on the marker with a GREEDY [^\\n]+ instead of
   [^']+. Keeping it newline-free stops a name swallowing its neighbours, while
   DOTALL still lets the axiom LIST wrap.

2. A fixture that can actually detect the hole. It must carry FOUR clean
   records PLUS the primed violating one, placed LAST:
     * with the buggy parser the primed record is dropped, leaving 4 clean
       records, which clears MIN_RECORDS and reports PASS -- the wrong verdict;
     * with the fixed parser there are 5 records and one violation, so
       FAIL(axiom).
   A fixture of only 4 records including the primed one would be rejected by
   the MIN_RECORDS guard even when the parser is broken -- i.e. it would pass
   for the wrong reason, which is the very slip this file exists to prevent.

This does NOT touch verify.sh or the workflow. Applying the gate to CI remains
Pablo's call; this repairs the proposal and its test.
"""
import io
import os
import shutil
import sys

SRC = ("/Storage 2TB/home/xluxx/Principia-Fractalis-ACTIVE/codex/"
       "ci_gate_selftest.sh")

OLD_REC = (
    'REC = re.compile(r"\'([^\']+)\' depends on axioms:\\s*\\[(.*?)\\]", '
    're.DOTALL)')
NEW_REC = (
    '# The name is anchored on the marker with a greedy [^\\n]+, NOT [^\']+:\n'
    '# Lean declaration names may end in a prime, which it prints inside its\n'
    '# own quotes as "...sub_ne_zero\'\' depends on axioms:", and [^\']+ stops\n'
    '# at that inner prime so the record is silently skipped. Measured: 4 of\n'
    '# 555 records in one real transcript were primed and invisible.\n'
    'REC = re.compile(r"\'([^\\n]+)\' depends on axioms:\\s*\\[(.*?)\\]", '
    're.DOTALL)')

FIXTURE_ANCHOR = (
    "# ------------------------------------------------- OLD logic "
    "(verify.sh today)")

FIXTURE = '''# F5: FOUR clean records plus a PRIMED violating record, placed last. This is
# the fixture that detects the prime-name hole. With a [^']+ parser the primed
# record is dropped, 4 clean records remain, MIN_RECORDS is satisfied and the
# verdict is a wrong PASS. Four records total (including the primed one) would
# NOT discriminate: the record-count guard would reject it even with a broken
# parser, i.e. it would pass for the wrong reason.
cat > "${TMP}/F5_primed.txt" <<'EOF'
'PF.t1' depends on axioms: [propext, Classical.choice, Quot.sound]
'PF.t2' depends on axioms: [propext, Classical.choice, Quot.sound]
'PF.t3' depends on axioms: [propext, Classical.choice, Quot.sound]
'PF.t4' depends on axioms: [propext, Classical.choice, Quot.sound]
'PF.reduced_height_bound'' depends on axioms: [propext,
 sorryAx,
 Quot.sound]
EOF

'''

OLD_CHECK = ('check "${TMP}/E_good.txt"    "E clean, 4 records"            '
             'accept')
NEW_CHECK = (
    'check "${TMP}/F5_primed.txt" "F5 primed name hides sorryAx" reject\n'
    + OLD_CHECK)

OLD_EXPL = ('echo "with too few records as a FAILURE rather than a pass."')
NEW_EXPL = (
    'echo "with too few records as a FAILURE rather than a pass."\n'
    'echo\n'
    'echo "Fixture F5 guards the prime-name hole: Lean prints a declaration"\n'
    'echo "whose name ends in a prime as \\"name\'\' depends on axioms:\\", and a"\n'
    'echo "[^\']+ parser stops at the inner prime and skips the record. Found by"\n'
    'echo "measuring a real 3421-job transcript: 4 of 555 records were primed."'
)

OLD_TAIL = ('echo "SELFTEST PASSED: new logic rejects all 7 bad fixtures '
            '(4 by the record-count\\n  guard, 3 by the axiom parser) and '
            'accepts the clean one."')
NEW_TAIL = ('echo "SELFTEST PASSED: new logic rejects all 8 bad fixtures '
            '(4 by the record-count\\n  guard, 4 by the axiom parser, one of '
            'those via a primed name) and accepts the clean one."')

text = io.open(SRC, encoding="utf-8").read()

edits = [("parser", OLD_REC, NEW_REC),
         ("fixture", FIXTURE_ANCHOR, FIXTURE + FIXTURE_ANCHOR),
         ("check call", OLD_CHECK, NEW_CHECK),
         ("explanation", OLD_EXPL, NEW_EXPL),
         ("tail count", OLD_TAIL, NEW_TAIL)]

for label, old, new in edits:
    n = text.count(old)
    if n != 1:
        print("REFUSING: %s anchor occurs %d times, expected 1" % (label, n))
        sys.exit(1)

bak = SRC + ".bak-prime"
if not os.path.exists(bak):
    shutil.copy2(SRC, bak)
    print("backup: %s" % bak)

for label, old, new in edits:
    text = text.replace(old, new, 1)
    print("applied: %s" % label)

tmp = SRC + ".new"
io.open(tmp, "w", encoding="utf-8", newline="\n").write(text)
shutil.copymode(SRC, tmp)
os.replace(tmp, SRC)

check = io.open(SRC, encoding="utf-8").read()
assert "[^\\n]+" in check and OLD_REC not in check
assert "F5_primed" in check
print("deployed")
print("bash -n:", os.system("bash -n '%s'" % SRC) == 0)
