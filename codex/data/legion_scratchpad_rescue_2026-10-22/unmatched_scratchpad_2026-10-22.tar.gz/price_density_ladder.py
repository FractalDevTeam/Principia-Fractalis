#!/usr/bin/env python3
"""
STEP 1: price the panel-density ladder for the march to c = 13.

The box criterion is  L0(c-r)*r < Mc_lb(c)  with

    Mc_lb(c) = Re xi(c) - err(c),   err(c) = (c^2 dR + c dI)/2

so a box at (c, r) has an error BUDGET

    B(c, r) = Re xi(c) - L0(c-r)*r

and needs  err(c) < B(c, r).  Because Re xi decays while the c^2 amplification
grows, B collapses toward 13 and the required density is a ladder in c -- the
same shape as the --pick-r radius ladder, for the same reason.

CALIBRATION is from the producer's own measured Mc_lb (codex/mclb_scan.txt),
not from a model: at each scanned centre
    err(c) = Re xi(c) - Mc_lb_measured(c)
and solving err = (c^2 + rho*c) dR / 2 with rho = dI/dR = 0.4418 (measured on
the c = 13 panel widths) gives the HYBRID density-1 half-width dR(c, 1).

DENSITY SCALING. The shipped hybrid is midpoint on segments 1-2 (error ~ h^2)
and range-brick on 3-6 (error ~ h^1). Raising density on a mixed scheme is
inefficient: the h^1 part comes to dominate and D ~ 11.5 is needed for a 22x
reduction. Going ALL-MIDPOINT scales as 1/D^2 throughout, at the cost of being
2.8x worse at D = 1. All-midpoint wins for any reduction past ~3x, so that is
what is priced here.

    dR_allmid(c, D) = dR_allmid(c0, 1) * (Mhat(c)/Mhat(c0)) / D^2

with the Mhat growth taken from the same coarse bound the emitted Lean proof
uses (pi <= 4, exp(T/2) <= 2, exp(T) <= 2, exp(-pi n^2) <= (1/23)^(n^2)).

BUILD COST. Density is realised as MORE MODULES, not bigger ones: peak RSS is
7.6 GB of 15 at 8 panels per file, so an 8x-denser single module would not fit.
At density D: 6D modules of 8 panels, ~7.5 min each, strictly serial.
"""
from fractions import Fraction as F
import bisect
import mpmath as mp

mp.mp.dps = 25


def xi(s):
    return mp.mpf(1) / 2 * s * (s - 1) * mp.power(mp.pi, -s / 2) * mp.gamma(s / 2) * mp.zeta(s)


Re_xi = lambda t: mp.re(xi(mp.mpc(1, t)))
W1 = mp.mpf("0.0432174056066540072876580607551")
L0 = lambda c: 2 * W1 * (1 + 1 / mp.mpf(c)) + 1 / (2 * mp.mpf(c) ** 2)

RHO = mp.mpf("0.4418")          # dI/dR, measured on the c = 13 panel widths

# ---- producer-measured Mc_lb (codex/mclb_scan.txt) -----------------------
SCAN = [(6.875, 0.14684818), (7.0, 0.13863778), (7.5, 0.11064253),
        (8.0, 0.08528181), (8.5, 0.06144593), (9.0, 0.04145387),
        (9.5, 0.02409874), (10.0, 0.00751429), (10.25, 0.00082888),
        (10.3125, -0.00074892), (10.375, -0.00232183), (10.5, -0.00538046)]
SX = [a for a, _ in SCAN]
SY = [b for _, b in SCAN]


def dR_hybrid_1(c):
    """Hybrid density-1 half-width, backed out of the measured Mc_lb."""
    c = float(c)
    if c <= SX[0]:
        i, t = 0, 0.0
    elif c >= SX[-1]:
        i, t = len(SX) - 2, 1.0
    else:
        i = bisect.bisect_right(SX, c) - 1
        t = (c - SX[i]) / (SX[i + 1] - SX[i])
    m = SY[i] + t * (SY[i + 1] - SY[i])
    err = Re_xi(mp.mpf(c)) - m
    return err * 2 / (mp.mpf(c) ** 2 + RHO * mp.mpf(c))


# ---- Mhat growth, from the emitted proof's own coarse bounds -------------
PI_UB, E_UB, T_UB = F(4), F(2), F(2)
B_UB = {n: F(1, 23) ** ((n + 1) ** 2) for n in range(3)}


def Mhat(c, T=F(1, 2)):
    tot = F(0)
    for n in range(3):
        A = PI_UB * (n + 1) ** 2
        E, Th, B, G = E_UB, T_UB, B_UB[n], abs(F(c)) / 2
        tot += (E / 4 * (2 * B) + (E + 1) * (2 * A * (A * Th - 1) * B)
                + (E + 1) * (2 * B) * G ** 2 + 2 * (E / 2) * (2 * A * B)
                + 2 * (E / 2) * (2 * B) * G + 2 * (E + 1) * (2 * A * B) * G)
    return tot


C0 = F(27, 4)
ALLMID_PENALTY = mp.mpf("2.81")      # all-midpoint vs hybrid at D = 1 (measured
                                     # from the per-segment width table)
MH0 = mp.mpf(Mhat(C0).numerator) / Mhat(C0).denominator


def dR_allmid(c, D):
    mh = Mhat(F(c).limit_denominator(10**6))
    mhf = mp.mpf(mh.numerator) / mh.denominator
    return dR_hybrid_1(C0) * ALLMID_PENALTY * (mhf / MH0) / mp.mpf(D) ** 2


def required_D(c, r):
    """Smallest integer density with err(c, D) < B(c, r)."""
    B = Re_xi(mp.mpf(c)) - L0(mp.mpf(c) - mp.mpf(r)) * mp.mpf(r)
    if B <= 0:
        return None, B
    for D in range(1, 200):
        d = dR_allmid(c, D)
        err = (mp.mpf(c) ** 2 * d + mp.mpf(c) * RHO * d) / 2
        if err < B:
            return D, B
    return None, B


# ---- the march: walk the frontier, pick r then D ------------------------
LAD = [F(1, 2 ** k) for k in range(4, 10)]
SAFE = mp.mpf("1.25")
MIN_PER_MODULE = mp.mpf("7.5")


def march(target=F(13)):
    f = F(109, 16)
    boxes = []
    guard = 0
    while f < target and guard < 2000:
        guard += 1
        best = None
        for r in LAD:
            c = f + r
            if c - r <= 0:
                continue
            D, B = required_D(c, r)
            if D is None:
                continue
            # prefer the largest r whose density is not punitive
            cost = (6 * D) * MIN_PER_MODULE
            adv = 2 * float(r)
            if best is None or cost / adv < best[3]:
                best = (c, r, D, cost / adv, B, cost)
        if best is None:
            return boxes, f, "no (r, D) works"
        c, r, D, _, B, cost = best
        boxes.append((c, r, D, float(B), cost))
        f = c + r
    return boxes, f, "reached target" if f >= target else "guard"


boxes, frontier, status = march()

print("=" * 92)
print("DENSITY LADDER TO c = 13   (all-midpoint, density realised as 6D modules"
      " of 8 panels)")
print("=" * 92)
print(f"{'#':>4} {'centre c':>12} {'r':>8} {'D':>4} {'budget B':>11}"
      f" {'err(c,D)':>11} {'modules':>8} {'hours':>7}")
tot_h = 0.0
tot_mod = 0
shown = 0
groups = {}
for i, (c, r, D, B, cost) in enumerate(boxes, 1):
    d = dR_allmid(c, D)
    err = float((mp.mpf(c) ** 2 * d + mp.mpf(c) * RHO * d) / 2)
    tot_h += cost / 60.0
    tot_mod += 6 * D
    groups.setdefault(D, []).append(float(c))
    if i <= 6 or i > len(boxes) - 6:
        print(f"{i:>4} {str(c):>12} {str(r):>8} {D:>4} {B:>11.6f}"
              f" {err:>11.6f} {6*D:>8} {cost/60.0:>7.2f}")
    elif shown == 0:
        print(f"{'':>4} {'...':>12}")
        shown = 1
print("-" * 92)
print(f"  {len(boxes)} boxes, frontier {float(frontier):.6f}  ({status})")
print(f"  {tot_mod} panel modules, {tot_h:.1f} h serial  ({tot_h/24:.1f} days)")
print()
print("  density groups:")
for D in sorted(groups):
    cs = groups[D]
    print(f"    D = {D:>3} : {len(cs):>3} boxes, c in [{min(cs):.4f}, {max(cs):.4f}]")
print()
print("  vs the flat-6.7x assumption:")
flat_h = len(boxes) * 6 * 7 * MIN_PER_MODULE / 60.0
print(f"    uniform D = 7 over {len(boxes)} boxes = {float(flat_h):.0f} h "
      f"({float(flat_h)/24:.1f} days)")
print(f"    ladder                              = {tot_h:.0f} h "
      f"({tot_h/24:.1f} days)   -> {float(flat_h)/tot_h:.1f}x cheaper")
