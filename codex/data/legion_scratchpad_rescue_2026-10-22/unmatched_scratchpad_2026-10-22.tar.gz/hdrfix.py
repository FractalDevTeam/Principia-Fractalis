#!/usr/bin/env python3
"""Correct the Layer-2 header to match the final proof."""
import io

p = "bk_wip.lean"
s = io.open(p, encoding="utf-8").read()

old = ('"every point is 2-torsion" to the rank statement, via mathlib\'s\n'
       "`rank_eq_zero_iff_isTorsion`.")
new = ('"every point is 2-torsion" to the rank statement, via mathlib\'s\n'
       "`rank_eq_zero_iff`.\n"
       "\n"
       "**Implementation note.** The hypothesis is written `P + P = 0` rather than\n"
       "`(2 : ℤ) • P = 0` deliberately. An `AddCommGroup M` with `[Module ℤ M]` carries\n"
       "*two* ℤ-scalar actions — `SubNegMonoid.toZSMul` and the `Module` one — which are\n"
       "definitionally equal but not syntactically, and the elaborator picks the\n"
       "former in a hypothesis while the goal wants the latter. The additive form is\n"
       "instance-free and sidesteps the mismatch; `two_smul` bridges it inside the\n"
       "proof.")

assert s.count(old) == 1, "anchor count = %d" % s.count(old)
io.open(p, "w", encoding="utf-8").write(s.replace(old, new))
print("header corrected")
