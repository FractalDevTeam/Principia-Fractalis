#!/usr/bin/env python3
"""Correct the three stale 'NAMED OPEN' entries for
PvsNP_via_Hodge_disc5_Bridge_Open in the 2026-08-23 dependency graph.

The Prop is a THEOREM (commit b75f5e35, alpha_bridge_is_discharged): it is
provably equivalent to ClassP != ClassNP (open_bridge_iff_classes_distinct),
and ClassP != ClassNP is itself proved unconditionally from the InClassP
specification defect (legacy_ClassP_ne_ClassNP, 2026-10-08).

Corrections are made INLINE and DATED, in the house style, rather than by
deleting the original text.
"""
import io

NOTE = ("**[CORRECTED 2026-10-17, commit b75f5e35: NOT OPEN — this Prop is a "
        "THEOREM.** `alpha_bridge_is_discharged` proves it, because "
        "`open_bridge_iff_classes_distinct` makes it equivalent to "
        "`ClassP ≠ ClassNP`, which `legacy_ClassP_ne_ClassNP` (2026-10-08) proves "
        "unconditionally from the `InClassP` trailing-input defect "
        "(`ClassP = {∅, univ}`). It has been discharge-able since 2026-10-08. The "
        "α-web's P-vs-NP bridge is therefore not this axis's open frontier; it is a "
        "theorem about a degenerate carrier. The Clay question remains open, but over "
        "the HONEST carriers (`PvsNP_Step`), not via this Prop. See "
        "`codex/PNP_REPAIR_PROPAGATION_2026-10-17.md`.]**")

p = "codex/GRAND_PROBLEM_DEPENDENCY_GRAPH_2026-08-23.md"
s = io.open(p, encoding="utf-8").read()

# --- line 42: the status table row
old42 = ("| 2 | P vs NP | Framework-internal (`ClassP`/`ClassNP` Cook-1971 style) "
         "| r123–r128 α-web | FULL-STRENGTH RESIDUAL (named open Prop "
         "`PvsNP_via_Hodge_disc5_Bridge_Open`) |")
new42 = ("| 2 | P vs NP | Framework-internal (`ClassP`/`ClassNP` Cook-1971 style) "
         "| r123–r128 α-web | FULL-STRENGTH RESIDUAL — ~~named open Prop "
         "`PvsNP_via_Hodge_disc5_Bridge_Open`~~ **CORRECTED 2026-10-17: that Prop is a "
         "THEOREM (b75f5e35), not open; the residual is real but is not reachable "
         "through it. See row D/G notes.** |")
assert s.count(old42) == 1, "line-42 anchor count = %d" % s.count(old42)
s = s.replace(old42, new42)

# --- line 116: the live-files entry
old116 = ("- `PF/PNP_Wave56CrossGaloisLockAttempt.lean` — "
          "`PvsNP_via_Hodge_disc5_Bridge_Open : Prop := ∃ f : Set Language → ℝ, "
          "f ClassP = √2 ∧ f ClassNP = φ + 1/4`. **NAMED OPEN.**")
new116 = ("- `PF/PNP_Wave56CrossGaloisLockAttempt.lean` — "
          "`PvsNP_via_Hodge_disc5_Bridge_Open : Prop := ∃ f : Set Language → ℝ, "
          "f ClassP = √2 ∧ f ClassNP = φ + 1/4`. ~~**NAMED OPEN.**~~ " + NOTE)
assert s.count(old116) == 1, "line-116 anchor count = %d" % s.count(old116)
s = s.replace(old116, new116)

# --- line 126: the kernel-proved-content entry
old126 = ("- `open_bridge_iff_P_neq_NP : PvsNP_via_Hodge_disc5_Bridge_Open ↔ "
          "ClassP ≠ ClassNP`. If the bridge Prop holds, P ≠ NP follows.")
new126 = ("- `open_bridge_iff_P_neq_NP : PvsNP_via_Hodge_disc5_Bridge_Open ↔ "
          "ClassP ≠ ClassNP`. ~~If the bridge Prop holds, P ≠ NP follows.~~ "
          "**CORRECTED 2026-10-17 (b75f5e35): the bridge Prop DOES hold — both sides "
          "of this `↔` are proved. The right-hand side is "
          "`legacy_ClassP_ne_ClassNP`, an unconditional consequence of the "
          "`InClassP` specification defect, so the equivalence carries no complexity "
          "content in either direction. The conditional reading above is therefore "
          "vacuous, not merely unfulfilled.**")
assert s.count(old126) == 1, "line-126 anchor count = %d" % s.count(old126)
s = s.replace(old126, new126)

io.open(p, "w", encoding="utf-8").write(s)
print("3 entries corrected in", p)
