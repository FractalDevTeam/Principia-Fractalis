#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Stage 2: wire ResidueBoundTight (7/10^7) into the c=13/2 pilot, and add the
module to PF.lean. Header arithmetic recomputed from the rationals."""
import io, re, shutil
from fractions import Fraction as F

ROOT = "/Storage 2TB/home/xluxx/Principia-Fractalis-ACTIVE/PF_Lean4_Code/"
PILOT = ROOT + "PF/Analytic/PilotBoxes/R1_c13_2_r1_16_pointwise_CLOSED_2026_10_16.lean"
PFLEAN = ROOT + "PF.lean"
for p in (PILOT, PFLEAN):
    shutil.copy(p, p + ".bak-wire")

s = io.open(PILOT, encoding="utf-8").read()

# (1) import
old_imp = "import PF.Analytic.FourierPanels.ResidueBound_c13_2_three_halves_to_5_2026_10_16"
assert s.count(old_imp) == 1
s = s.replace(old_imp, old_imp +
              "\nimport PF.Analytic.FourierPanels.ResidueBoundTight_c13_2_2026_10_18", 1)

# (2) open
old_open = "open PrincipiaTractalis.FourierPanels_c13_2.ResidueBound"
assert s.count(old_open) == 1
s = s.replace(old_open, old_open +
              "\nopen PrincipiaTractalis.FourierPanels_c13_2.ResidueBoundTight", 1)

# (3) point h_res at the tight theorems
for side in ("plus", "minus"):
    o = f"have h_res := nodeR_fourier_{side}_at_c13_2_N3_residue_three_halves_to_5_abs_le"
    n = f"have h_res := nodeR_fourier_{side}_at_c13_2_N3_residue_abs_le_tight"
    c = s.count(o)
    assert c >= 2, f"{side}: expected >=2 h_res sites, found {c}"
    s = s.replace(o, n)
    print(f"  {side}: {c} h_res sites repointed")

# (4) the constant, 21 sites
n231 = s.count("231/10^6")
assert n231 >= 20, f"expected >=20 residue refs, found {n231}"
s = s.replace("231/10^6", "7/10^7")
assert "231/10^6" not in s
print(f"  {n231} residue refs 231/10^6 -> 7/10^7")
# docstring unicode form
s = s.replace("231/10⁶", "7/10⁷")

# (5) header arithmetic, recomputed
R = F(1339441331, 80000000000)
I = F(302372667, 160000000000)
A = F(7, 10**7) + F(12, 10**8) + F(1, 10**21)
Rf, If = R + A, I + A
t1, t2 = F(169, 4) * Rf, F(13, 2) * If
lhs, margin = t1 + t2, F(3, 4) - (F(169, 4) * Rf + F(13, 2) * If)
d = lambda x, n=10: f"{float(x):.{n}f}"
old = """  add-on   = 7/10⁷ + 12/10⁸ + 1/10²¹ ≈ 0.00023112
  R_ub_f ≈ 0.0167430166 + 0.00023112 ≈ 0.0169741366
  I_ub_f ≈ 0.0018898292 + 0.00023112 ≈ 0.0021209492
  (169/4)·0.0169741366 + (13/2)·0.0021209492
      ≈ 0.7171573 + 0.0137862 ≈ 0.7309434 ≤ 0.75 ✓   (slack ≈ +0.0190566)"""
new = f"""  add-on   = 7/10⁷ + 12/10⁸ + 1/10²¹ ≈ 0.00000082
  R_ub_f ≈ {d(R)} + 0.00000082 ≈ {d(Rf)}
  I_ub_f ≈ {d(I)} + 0.00000082 ≈ {d(If)}
  (169/4)·{d(Rf)} + (13/2)·{d(If)}
      ≈ {d(t1, 7)} + {d(t2, 7)} ≈ {d(lhs, 7)} ≤ 0.75 ✓   (slack ≈ +{d(margin, 7)})"""
assert s.count(old) == 1, "header arithmetic block not matched"
s = s.replace(old, new, 1)

anchor = "it is Pablo's call." if False else None
note_anchor = ("The residue `7/10⁷` is now 99.9% of the remaining add-on total; subdividing\n"
               "it is the next lever (see that note's `ln k` design).")
new_note = (f"""2026-10-18 (Legion): the residue add-on is now `7/10⁷`, from
`ResidueBoundTight_c13_2_2026_10_18` — 330× tighter than the `231/10⁶` it
replaces, via an exponential majorant rather than the `ln k` subdivision that
was scoped (which would have reached only 4.1016e−6). No new transcendental
constant. Add-on total is now 8.2e−7 and the Gate-1 margin is
+{d(margin, 7)}, up from +0.0190566. The add-ons are no longer the binding
term at c=13/2: the panel enclosure is.""")
if note_anchor in s:
    s = s.replace(note_anchor, new_note, 1)
    print("  provenance note updated")
else:
    print("  WARNING: provenance anchor not found; appending not attempted")

io.open(PILOT, "w", encoding="utf-8").write(s)
print(f"\nNEW Gate-1 lhs = {d(lhs, 12)}   margin = +{d(margin, 12)}")
assert margin > 0, "Gate 1 would FAIL"

# (6) PF.lean import
t = io.open(PFLEAN, encoding="utf-8").read()
anc = "import PF.Analytic.FourierPanels.ResidueBound_c13_2_three_halves_to_5_2026_10_16"
if anc in t:
    t = t.replace(anc, anc + "\nimport PF.Analytic.FourierPanels.ResidueBoundTight_c13_2_2026_10_18"
                  + "   -- 2026-10-18 Riemann: residue 330x tighter (231/10^6 -> 7/10^7) via an"
                  + " exponential majorant; no subdivision, no new transcendental constant", 1)
    io.open(PFLEAN, "w", encoding="utf-8").write(t)
    print("PF.lean: import added")
else:
    print("PF.lean: anchor not found - NOT modified")
