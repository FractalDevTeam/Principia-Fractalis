#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
The two one-line add-on tightenings (Rio, 2026-10-18), from the add-on scoping
in 4d5c26de:

  1. epsOm : 1/10^4  ->  1/10^21
     The chain already PROVES (1/10^20)*(1/47.5 + 1/48)*(23/22) = 4.3790e-22
     and then discards 2.284e17x of it. Only the final norm_num target changes.
  2. analytic tail : 1/10^6  ->  12/10^8
     The chain already PROVES 1150/(2904*6436343) + 1150/(3454*6436343)
     = 1.1326e-7. (1e-7 is NOT reachable; 1.2e-7 is.)

HAZARD GUARDED: a naive replace of "1/10^6" would also match inside
"231/10^6" (the residue add-on), corrupting it to "2312/10^8". Every
substitution below uses a negative lookbehind for a digit.
"""
import io, re, shutil
from fractions import Fraction as F

ROOT = "/Storage 2TB/home/xluxx/Principia-Fractalis-ACTIVE/PF_Lean4_Code/"
TAIL = ROOT + "PF/Analytic/FourierPanels/AnalyticTailBound_c13_2_2026_10_16.lean"
PILOT = ROOT + "PF/Analytic/PilotBoxes/R1_c13_2_r1_16_pointwise_CLOSED_2026_10_16.lean"

for p in (TAIL, PILOT):
    shutil.copy(p, p + ".bak-addons")
print("backups written (.bak-addons)")

# ----------------------------------------------------------------- tail file
s = io.open(TAIL, encoding="utf-8").read()
n = len(re.findall(r"(?<![0-9])1 / 10 \^ 6", s))
assert n == 6, f"expected 6 spaced tail bounds, found {n}"
s = re.sub(r"(?<![0-9])1 / 10 \^ 6", "12 / 10 ^ 8", s)
# docstring mentions
s = s.replace("`≤ 1/10⁶`", "`≤ 12/10⁸`")
io.open(TAIL, "w", encoding="utf-8").write(s)
print(f"tail: {n} bounds 1/10^6 -> 12/10^8")

# --------------------------------------------------------------- pilot file
s = io.open(PILOT, encoding="utf-8").read()

# (a) epsOm definition
old = "private noncomputable abbrev epsOm : ℝ := 1 / 10 ^ 4"
new = "private noncomputable abbrev epsOm : ℝ := 1 / 10 ^ 21"
assert s.count(old) == 1, "epsOm abbrev not found"
s = s.replace(old, new, 1)

# (b) the h_numerical target and the calc step that consumes it
n4 = len(re.findall(r"(?<![0-9])\(1 : ℝ\) / 10 \^ 4", s))
s = re.sub(r"(?<![0-9])\(1 : ℝ\) / 10 \^ 4", "(1 : ℝ) / 10 ^ 21", s)
n4b = len(re.findall(r"(?<![0-9])1 / 10 \^ 4(?! )", s))
s = re.sub(r"(?<![0-9])1 / 10 \^ 4(?![0-9])", "1 / 10 ^ 21", s)
print(f"pilot: epsOm 1/10^4 -> 1/10^21  ({n4} typed + {n4b} bare targets)")

# (c) the literal 1/10^4 inside the final Gate-1 `show`
n4c = len(re.findall(r"(?<![0-9])1/10\^4", s))
assert n4c == 2, f"expected 2 bare 1/10^4 in the Gate-1 show, found {n4c}"
s = re.sub(r"(?<![0-9])1/10\^4", "1/10^21", s)

# (d) the tail constant everywhere in the pilot -- guarded against 231/10^6
n6 = len(re.findall(r"(?<![0-9])1/10\^6", s))
assert n6 >= 12, f"expected >=12 tail refs, found {n6}"
s = re.sub(r"(?<![0-9])1/10\^6", "12/10^8", s)
assert "2312/10^8" not in s, "CORRUPTION: residue constant was damaged"
assert s.count("231/10^6") >= 10, "residue constant lost"
print(f"pilot: {n6} tail refs 1/10^6 -> 12/10^8 (residue 231/10^6 intact)")

# (e) header arithmetic block -- recomputed exactly
R = F(1339441331, 80000000000)
I = F(302372667, 160000000000)
A = F(231, 10**6) + F(12, 10**8) + F(1, 10**21)
lhs = F(169, 4) * (R + A) + F(13, 2) * (I + A)
margin = F(3, 4) - lhs
print(f"\nNEW Gate-1: (169/4)(R_ub+A) + (13/2)(I_ub+A) = {float(lhs):.10f}")
print(f"            margin = {float(margin):.10f}   (was +0.0141387)")
assert margin > 0, "Gate 1 would FAIL"

old_hdr = """  add-on   = 231/10⁶ + 1/10⁶ + 1/10⁴ ≈ 0.000332"""
new_hdr = """  add-on   = 231/10⁶ + 12/10⁸ + 1/10²¹ ≈ 0.00023112"""
if s.count(old_hdr) == 1:
    s = s.replace(old_hdr, new_hdr, 1)
    print("header add-on line updated")
else:
    print("WARNING: header add-on line not matched verbatim; check by hand")

io.open(PILOT, "w", encoding="utf-8").write(s)
print("\npilot written")
print(f"\nmargin gain = {float(margin) - 0.0141387:+.7f}")
