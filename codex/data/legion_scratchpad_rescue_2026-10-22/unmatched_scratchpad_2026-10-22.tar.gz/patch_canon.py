#!/usr/bin/env python3
"""Add a runtime drift guard to gen_box.py.

Rio 2026-10-21 §2.1 requires the producer's inputs committed at the paths the
producer expects: codex/gen/, codex/addons/, and the unconditional template
beside gen_box.py. Every one of those nine files is byte-identical to a file
that ALREADY lives in the tree at its own canonical location
(PF_Lean4_Code/scripts/ for the two generators, PF/Analytic/FourierPanels/ and
PF/Analytic/PilotBoxes/ for the seven Lean templates).

So this repair introduces nine duplicates, and duplicates drift. §0.7 exists
precisely because a deployed copy drifted from a repo copy unnoticed. Rather
than leave the same hazard in a new place, the producer now verifies at startup
that each of its inputs still matches its canonical in-tree original, and
refuses to run on a mismatch -- naming the file. A drift becomes a loud failure
at generate time instead of a silent difference in an emitted box.

The check is skipped (with a printed notice, not silently) when a canonical
original is absent, so the producer still runs from a bare checkout or from the
/tmp staging.
"""
import io

p = "gen_box.py"
s = io.open(p, encoding="utf-8").read()

old = '''LF = chr(10)
N_PANELS = 8            # panels per MODULE -- fixed, never scaled with density'''

new = '''LF = chr(10)

# --------------------------------------------------------------------------
# Input drift guard
# --------------------------------------------------------------------------
# codex/gen/, codex/addons/ and the unconditional template are DUPLICATES of
# files that already live in the tree at their own canonical locations. They
# are committed here because this is where the producer looks (Rio 2026-10-21
# §2.1). Duplicates drift, and §0.7 is on the record because exactly that
# happened once already -- a deployed producer diverged from the repo one and
# nobody noticed. So verify, every run, and refuse rather than emit from a
# drifted input.
_CANON = {
    "gen/gen_fourier_panels_c27_4.py":
        "PF_Lean4_Code/scripts/gen_fourier_panels_c27_4.py",
    "gen/gen_fourier_panels_c27_4_midpoint.py":
        "PF_Lean4_Code/scripts/gen_fourier_panels_c27_4_midpoint.py",
    "addons/CoreDefs_c13_2_2026_10_16.lean":
        "PF_Lean4_Code/PF/Analytic/FourierPanels/CoreDefs_c13_2_2026_10_16.lean",
    "addons/ResidueBound_c13_2_three_halves_to_5_2026_10_16.lean":
        "PF_Lean4_Code/PF/Analytic/FourierPanels/"
        "ResidueBound_c13_2_three_halves_to_5_2026_10_16.lean",
    "addons/ResidueBoundTight_c13_2_2026_10_18.lean":
        "PF_Lean4_Code/PF/Analytic/FourierPanels/"
        "ResidueBoundTight_c13_2_2026_10_18.lean",
    "addons/AnalyticTailBound_c13_2_2026_10_16.lean":
        "PF_Lean4_Code/PF/Analytic/FourierPanels/"
        "AnalyticTailBound_c13_2_2026_10_16.lean",
    "addons/OmegaTailBound_c13_2_2026_10_16.lean":
        "PF_Lean4_Code/PF/Analytic/FourierPanels/"
        "OmegaTailBound_c13_2_2026_10_16.lean",
    "addons/R1_c13_2_r1_16_pointwise_CLOSED_2026_10_16.lean":
        "PF_Lean4_Code/PF/Analytic/PilotBoxes/"
        "R1_c13_2_r1_16_pointwise_CLOSED_2026_10_16.lean",
    "R1_c27_4_r1_16_pointwise_UNCONDITIONAL_2026_10_19.lean":
        "PF_Lean4_Code/PF/Analytic/PilotBoxes/"
        "R1_c27_4_r1_16_pointwise_UNCONDITIONAL_2026_10_19.lean",
}


def _md5(path):
    import hashlib
    h = hashlib.md5()
    with open(path, "rb") as fh:
        for blk in iter(lambda: fh.read(1 << 16), b""):
            h.update(blk)
    return h.hexdigest()


def check_inputs(verbose=True):
    """Verify every producer input against its canonical in-tree original.
    Raises on drift. Absent originals are REPORTED, never silently skipped."""
    root = os.path.dirname(HERE)
    checked, absent, bad = 0, [], []
    for rel, canon in _CANON.items():
        mine = os.path.join(HERE, rel)
        theirs = os.path.join(root, canon)
        if not os.path.exists(mine):
            bad.append(f"{rel}: MISSING from codex/ -- the producer cannot run")
            continue
        if not os.path.exists(theirs):
            absent.append(rel)
            continue
        if _md5(mine) != _md5(theirs):
            bad.append(f"{rel}: DRIFTED from {canon}")
        else:
            checked += 1
    if bad:
        raise SystemExit("producer input check FAILED:" + LF
                         + LF.join("  " + b for b in bad))
    if verbose:
        print(f"  inputs    : {checked}/{len(_CANON)} md5-match their canonical "
              f"in-tree originals"
              + (f", {len(absent)} original(s) absent: "
                 f"{', '.join(absent)}" if absent else ""))
    return checked, absent


N_PANELS = 8            # panels per MODULE -- fixed, never scaled with density'''

assert s.count(old) == 1, f"anchor: {s.count(old)}"
s = s.replace(old, new)

# call it before anything is loaded
old2 = """    set_density(args.density, extend_midpoint=args.extend_midpoint)"""
new2 = """    set_density(args.density, extend_midpoint=args.extend_midpoint)
    check_inputs()"""
assert s.count(old2) == 1, "set_density call site"
s = s.replace(old2, new2)

io.open(p, "w", encoding="utf-8", newline="\n").write(s)
print("gen_box.py: input drift guard added, runs before generation")
