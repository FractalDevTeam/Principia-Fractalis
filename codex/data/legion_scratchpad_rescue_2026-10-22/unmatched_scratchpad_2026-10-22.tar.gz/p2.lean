import Mathlib
open MeasureTheory SchwartzMap
-- extend's second hypothesis: is toLpCLM uniformly inducing?
#check @SchwartzMap.toLpCLM
example : True := trivial
-- any IsUniformInducing / isometry facts about toLp?
#check @SchwartzMap.norm_toLp
#check @IsUniformInducing
#check @ContinuousLinearMap.isUniformInducing
#check @LinearIsometry.isUniformInducing
#check @Isometry.isUniformInducing
