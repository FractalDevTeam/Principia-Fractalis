#!/usr/bin/env python3
"""Where does the march actually stop? Gate 2 vs Gate 1.

Gate 2, as written in R1_c51_8_r_pointwise_SCAFFOLD_2026_10_16 line ~18:
    "(1 + 2|t|) * 50 + (t^2 + |t|) * 50 <= 2 * 1727   at |t| <= 103/16"
This is what licenses the derivative bound L = 1 over the box, using the
uniform enclosure ||Lambda0|| <= 50/1727. It is an inequality in the box's
UPPER EDGE |t|, so it has its own hard ceiling.

Gate 1, by contrast, is the pointwise-panel enclosure at the box CENTRE, and
its true-value headroom runs to where Re xi(1+ic) crosses Mc_lb = 1/8.
"""
from fractions import Fraction as F
from mpmath import mp, mpf, mpc, pi, gamma, zeta, power

mp.dps = 40


def gate2_lhs(t):
    return (1 + 2 * t) * 50 + (t * t + t) * 50


RHS = 2 * 1727

print("=" * 76)
print("GATE 2:  50(1+2|t|) + 50(t^2+|t|) <= %d   i.e.  50(t^2+3t+1) <= %d" % (RHS, RHS))
print("         <=>  t^2 + 3t + 1 <= %s  = %.6f" % (F(RHS, 50), RHS / 50))
# exact ceiling: t^2+3t+1 = RHS/50
disc = 9 - 4 * (1 - RHS / 50)
tmax = (-3 + disc ** 0.5) / 2
print("         ceiling:  t <= (-3 + sqrt(9 + 4(%.2f - 1)))/2 = %.6f" % (RHS / 50, tmax))
print()
print("Per-box check (r = 1/16, gate 2 is evaluated at the box UPPER EDGE):")
print("%-10s %-12s %-14s %-12s %-8s" % ("centre", "upper edge", "50(t^2+3t+1)", "slack", "verdict"))
centres = ["6", "49/8", "25/4", "51/8", "13/2", "53/8", "27/4", "55/8", "7"]
r = F(1, 16)
for cs in centres:
    c = F(cs)
    hi = c + r
    lhs = gate2_lhs(hi)
    ok = lhs <= RHS
    tag = "PASS" if ok else "**FAIL**"
    mark = "   <-- requested box" if cs == "13/2" else ""
    print("%-10s %-12s %-14.2f %-12.2f %-8s%s"
          % (cs, str(hi) + " = " + ("%.4f" % float(hi)), float(lhs), float(RHS - lhs), tag, mark))

print()
print("=" * 76)
print("GATE 1 true-value headroom, for comparison")


def Lambda0(s):
    return power(pi, -s / 2) * gamma(s / 2) * zeta(s) + 1 / s + 1 / (1 - s)


def re_xi(c):
    c = mpf(c)
    L0 = Lambda0(mpc(1, c))
    return (1 - c ** 2 * L0.real - c * L0.imag) / 2


def cross(target, lo=mpf(6), hi=mpf(14)):
    f = lambda c: re_xi(c) - target
    assert f(lo) > 0, "lower bracket already below target"
    if f(hi) > 0:
        return None
    for _ in range(300):
        mid = (lo + hi) / 2
        if f(mid) > 0:
            lo = mid
        else:
            hi = mid
    return (lo + hi) / 2


for name, thr in [("1/8", mpf(1) / 8), ("1/16", mpf(1) / 16), ("0", mpf(0))]:
    print("   true Re xi(1+ic) crosses %-5s at c = %.6f" % (name, cross(thr)))

print()
print("=" * 76)
print("CONCLUSION")
print("  requested box [6.4375, 6.5625]:")
lhs = gate2_lhs(F(13, 2) + r)
print("    gate 2 : 50(t^2+3t+1) = %.2f <= %d, slack %.2f   PASS" % (float(lhs), RHS, float(RHS - lhs)))
print("    gate 1 : true Re xi at worst edge 6.5625 = %.6f, vs 1/8 margin %+.6f   PASS"
      % (float(re_xi("6.5625")), float(re_xi("6.5625") - mpf(1) / 8)))
print()
print("  but the march's binding constraint is GATE 2, at |t| <= %.4f:" % tmax)
print("    centres 13/2, 53/8, 27/4 pass; centre 55/8 = 6.875 FAILS (edge 6.9375).")
print("    So three more boxes, then gate 2 breaks -- while gate 1's true-value")
print("    headroom runs to c = %.4f, well beyond." % cross(mpf(1) / 8))
print("    Tightening the gate-1 enclosure (residue / tail / omega-gap) does")
print("    NOT move the gate-2 ceiling: that one is set by the uniform")
print("    ||Lambda0|| <= 50/1727 derivative route, which is a different object.")
