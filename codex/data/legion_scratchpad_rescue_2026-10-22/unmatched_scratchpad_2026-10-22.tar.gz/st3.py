#!/usr/bin/env python3
import io

# 1. self-test summary line: 4 -> 7 bad fixtures
p = "/tmp/ci_gate_selftest.sh"
s = io.open(p, encoding="utf-8").read()
old = "SELFTEST PASSED: new logic rejects all 4 bad fixtures and accepts the clean one."
new = "SELFTEST PASSED: new logic rejects all 7 bad fixtures (4 by the record-count\\n  guard, 3 by the axiom parser) and accepts the clean one."
assert s.count(old) == 1
io.open(p, "w", encoding="utf-8").write(s.replace(old, new))
print("selftest message corrected")

# 2. note: extend the verdict table with the full-size fixtures
q = "/tmp/CI_GATE_VACUOUS_2026-10-17.md"
s2 = io.open(q, encoding="utf-8").read()
oldrow = ("| **D** | `sorryAx` on a wrapped continuation line | **PASS** |\n")
newrow = ("| **D** | `sorryAx` on a wrapped continuation line | **PASS** |\n"
          "| **B4** | 4 records, one carrying `myProjectAxiom`, single line | **PASS** |\n"
          "| **C4** | 4 records, one carrying `myProjectAxiom`, wrapped | **PASS** |\n"
          "| **D4** | 4 records, one carrying `sorryAx`, wrapped | **PASS** |\n")
assert s2.count(oldrow) == 1
s2 = s2.replace(oldrow, newrow)

oldb = "**B is the finding.**"
newb = ("**B4/C4/D4 are the sharpest form.** Those transcripts are *well formed and\n"
        "adequately populated* — four records each, no empty-log excuse — and one record\n"
        "in each carries a genuine violation. The old logic passes all three. So the\n"
        "defect is not about the transcript being empty; it is about the verdict logic\n"
        "being unable to reject anything.\n"
        "\n"
        "**B is the finding.**")
assert s2.count(oldb) == 1
s2 = s2.replace(oldb, newb, 1)

io.open(q, "w", encoding="utf-8").write(s2)
print("note table extended")
