import PF.Analytic.Lambda0PrimeUniformBound_2026_10_14
import Mathlib.Analysis.Calculus.ParametricIntegral

open Complex Real MeasureTheory Set

-- ===== THE GATE: differentiation under the integral sign =====
#check @hasDerivAt_integral_of_dominated_loc_of_deriv_le

-- ===== supporting pieces =====
#check @Real.log_le_sub_one_of_pos
#check @Complex.hasDerivAt_const_cpow
#check @completedRiemannZeta₀_eq_theta_integral
#check @Complex.norm_deriv_le_of_forall_mem_sphere_norm_le
#check @integral_exp_neg_mul_Ioi
#check @Complex.norm_cpow_eq_rpow_re_of_pos
#check @Real.add_pow_le_pow_mul_pow_of_sq_le_sq

section InTree
open PrincipiaTractalis.Lambda0PrimeUniformBound20261014
open PrincipiaTractalis.Lambda0UniformBound20261014
#check @norm_integrand_bound_strip
#check @lambda0_abs_uniform_strip
#check @omega_le_geometric
#check @integral_exp_neg_pi_mul_Ioi
#check @one_sub_exp_neg_pi_pos
#check @exp_neg_pi_le_eighth
end InTree
