#!/bin/bash
export PATH="$HOME/.elan/bin:$PATH"
cd "/Storage 2TB/home/xluxx/Principia-Fractalis-ACTIVE/PF_Lean4_Code" || exit 1
B=".lake/build/lib/lean/PF/Analytic/FourierPanels"
mkdir -p "$B"
: > /tmp/b_progress
for k in 1 2 3 4 5 6; do
  taskset -c 0,1 lake env lean -o "$B/Seg0${k}Range_c55_8_2026_10_16.olean" "PF/Analytic/FourierPanels/Seg0${k}Range_c55_8_2026_10_16.lean" > /tmp/b_r$k.log 2>&1
  echo "r$k rc=$? $(date +%H:%M:%S)" >> /tmp/b_progress
done
for k in 1 2; do
  taskset -c 0,1 lake env lean -o "$B/Seg0${k}Midpoint_c55_8_2026_10_20.olean" "PF/Analytic/FourierPanels/Seg0${k}Midpoint_c55_8_2026_10_20.lean" > /tmp/b_m$k.log 2>&1
  echo "m$k rc=$? $(date +%H:%M:%S)" >> /tmp/b_progress
done
echo DONE > /tmp/b_status
