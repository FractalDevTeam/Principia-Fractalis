#!/bin/bash
# Serial, lock-guarded. A single Seg0kRange build peaks at 5-7 GB on a 15 GB
# box, so two concurrent builds OOM (observed: rc=137). The lock makes a second
# invocation refuse rather than collide.
exec 9>/tmp/pf_lean_build.lock
if ! flock -n 9; then echo "ANOTHER BUILD HOLDS THE LOCK" > /tmp/b4_status; exit 1; fi
export PATH="$HOME/.elan/bin:$PATH"
cd "/Storage 2TB/home/xluxx/Principia-Fractalis-ACTIVE/PF_Lean4_Code" || exit 1
B=".lake/build/lib/lean/PF/Analytic/FourierPanels"
mkdir -p "$B"
: > /tmp/b4_progress
run() {  # $1 = label, $2 = olean, $3 = src
  taskset -c 0,1 lake env lean -o "$B/$2" "PF/Analytic/FourierPanels/$3" > "/tmp/b4_$1.log" 2>&1
  echo "$1 rc=$? $(date +%H:%M:%S) peakfree=$(free -g | awk 'NR==2{print $4}')" >> /tmp/b4_progress
}
run m2 Seg02Midpoint_c55_8_2026_10_20.olean Seg02Midpoint_c55_8_2026_10_20.lean
for k in 1 2 3 4 5 6; do
  run r$k "Seg0${k}Range_c55_8_2026_10_16.olean" "Seg0${k}Range_c55_8_2026_10_16.lean"
done
echo DONE > /tmp/b4_status
